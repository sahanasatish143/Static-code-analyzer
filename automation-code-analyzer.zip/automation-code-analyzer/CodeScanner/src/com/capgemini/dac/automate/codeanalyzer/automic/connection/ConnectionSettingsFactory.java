package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionSettingsFactory
{
  public ConnectionSettings getDefaultConnectionSettings();
  public ConnectionSettings parseConnectionSettingsFromSource();
}
