/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSCITAttribute
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSCITAttribute object in the context of an editor or in a code translator.
   */
  public JOBSCITAttribute()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setOutputDb(1);
    this.setOutputDbErr(1);
    this.setOutputFile(0);
    this.setOptReportPLOG(1);
    this.setRequTaskParams(0);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSCITAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSCITAttribute.
   * @see JOBSCITAttributeFactory
   */
  public JOBSCITAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for OutputDb.
   *
   * @param OutputDb the OutputDb value to set
   */
  public void setOutputDb(Integer outputDb)
  {
    properties.setProperty("OutputDb", outputDb.toString());
  }

  /**
   * Standard getter for OutputDb.
   *
   * @return the OutputDb
   * @returns the OutputDb value
   */
  public Integer getOutputDb()
  {
    return Integer.parseInt(properties.getProperty("OutputDb"));
  }

  /**
   * Standard setter for OutputDbErr.
   *
   * @param OutputDbErr the OutputDbErr value to set
   */
  public void setOutputDbErr(Integer outputDbErr)
  {
    properties.setProperty("OutputDbErr", outputDbErr.toString());
  }

  /**
   * Standard getter for OutputDbErr.
   *
   * @return the OutputDbErr
   * @returns the OutputDbErr value
   */
  public Integer getOutputDbErr()
  {
    return Integer.parseInt(properties.getProperty("OutputDbErr"));
  }

  /**
   * Standard setter for OutputFile.
   *
   * @param OutputFile the OutputFile value to set
   */
  public void setOutputFile(Integer outputFile)
  {
    properties.setProperty("OutputFile", outputFile.toString());
  }

  /**
   * Standard getter for OutputFile.
   *
   * @return the OutputFile
   * @returns the OutputFile value
   */
  public Integer getOutputFile()
  {
    return Integer.parseInt(properties.getProperty("OutputFile"));
  }

  /**
   * Standard setter for OptReportPLOG.
   *
   * @param OptReportPLOG the OptReportPLOG value to set
   */
  public void setOptReportPLOG(Integer optReportPLOG)
  {
    properties.setProperty("OptReportPLOG", optReportPLOG.toString());
  }

  /**
   * Standard getter for OptReportPLOG.
   *
   * @return the OptReportPLOG
   * @returns the OptReportPLOG value
   */
  public Integer getOptReportPLOG()
  {
    return Integer.parseInt(properties.getProperty("OptReportPLOG"));
  }

  /**
   * Standard setter for RequTaskParams.
   *
   * @param RequTaskParams the RequTaskParams value to set
   */
  public void setRequTaskParams(Integer requTaskParams)
  {
    properties.setProperty("RequTaskParams", requTaskParams.toString());
  }

  /**
   * Standard getter for RequTaskParams.
   *
   * @return the RequTaskParams
   * @returns the RequTaskParams value
   */
  public Integer getRequTaskParams()
  {
    return Integer.parseInt(properties.getProperty("RequTaskParams"));
  }

}
