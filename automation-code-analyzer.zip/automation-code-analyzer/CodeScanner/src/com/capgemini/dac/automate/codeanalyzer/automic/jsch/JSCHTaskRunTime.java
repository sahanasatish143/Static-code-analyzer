/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jsch;

import java.util.Properties;

/**
 * Represents a single runTime block of an Automic JSCH object JSCHStructure
 * task.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.8
 */
public class JSCHTaskRunTime
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JSCHTaskRunTime object in the context of an editor or in a code translator.
   */
  public JSCHTaskRunTime()
  {
    this.properties = new Properties();
    this.setMrtCancel(0);
    this.setMrtDays(0);
    this.setMrtErt(0);
    this.setMrtExecute(0);
    this.setMrtExecuteObj(0);
    this.setMrtFix(0);
    this.setMrtMethodDate(0);
    this.setMrtMethodErt(0);
    this.setMrtMethodFix(0);
    this.setMrtMethodNone(1);
    this.setMrtOn(1);
    this.setMrtTZ("");
    this.setMrtTim("00:00");
    this.setSrtErt(0);
    this.setSrtFix(0);
    this.setSrtMethodErt(0);
    this.setSrtMethodFix(0);
    this.setSrtMethodNone(1);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JSCHTaskRunTimeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JSCHTaskRunTime.
   * @see JSCHTaskRunTimeFactory
   */
  public JSCHTaskRunTime(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for MrtCancel
   *
   * @param mrtCancel the MrtCancel value to set
   */
  public void setMrtCancel(Integer mrtCancel)
  {
    properties.setProperty("MrtCancel", mrtCancel.toString());
  }

  /**
   * Standard getter for MrtCancel
   *
   * @returns the MrtCancel value
   */
  public Integer getMrtCancel()
  {
    return Integer.parseInt(properties.getProperty("MrtCancel"));
  }

  /**
   * Standard setter for MrtDays
   *
   * @param mrtDays the MrtDays value to set
   */
  public void setMrtDays(Integer mrtDays)
  {
    properties.setProperty("MrtDays", mrtDays.toString());
  }

  /**
   * Standard getter for MrtDays
   *
   * @returns the MrtDays value
   */
  public Integer getMrtDays()
  {
    return Integer.parseInt(properties.getProperty("MrtDays"));
  }

  /**
   * Standard setter for MrtErt
   *
   * @param mrtErt the MrtErt value to set
   */
  public void setMrtErt(Integer mrtErt)
  {
    properties.setProperty("MrtErt", mrtErt.toString());
  }

  /**
   * Standard getter for MrtErt
   *
   * @returns the MrtErt value
   */
  public Integer getMrtErt()
  {
    return Integer.parseInt(properties.getProperty("MrtErt"));
  }

  /**
   * Standard setter for MrtExecute
   *
   * @param mrtExecute the MrtExecute value to set
   */
  public void setMrtExecute(Integer mrtExecute)
  {
    properties.setProperty("MrtExecute", mrtExecute.toString());
  }

  /**
   * Standard getter for MrtExecute
   *
   * @returns the MrtExecute value
   */
  public Integer getMrtExecute()
  {
    return Integer.parseInt(properties.getProperty("MrtExecute"));
  }

  /**
   * Standard setter for MrtExecuteObj
   *
   * @param mrtExecuteObj the MrtExecuteObj value to set
   */
  public void setMrtExecuteObj(Integer mrtExecuteObj)
  {
    properties.setProperty("MrtExecuteObj", mrtExecuteObj.toString());
  }

  /**
   * Standard getter for MrtExecuteObj
   *
   * @returns the MrtExecuteObj value
   */
  public Integer getMrtExecuteObj()
  {
    return Integer.parseInt(properties.getProperty("MrtExecuteObj"));
  }

  /**
   * Standard setter for MrtFix
   *
   * @param mrtFix the MrtFix value to set
   */
  public void setMrtFix(Integer mrtFix)
  {
    properties.setProperty("MrtFix", mrtFix.toString());
  }

  /**
   * Standard getter for MrtFix
   *
   * @returns the MrtFix value
   */
  public Integer getMrtFix()
  {
    return Integer.parseInt(properties.getProperty("MrtFix"));
  }

  /**
   * Standard setter for MrtMethodDate
   *
   * @param mrtMethodDate the MrtMethodDate value to set
   */
  public void setMrtMethodDate(Integer mrtMethodDate)
  {
    properties.setProperty("MrtMethodDate", mrtMethodDate.toString());
  }

  /**
   * Standard getter for MrtMethodDate
   *
   * @returns the MrtMethodDate value
   */
  public Integer getMrtMethodDate()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodDate"));
  }

  /**
   * Standard setter for MrtMethodErt
   *
   * @param mrtMethodErt the MrtMethodErt value to set
   */
  public void setMrtMethodErt(Integer mrtMethodErt)
  {
    properties.setProperty("MrtMethodErt", mrtMethodErt.toString());
  }

  /**
   * Standard getter for MrtMethodErt
   *
   * @returns the MrtMethodErt value
   */
  public Integer getMrtMethodErt()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodErt"));
  }

  /**
   * Standard setter for MrtMethodFix
   *
   * @param mrtMethodFix the MrtMethodFix value to set
   */
  public void setMrtMethodFix(Integer mrtMethodFix)
  {
    properties.setProperty("MrtMethodFix", mrtMethodFix.toString());
  }

  /**
   * Standard getter for MrtMethodFix
   *
   * @returns the MrtMethodFix value
   */
  public Integer getMrtMethodFix()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodFix"));
  }

  /**
   * Standard setter for MrtMethodNone
   *
   * @param mrtMethodNone the MrtMethodNone value to set
   */
  public void setMrtMethodNone(Integer mrtMethodNone)
  {
    properties.setProperty("MrtMethodNone", mrtMethodNone.toString());
  }

  /**
   * Standard getter for MrtMethodNone
   *
   * @returns the MrtMethodNone value
   */
  public Integer getMrtMethodNone()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodNone"));
  }

  /**
   * Standard setter for MrtOn
   *
   * @param mrtOn the MrtOn value to set
   */
  public void setMrtOn(Integer mrtOn)
  {
    properties.setProperty("MrtOn", mrtOn.toString());
  }

  /**
   * Standard getter for MrtOn
   *
   * @returns the MrtOn value
   */
  public Integer getMrtOn()
  {
    return Integer.parseInt(properties.getProperty("MrtOn"));
  }

  /**
   * Standard setter for MrtTZ
   *
   * @param mrtTZ the MrtTZ value to set
   */
  public void setMrtTZ(String mrtTZ)
  {
    properties.setProperty("MrtTZ", mrtTZ);
  }

  /**
   * Standard getter for MrtTZ
   *
   * @returns the MrtTZ value
   */
  public String getMrtTZ()
  {
    return properties.getProperty("MrtTZ");
  }

  /**
   * Standard setter for MrtTim
   *
   * @param MrtTim the MrtTim value to set
   */
  public void setMrtTim(String MrtTim)
  {
    properties.setProperty("MrtTim", MrtTim);
  }

  /**
   * Standard getter for MrtTim
   *
   * @returns the MrtTim value
   */
  public String getMrtTim()
  {
    return properties.getProperty("MrtTim");
  }

  /**
   * Standard setter for SrtErt
   *
   * @param srtErt the SrtErt value to set
   */
  public void setSrtErt(Integer srtErt)
  {
    properties.setProperty("SrtErt", srtErt.toString());
  }

  /**
   * Standard getter for SrtErt
   *
   * @returns the SrtErt value
   */
  public Integer getSrtErt()
  {
    return Integer.parseInt(properties.getProperty("SrtErt"));
  }

  /**
   * Standard setter for SrtFix
   *
   * @param srtFix the SrtFix value to set
   */
  public void setSrtFix(Integer srtFix)
  {
    properties.setProperty("SrtFix", srtFix.toString());
  }

  /**
   * Standard getter for SrtFix
   *
   * @returns the SrtFix value
   */
  public Integer getSrtFix()
  {
    return Integer.parseInt(properties.getProperty("SrtFix"));
  }

  /**
   * Standard setter for SrtMethodErt
   *
   * @param srtMethodErt the SrtMethodErt value to set
   */
  public void setSrtMethodErt(Integer srtMethodErt)
  {
    properties.setProperty("SrtMethodErt", srtMethodErt.toString());
  }

  /**
   * Standard getter for SrtMethodErt
   *
   * @returns the SrtMethodErt value
   */
  public Integer getSrtMethodErt()
  {
    return Integer.parseInt(properties.getProperty("SrtMethodErt"));
  }

  /**
   * Standard setter for SrtMethodFix
   *
   * @param srtMethodFix the SrtMethodFix value to set
   */
  public void setSrtMethodFix(Integer srtMethodFix)
  {
    properties.setProperty("SrtMethodFix", srtMethodFix.toString());
  }

  /**
   * Standard getter for SrtMethodFix
   *
   * @returns the SrtMethodFix value
   */
  public Integer getSrtMethodFix()
  {
    return Integer.parseInt(properties.getProperty("SrtMethodFix"));
  }

  /**
   * Standard setter for SrtMethodNone
   *
   * @param SrtMethodNone the SrtMethodNone value to set
   */
  public void setSrtMethodNone(Integer SrtMethodNone)
  {
    properties.setProperty("SrtMethodNone", SrtMethodNone.toString());
  }

  /**
   * Standard getter for SrtMethodNone
   *
   * @returns the SrtMethodNone value
   */
  public Integer getSrtMethodNone()
  {
    return Integer.parseInt(properties.getProperty("SrtMethodNone"));
  }
}