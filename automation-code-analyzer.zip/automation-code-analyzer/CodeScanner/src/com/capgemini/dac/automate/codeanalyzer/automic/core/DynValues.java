/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.ArrayList;
import java.util.Properties;

/**
 * Represents a dynamic values declaration in an Automic executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class DynValues
{
  private Properties properties;
  private ArrayList<DynNode> nodes;

  /**
   * Constructor to build a default DynValues object.
   */
  public DynValues()
  {
    this.properties = new Properties();
    nodes = new ArrayList<DynNode>();
    this.setState(1);
  }

  /**
   * Constructor meant to be used by a factory adhering to the DynValuesFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public DynValues(Properties properties)
  {
    this.properties = properties;
    nodes = new ArrayList<DynNode>();
  }

  /**
   * Adds a DynNode to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void add(DynNode node)
  {
    nodes.add(node);
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

}