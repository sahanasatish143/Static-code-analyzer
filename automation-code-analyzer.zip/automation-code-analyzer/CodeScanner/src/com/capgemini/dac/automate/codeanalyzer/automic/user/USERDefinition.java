/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.user;

import java.util.Properties;

/**
 * This class represents an Automic USERDefinition under USER object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class USERDefinition
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the USERDefinitionFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for USERDefinition.
   * @see USERDefinitionFactory
   */
  public USERDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * USERDefinition under USER object in the context of an editor or in a code
   * translator.
   */
  public USERDefinition()
  {
    this.properties = new Properties();
    this.setKDCIgnoreSSO(0);
    this.setldap(1);
    this.setstate(1);
    this.setActive(1);
    this.setFirstName("");
    this.setLocked(0);
    this.setLastName("");
    this.setEMail1("");
    this.setEMail2("");
    this.setPwdChange(0);
    this.setLogin("");
    this.setPwdNeverExpire(0);
    this.setIgnoreSSO(0);
    this.setPwdMustChange(0);
    this.setLdap(0);
    this.setDstngshdName("");
    this.setCboTimeZone("");
    this.setValidTimeFrom("");
    this.setValidTimeTo("");
    this.setValidTime(0);
    this.setCaleName("");
    this.setCaleKeyName("");
    this.setMultiLogon(0);
    this.setEHRefresh(90);
    this.setErrorCnt(0);
  }

  /**
   * Standard setter for FirstName tag.
   *
   * @param firstName the new first name
   */
  public void setFirstName(String firstName)
  {
    properties.setProperty("firstName", firstName);
  }

  /**
   * Standard getter for FirstName tag.
   *
   * @return the FirstName value
   */
  public String getFirstName()
  {
    return properties.getProperty("firstName");
  }

  /**
   * Standard setter for LastName tag.
   *
   * @param lastName the new last name
   */
  public void setLastName(String lastName)
  {
    properties.setProperty("lastName", lastName);
  }

  /**
   * Standard getter for LastName tag.
   *
   * @return the LastName value
   */
  public String getLastName()
  {
    return properties.getProperty("lastName");
  }

  /**
   * Standard setter for EMail1 tag.
   *
   * @param eMail1 the new e mail 1
   */
  public void setEMail1(String eMail1)
  {
    properties.setProperty("eMail1", eMail1);
  }

  /**
   * Standard getter for EMail1 tag.
   *
   * @return the EMail1 value
   */
  public String getEMail1()
  {
    return properties.getProperty("eMail1");
  }

  /**
   * Standard setter for EMail2 tag.
   *
   * @param eMail2 the new e mail 2
   */
  public void setEMail2(String eMail2)
  {
    properties.setProperty("eMail2", eMail2);
  }

  /**
   * Standard getter for EMail2 tag.
   *
   * @return the EMail2 value
   */
  public String getEMail2()
  {
    return properties.getProperty("eMail2");
  }

  /**
   * Standard setter for Login tag.
   *
   * @param login the new login
   */
  public void setLogin(String login)
  {
    properties.setProperty("login", login);
  }

  /**
   * Standard getter for Login tag.
   *
   * @return the Login value
   */
  public String getLogin()
  {
    return properties.getProperty("login");
  }

  /**
   * Standard setter for DstngshdName tag.
   *
   * @param dstngshdName the new dstngshd name
   */
  public void setDstngshdName(String dstngshdName)
  {
    properties.setProperty("dstngshdName", dstngshdName);
  }

  /**
   * Standard getter for DstngshdName tag.
   *
   * @return the DstngshdName value
   */
  public String getDstngshdName()
  {
    return properties.getProperty("dstngshdName");
  }

  /**
   * Standard setter for CboTimeZone tag.
   *
   * @param cboTimeZone the new cbo time zone
   */
  public void setCboTimeZone(String cboTimeZone)
  {
    properties.setProperty("cboTimeZone", cboTimeZone);
  }

  /**
   * Standard getter for CboTimeZone tag.
   *
   * @return the CboTimeZone value
   */
  public String getCboTimeZone()
  {
    return properties.getProperty("cboTimeZone");
  }

  /**
   * Standard setter for ValidTimeFrom tag.
   *
   * @param validTimeFrom the new valid time from
   */
  public void setValidTimeFrom(String validTimeFrom)
  {
    properties.setProperty("validTimeFrom", validTimeFrom);
  }

  /**
   * Standard getter for ValidTimeFrom tag.
   *
   * @return the ValidTimeFrom value
   */
  public String getValidTimeFrom()
  {
    return properties.getProperty("validTimeFrom");
  }

  /**
   * Standard setter for ValidTimeTo tag.
   *
   * @param validTimeTo the new valid time to
   */
  public void setValidTimeTo(String validTimeTo)
  {
    properties.setProperty("validTimeTo", validTimeTo);
  }

  /**
   * Standard getter for ValidTimeTo tag.
   *
   * @return the ValidTimeTo value
   */
  public String getValidTimeTo()
  {
    return properties.getProperty("validTimeTo");
  }

  /**
   * Standard setter for CaleName tag.
   *
   * @param caleName the new cale name
   */
  public void setCaleName(String caleName)
  {
    properties.setProperty("caleName", caleName);
  }

  /**
   * Standard getter for CaleName tag.
   *
   * @return the CaleName value
   */
  public String getCaleName()
  {
    return (properties.getProperty("caleName"));
  }

  /**
   * Standard setter for CaleKeyName tag.
   *
   * @param caleKeyName the new cale key name
   */
  public void setCaleKeyName(String caleKeyName)
  {
    properties.setProperty("caleKeyName", caleKeyName);
  }

  /**
   * Standard getter for CaleKeyName tag.
   *
   * @return the CaleKeyName value
   */
  public String getCaleKeyName()
  {
    return (properties.getProperty("caleKeyName"));
  }

  /**
   * Standard setter for Active.
   *
   * @param active the new active
   */
  public void setActive(Integer active)
  {
    properties.setProperty("active", active.toString());
  }

  /**
   * Standard getter for Active.
   *
   * @return the Active value
   */
  public Integer getActive()
  {
    return Integer.parseInt(properties.getProperty("active"));
  }

  /**
   * Standard setter for KDCIgnoreSSO.
   *
   * @param kDCIgnoreSSO the new KDC ignore SSO
   */
  public void setKDCIgnoreSSO(Integer kDCIgnoreSSO)
  {
    properties.setProperty("kDCIgnoreSSO", kDCIgnoreSSO.toString());
  }

  /**
   * Standard getter for KDCIgnoreSSO.
   *
   * @return the KDCIgnoreSSO value
   */
  public Integer getKDCIgnoreSSO()
  {
    return Integer.parseInt(properties.getProperty("kDCIgnoreSSO"));
  }

  /**
   * Standard setter for ldap.
   *
   * @param ldap the ldap value to set
   */
  public void setldap(Integer ldap)
  {
    properties.setProperty("ldap", ldap.toString());
  }

  /**
   * Standard getter for ldap.
   *
   * @return the ldap value
   */
  public Integer getldap()
  {
    return Integer.parseInt(properties.getProperty("ldap"));
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setstate(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state value
   */
  public Integer getstate()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for Locked.
   *
   * @param locked the new locked
   */
  public void setLocked(Integer locked)
  {
    properties.setProperty("locked", locked.toString());
  }

  /**
   * Standard getter for Locked.
   *
   * @return the Locked value
   */
  public Integer getLocked()
  {
    return Integer.parseInt(properties.getProperty("locked"));
  }

  /**
   * Standard setter for PwdChange.
   *
   * @param pwdChange the new pwd change
   */
  public void setPwdChange(Integer pwdChange)
  {
    properties.setProperty("pwdChange", pwdChange.toString());
  }

  /**
   * Standard getter for PwdChange.
   *
   * @return the PwdChange value
   */
  public Integer getPwdChange()
  {
    return Integer.parseInt(properties.getProperty("pwdChange"));
  }

  /**
   * Standard setter for PwdNeverExpire.
   *
   * @param pwdNeverExpire the new pwd never expire
   */
  public void setPwdNeverExpire(Integer pwdNeverExpire)
  {
    properties.setProperty("pwdNeverExpire", pwdNeverExpire.toString());
  }

  /**
   * Standard getter for PwdNeverExpire.
   *
   * @return the PwdNeverExpire value
   */
  public Integer getPwdNeverExpire()
  {
    return Integer.parseInt(properties.getProperty("pwdNeverExpire"));
  }

  /**
   * Standard setter for IgnoreSSO.
   *
   * @param ignoreSSO the new ignore SSO
   */
  public void setIgnoreSSO(Integer ignoreSSO)
  {
    properties.setProperty("ignoreSSO", ignoreSSO.toString());
  }

  /**
   * Standard getter for IgnoreSSO.
   *
   * @return the IgnoreSSO value
   */
  public Integer getIgnoreSSO()
  {
    return Integer.parseInt(properties.getProperty("ignoreSSO"));
  }

  /**
   * Standard setter for PwdMustChange.
   *
   * @param pwdMustChange the new pwd must change
   */
  public void setPwdMustChange(Integer pwdMustChange)
  {
    properties.setProperty("pwdMustChange", pwdMustChange.toString());
  }

  /**
   * Standard getter for PwdMustChange.
   *
   * @return the PwdMustChange value
   */
  public Integer getPwdMustChange()
  {
    return Integer.parseInt(properties.getProperty("pwdMustChange"));
  }

  /**
   * Standard setter for Ldap.
   *
   * @param ldap the new ldap
   */
  public void setLdap(Integer ldap)
  {
    properties.setProperty("ldap", ldap.toString());
  }

  /**
   * Standard getter for Ldap.
   *
   * @return the Ldap value
   */
  public Integer getLdap()
  {
    return Integer.parseInt(properties.getProperty("ldap"));
  }

  /**
   * Standard setter for ValidTime.
   *
   * @param validTime the new valid time
   */
  public void setValidTime(Integer validTime)
  {
    properties.setProperty("validTime", validTime.toString());
  }

  /**
   * Standard getter for ValidTime.
   *
   * @return the ValidTime value
   */
  public Integer getValidTime()
  {
    return Integer.parseInt(properties.getProperty("validTime"));
  }

  /**
   * Standard setter for MultiLogon.
   *
   * @param multiLogon the new multi logon
   */
  public void setMultiLogon(Integer multiLogon)
  {
    properties.setProperty("multiLogon", multiLogon.toString());
  }

  /**
   * Standard getter for MultiLogon.
   *
   * @return the MultiLogon value
   */
  public Integer getMultiLogon()
  {
    return Integer.parseInt(properties.getProperty("multiLogon"));
  }

  /**
   * Standard setter for EHRefresh.
   *
   * @param eHRefresh the new EH refresh
   */
  public void setEHRefresh(Integer eHRefresh)
  {
    properties.setProperty("eHRefresh", eHRefresh.toString());
  }

  /**
   * Standard getter for EHRefresh.
   *
   * @return the EHRefresh value
   */
  public Integer getEHRefresh()
  {
    return Integer.parseInt(properties.getProperty("eHRefresh"));
  }

  /**
   * Standard setter for ErrorCnt.
   *
   * @param errorCnt the new error cnt
   */
  public void setErrorCnt(Integer errorCnt)
  {
    properties.setProperty("errorCnt", errorCnt.toString());
  }

  /**
   * Standard getter for ErrorCnt.
   *
   * @return the ErrorCnt value
   */
  public Integer getErrorCnt()
  {
    return Integer.parseInt(properties.getProperty("errorCnt"));
  }
}
