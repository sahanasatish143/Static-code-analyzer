package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARAAttrFactory
{
  public VARAAttr getDefaultVARAAttr();
  public VARAAttr parseVARAAttrFromSource();
}
