/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.DynValues;

/**
 * Represents a single task block of an Automic JobP object job structure.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class Task
{
  Properties properties;
  private TaskCheckpoint checkpoint;
  private TaskAfter after;
  private TaskWhen when;
  private TaskConditions preconditions;
  private ArrayList<TaskPredecessor> predecessors;
  private TaskRunTime runtime;
  private TaskResult result;
  private DynValues dynvalues;
  private TaskCit CIT;
  private TaskCalendars calendars;
  private TaskConditions postconditions;
  private TaskExternal external;

  /**
   * Constructor to build a default Runtime object.
   */
  public Task()
  {
    this.properties = new Properties();
    this.predecessors = new ArrayList<TaskPredecessor>();
    this.preconditions = null;
    this.postconditions = null;
    this.calendars = null;
    this.after = null;
    this.when = null;
    this.runtime = null;
    this.result = null;
    this.dynvalues = null;
    this.CIT = null;
    this.external = null;
    this.setAlias("");
    this.setBranchType(0);
    this.setCol(1);
    this.setLnr(1);
    this.setOtype("");
    this.setObject("");
    this.setParentAlias("");
    this.setParentObject("");
    this.setRow(1);
    this.setText2("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the TaskFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public Task(Properties properties)
  {
    this.properties = properties;
    this.predecessors = new ArrayList<TaskPredecessor>();
    this.preconditions = null;
    this.postconditions = null;
    this.calendars = null;
    this.after = null;
    this.when = null;
    this.runtime = null;
    this.result = null;
    this.dynvalues = null;
    this.CIT = null;
    this.external = null;

  }

  /**
   * Standard setter for Alias
   *
   * @param alias the Alias value to set
   */
  public void setAlias(String alias)
  {
    properties.setProperty("Alias", alias);
  }

  /**
   * Standard getter for Alias
   *
   * @returns the Alias value
   */
  public String getAlias()
  {
    return properties.getProperty("Alias");
  }

  /**
   * Standard setter for BranchType
   *
   * @param branchType the BranchType value to set
   */
  public void setBranchType(Integer branchType)
  {
    properties.setProperty("BranchType", branchType.toString());
  }

  /**
   * Standard getter for BranchType
   *
   * @returns the BranchType value
   */
  public Integer getBranchType()
  {
    return Integer.parseInt(properties.getProperty("BranchType"));
  }

  /**
   * Standard setter for Col
   *
   * @param col the Col value to set
   */
  public void setCol(Integer col)
  {
    properties.setProperty("Col", col.toString());
  }

  /**
   * Standard getter for Col
   *
   * @returns the Col value
   */
  public Integer getCol()
  {
    return Integer.parseInt(properties.getProperty("Col"));
  }

  /**
   * Standard setter for Lnr
   *
   * @param lnr the Lnr value to set
   */
  public void setLnr(Integer lnr)
  {
    properties.setProperty("Lnr", lnr.toString());
  }

  /**
   * Standard getter for Lnr
   *
   * @returns the Lnr value
   */
  public Integer getLnr()
  {
    return Integer.parseInt(properties.getProperty("Lnr"));
  }

  /**
   * Standard setter for Otype
   *
   * @param otype the Otype value to set
   */
  public void setOtype(String otype)
  {
    properties.setProperty("Otype", otype);
  }

  /**
   * Standard getter for Otype
   *
   * @returns the Otype value
   */
  public String getOtype()
  {
    return properties.getProperty("Otype");
  }

  /**
   * Standard setter for Object
   *
   * @param object the Object value to set
   */
  public void setObject(String object)
  {
    properties.setProperty("Object", object);
  }

  /**
   * Standard getter for Object
   *
   * @returns the Object value
   */
  public String getObject()
  {
    return properties.getProperty("Object");
  }

  /**
   * Standard setter for ParentAlias
   *
   * @param parentAlias the ParentAlias value to set
   */
  public void setParentAlias(String parentAlias)
  {
    properties.setProperty("ParentAlias", parentAlias);
  }

  /**
   * Standard getter for ParentAlias
   *
   * @returns the ParentAlias value
   */
  public String getParentAlias()
  {
    return properties.getProperty("ParentAlias");
  }

  /**
   * Standard setter for ParentObject
   *
   * @param parentObject the ParentObject value to set
   */
  public void setParentObject(String parentObject)
  {
    properties.setProperty("ParentObject", parentObject);
  }

  /**
   * Standard getter for ParentObject
   *
   * @returns the ParentObject value
   */
  public String getParentObject()
  {
    return properties.getProperty("ParentObject");
  }

  /**
   * Standard setter for Row
   *
   * @param row the Row value to set
   */
  public void setRow(Integer row)
  {
    properties.setProperty("Row", row.toString());
  }

  /**
   * Standard getter for Row
   *
   * @returns the Row value
   */
  public Integer getRow()
  {
    return Integer.parseInt(properties.getProperty("Row"));
  }

  /**
   * Standard setter for Text2
   *
   * @param text2 the state value to set
   */
  public void setText2(String text2)
  {
    properties.setProperty("Text2", text2);
  }

  /**
   * Standard getter for Text2
   *
   * @returns the Text2 value
   */
  public String getText2()
  {
    return properties.getProperty("Text2");
  }

  /**
   * Adds a SyncRefRecord to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void addCalendar(TaskCalendar calendar)
  {
    calendars.addCalendar(calendar);
  }

  /**
   * Adds a SyncRefRecord to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void addPredecessor(TaskPredecessor predecessor)
  {
    predecessors.add(predecessor);
  }

  /**
   * Adds a SyncRefRecord to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void addPrecondition(TaskCondition condition)
  {
    preconditions.add(condition);
  }

  /**
   * Adds a SyncRefRecord to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void addPostcondition(TaskCondition condition)
  {
    postconditions.add(condition);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the SyncRefRecords in the collection
   */
  public Iterator<TaskCalendar> getCalendarsIterator()
  {
    return this.calendars.getCalendarsIterator();
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the SyncRefRecords in the collection
   */
  public Iterator<TaskPredecessor> getPredecessorsIterator()
  {
    return this.predecessors.iterator();
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the SyncRefRecords in the collection
   */
  public Iterator<TaskCondition> getPreconditionsIterator()
  {
    return this.preconditions.iterator();
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the SyncRefRecords in the collection
   */
  public Iterator<TaskCondition> getPostconditionsIterator()
  {
    return this.postconditions.iterator();
  }

  /**
   * Standard getter for checkpoint.
   *
   * @return the checkpoint
   */
  public TaskCheckpoint getCheckpoint()
  {
    return checkpoint;
  }

  /**
   * Standard setter for checkpoint
   *
   * @param checkpoint the checkpoint to set
   */
  public void setCheckpoint(TaskCheckpoint checkpoint)
  {
    this.checkpoint = checkpoint;
  }

  /**
   * Standard getter for after.
   *
   * @return the after
   */
  public TaskAfter getAfter()
  {
    return after;
  }

  /**
   * Standard setter for after
   *
   * @param after the after to set
   */
  public void setAfter(TaskAfter after)
  {
    this.after = after;
  }

  /**
   * Standard getter for when.
   *
   * @return the when
   */
  public TaskWhen getWhen()
  {
    return when;
  }

  /**
   * Standard setter for when
   *
   * @param when the when to set
   */
  public void setWhen(TaskWhen when)
  {
    this.when = when;
  }

  /**
   * Standard getter for runtime.
   *
   * @return the runtime
   */
  public TaskRunTime getRuntime()
  {
    return runtime;
  }

  /**
   * Standard setter for runtime
   *
   * @param runtime the runtime to set
   */
  public void setRuntime(TaskRunTime runtime)
  {
    this.runtime = runtime;
  }

  /**
   * Standard getter for result.
   *
   * @return the result
   */
  public TaskResult getResult()
  {
    return result;
  }

  /**
   * Standard setter for result
   *
   * @param result the result to set
   */
  public void setResult(TaskResult result)
  {
    this.result = result;
  }

  /**
   * Standard getter for dynvalues.
   *
   * @return the dynvalues
   */
  public DynValues getDynvalues()
  {
    return dynvalues;
  }

  /**
   * Standard setter for dynvalues
   *
   * @param dynvalues the dynvalues to set
   */
  public void setDynvalues(DynValues dynvalues)
  {
    this.dynvalues = dynvalues;
  }

  /**
   * Standard getter for cIT.
   *
   * @return the cIT
   */
  public TaskCit getCIT()
  {
    return CIT;
  }

  /**
   * Standard setter for cIT
   *
   * @param cIT the cIT to set
   */
  public void setCIT(TaskCit cIT)
  {
    CIT = cIT;
  }

  /**
   * Standard getter for external.
   *
   * @return the external
   */
  public TaskExternal getExternal()
  {
    return external;
  }

  /**
   * Standard setter for external
   *
   * @param external the external to set
   */
  public void setExternal(TaskExternal external)
  {
    this.external = external;
  }
  /**
   * Standard getter for preconditions.
   *
   * @return the preconditions
   */
  public TaskConditions getPreconditions()
  {
    return preconditions;
  }

  /**
   * Standard setter for preconditions
   *
   * @param preconditions the preconditions to set
   */
  public void setPreconditions(TaskConditions preconditions)
  {
    this.preconditions = preconditions;
  }
  /**
   * Standard getter for postconditions.
   *
   * @return the postconditions
   */
  public TaskConditions getPostconditions()
  {
    return postconditions;
  }

  /**
   * Standard setter for postconditions
   *
   * @param postconditions the postconditions to set
   */
  public void setPostconditions(TaskConditions postconditions)
  {
    this.postconditions = postconditions;
  }
  /**
   * Standard getter for calendars.
   *
   * @return the calendars
   */
  public TaskCalendars getCalendars()
  {
    return calendars;
  }

  /**
   * Standard setter for calendars
   *
   * @param calendars the calendars to set
   */
  public void setCalendars(TaskCalendars calendars)
  {
    this.calendars = calendars;
  }
}