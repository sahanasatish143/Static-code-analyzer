/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

/**
 * The Class Connection.
 */
public class Connection extends AutomicExecutableObject
{

  /** The connection cit. */
  private ConnectionCit connectionCit;
  
  /** The connection SQL. */
  private ConnectionSQL connectionSQL; 
  
  /** The connection attr. */
  private ConnectionAttribute connectionAttr;
  
  /** The connection HTTP. */
  private ConnectionHTTP connectionHTTP;
  
  /** The connection RFC. */
  private ConnectionRFC connectionRFC;

  
  /**
   * Instantiates a new connection.
   */
  public Connection()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new connection.
   *
   * @param properties the properties
   */
  public Connection(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Sets the connection cit.
   *
   * @param connectionCit the new connection cit
   */
  public void setConnectionCit(ConnectionCit connectionCit)
  {
    this.connectionCit = connectionCit;
  }

  /**
   * Gets the connection cit.
   *
   * @return the connection cit
   */
  public ConnectionCit getConnectionCit()
  {
    return this.connectionCit;
  }
  
  /**
   * Sets the connection SQL.
   *
   * @param connectionSQL the new connection SQL
   */
  public void setConnectionSQL(ConnectionSQL connectionSQL)
  {
    this.connectionSQL = connectionSQL;
  }

  
  /**
   * Gets the connection SQL.
   *
   * @return the connection SQL
   */
  public ConnectionSQL getConnectionSQL()
  {
    return this.connectionSQL;
  }
  
  /**
   * Sets the connection attribute.
   *
   * @param connectionAttr the new connection attribute
   */
  public void setConnectionAttribute(ConnectionAttribute connectionAttr)
  {
    this.connectionAttr = connectionAttr;
  }
  /**
   * Gets the connection attribute.
   *
   * @return the connection attribute
   */
  public ConnectionAttribute getConnectionAttribute()
  {
    return this.connectionAttr;
  }
  
  /**
   * Sets the connection HTTP.
   *
   * @param connectionHTTP the new connection HTTP
   */
  public void setConnectionHTTP(ConnectionHTTP connectionHTTP)
  {
    this.connectionHTTP = connectionHTTP;
  }

  
  
  /**
   * Gets the connection HTTP.
   *
   * @return the connection HTTP
   */
  public ConnectionHTTP getConnectionHTTP()
  {
    return this.connectionHTTP;
  }

  /**
   * Sets the connection RFC.
   *
   * @param connectionRFC the new connection RFC
   */
  public void setConnectionRFC(ConnectionRFC connectionRFC)
  {
    this.connectionRFC = connectionRFC;
  }

  
  /**
   * Gets the connection RFC.
   *
   * @return the connection RFC
   */
  public ConnectionRFC getConnectionRFC()
  {
    return this.connectionRFC;
  }

}
