/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

/**
 * The Class Citcont.
 *
 * @author sahana;sahana.b.s@capgemini.com
 * @version 1.0
 * @since 1.0
 */
public class Citcont
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new citcont.
   */
  public Citcont()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new citcont.
   *
   * @param properties the properties
   */
  public Citcont(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the agent name.
   *
   * @param agentname the new agent name
   */
  public void setAgentName(String agentname)
  {
    properties.setProperty("agentname", agentname);
  }

  /**
   * Gets the agent name.
   *
   * @return the agent name
   */
  public String getAgentName()
  {
    return properties.getProperty("agentname");
  }

  /**
   * Sets the job type.
   *
   * @param jobtype the new job type
   */
  public void setJobType(String jobtype)
  {
    properties.setProperty("jobtype", jobtype);
  }

  /**
   * Gets the JobType.
   *
   * @return the JobType
   */
  public String getJobType()
  {
    return properties.getProperty("jobtype");
  }

  /**
   * Sets the text.
   *
   * @param text the new text
   */
  public void setText(String text)
  {
    properties.setProperty("text", text);
  }

  /**
   * Gets the text.
   *
   * @return the text
   */
  public String getText()
  {
    return properties.getProperty("text");
  }

  public void setCit(CitDefinition parseMembersFromSource)
  {
    properties.getProperty("cit");
  }

}
