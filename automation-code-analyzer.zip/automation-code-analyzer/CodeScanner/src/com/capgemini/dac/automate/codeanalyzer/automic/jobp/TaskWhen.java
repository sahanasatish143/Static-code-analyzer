/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * 
 * 
 * @author
 * @version 1.0
 * @since 1.8
 */
public class TaskWhen
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public TaskWhen()
  {
    this.properties = new Properties();
    this.setChkWhenExec(0);
    this.setLtstEnd(0);
    this.setLtstEndDays(0);
    this.setLtstEndTime("00:00");
    this.setLtstSt(0);
    this.setLtstStDays(0);
    this.setLtstStTime("00:00");
    this.setLtstTimeTZ("");
    this.setWCTypeAND(1);
    this.setWCTypeOR(0);
    this.setWElseA(0);
    this.setWElseH(1);
    this.setWElseS(0);
    this.setWElseX(0);
    this.setWhenExecute("");
    this.setWtimOn(0);
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskWhen(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for ChkWhenExec
   *
   * @param chkWhenExec the ChkWhenExec value to set
   */
  public void setChkWhenExec(Integer chkWhenExec)
  {
    properties.setProperty("ChkWhenExec", chkWhenExec.toString());
  }

  /**
   * Standard getter for ChkWhenExec
   *
   * @returns the ChkWhenExec value
   */
  public Integer getChkWhenExec()
  {
    return Integer.parseInt(properties.getProperty("ChkWhenExec"));
  }

  /**
   * Standard setter for LtstEnd
   *
   * @param ltstEnd the LtstEnd value to set
   */
  public void setLtstEnd(Integer ltstEnd)
  {
    properties.setProperty("LtstEnd", ltstEnd.toString());
  }

  /**
   * Standard getter for LtstEnd
   *
   * @returns the LtstEnd value
   */
  public Integer getLtstEnd()
  {
    return Integer.parseInt(properties.getProperty("LtstEnd"));
  }

  /**
   * Standard setter for LtstEndDays
   *
   * @param ltstEndDays the LtstEndDays value to set
   */
  public void setLtstEndDays(Integer ltstEndDays)
  {
    properties.setProperty("LtstEndDays", ltstEndDays.toString());
  }

  /**
   * Standard getter for LtstEndDays
   *
   * @returns the LtstEndDays value
   */
  public Integer getLtstEndDays()
  {
    return Integer.parseInt(properties.getProperty("LtstEndDays"));
  }

  /**
   * Standard setter for LtstEndTime
   *
   * @param ltstEndTime the LtstEndTime value to set
   */
  public void setLtstEndTime(String ltstEndTime)
  {
    properties.setProperty("LtstEndTime", ltstEndTime);
  }

  /**
   * Standard getter for LtstEndTime
   *
   * @returns the LtstEndTime value
   */
  public String getLtstEndTime()
  {
    return properties.getProperty("LtstEndTime");
  }

  /**
   * Standard setter for LtstSt
   *
   * @param ltstSt the LtstSt value to set
   */
  public void setLtstSt(Integer ltstSt)
  {
    properties.setProperty("LtstSt", ltstSt.toString());
  }

  /**
   * Standard getter for LtstSt
   *
   * @returns the LtstSt value
   */
  public Integer getLtstSt()
  {
    return Integer.parseInt(properties.getProperty("LtstSt"));
  }

  /**
   * Standard setter for LtstStDays
   *
   * @param ltstStDays the LtstStDays value to set
   */
  public void setLtstStDays(Integer ltstStDays)
  {
    properties.setProperty("LtstStDays", ltstStDays.toString());
  }

  /**
   * Standard getter for LtstStDays
   *
   * @returns the LtstStDays value
   */
  public Integer getLtstStDays()
  {
    return Integer.parseInt(properties.getProperty("LtstStDays"));
  }

  /**
   * Standard setter for LtstStTime
   *
   * @param ltstStTime the LtstStTime value to set
   */
  public void setLtstStTime(String ltstStTime)
  {
    properties.setProperty("LtstStTime", ltstStTime);
  }

  /**
   * Standard getter for LtstStTime
   *
   * @returns the LtstStTime value
   */
  public String getLtstStTime()
  {
    return properties.getProperty("LtstStTime");
  }

  /**
   * Standard setter for LtstTimeTZ
   *
   * @param ltstTimeTZ the LtstTimeTZ value to set
   */
  public void setLtstTimeTZ(String ltstTimeTZ)
  {
    properties.setProperty("LtstTimeTZ", ltstTimeTZ);
  }

  /**
   * Standard getter for LtstTimeTZ
   *
   * @returns the LtstTimeTZ value
   */
  public String getLtstTimeTZ()
  {
    return properties.getProperty("LtstTimeTZ");
  }

  /**
   * Standard setter for WCTypeAND
   *
   * @param wCTypeAND the WCTypeAND value to set
   */
  public void setWCTypeAND(Integer wCTypeAND)
  {
    properties.setProperty("WCTypeAND", wCTypeAND.toString());
  }

  /**
   * Standard getter for WCTypeAND
   *
   * @returns the WCTypeAND value
   */
  public Integer getWCTypeAND()
  {
    return Integer.parseInt(properties.getProperty("WCTypeAND"));
  }

  /**
   * Standard setter for WCTypeOR
   *
   * @param wCTypeOR the WCTypeOR value to set
   */
  public void setWCTypeOR(Integer wCTypeOR)
  {
    properties.setProperty("WCTypeOR", wCTypeOR.toString());
  }

  /**
   * Standard getter for WCTypeOR
   *
   * @returns the WCTypeOR value
   */
  public Integer getWCTypeOR()
  {
    return Integer.parseInt(properties.getProperty("WCTypeOR"));
  }

  /**
   * Standard setter for WElseA
   *
   * @param wElseA the WElseA value to set
   */
  public void setWElseA(Integer wElseA)
  {
    properties.setProperty("WElseA", wElseA.toString());
  }

  /**
   * Standard getter for WElseA
   *
   * @returns the WElseA value
   */
  public Integer getWElseA()
  {
    return Integer.parseInt(properties.getProperty("WElseA"));
  }

  /**
   * Standard setter for WElseH
   *
   * @param wElseH the WElseH value to set
   */
  public void setWElseH(Integer wElseH)
  {
    properties.setProperty("WElseH", wElseH.toString());
  }

  /**
   * Standard getter for WElseH
   *
   * @returns the WElseH value
   */
  public Integer getWElseH()
  {
    return Integer.parseInt(properties.getProperty("WElseH"));
  }

  /**
   * Standard setter for WElseS
   *
   * @param wElseS the WElseS value to set
   */
  public void setWElseS(Integer wElseS)
  {
    properties.setProperty("WElseS", wElseS.toString());
  }

  /**
   * Standard getter for WElseS
   *
   * @returns the WElseS value
   */
  public Integer getWElseS()
  {
    return Integer.parseInt(properties.getProperty("WElseS"));
  }

  /**
   * Standard setter for WElseX
   *
   * @param wElseX the WElseX value to set
   */
  public void setWElseX(Integer wElseX)
  {
    properties.setProperty("WElseX", wElseX.toString());
  }

  /**
   * Standard getter for WElseX
   *
   * @returns the WElseX value
   */
  public Integer getWElseX()
  {
    return Integer.parseInt(properties.getProperty("WElseX"));
  }

  /**
   * Standard setter for WhenExecute
   *
   * @param whenExecute the WhenExecute value to set
   */
  public void setWhenExecute(String whenExecute)
  {
    properties.setProperty("WhenExecute", whenExecute);
  }

  /**
   * Standard getter for WhenExecute
   *
   * @returns the WhenExecute value
   */
  public String getWhenExecute()
  {
    return properties.getProperty("WhenExecute");
  }

  /**
   * Standard setter for WtimOn
   *
   * @param wtimOn the WtimOn value to set
   */
  public void setWtimOn(Integer wtimOn)
  {
    properties.setProperty("WtimOn", wtimOn.toString());
  }

  /**
   * Standard getter for WtimOn
   *
   * @returns the WtimOn value
   */
  public Integer getWtimOn()
  {
    return Integer.parseInt(properties.getProperty("WtimOn"));
  }
}