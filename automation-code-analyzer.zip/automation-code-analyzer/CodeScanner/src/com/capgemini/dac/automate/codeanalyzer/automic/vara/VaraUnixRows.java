package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VaraUnixRows
{
  /** The properties. */
  Properties properties;
  
  /**
   * Instantiates a new vara UNIX rows.
   */
  public VaraUnixRows()
  {
    this.properties = new Properties();
    this.setUNIX_Columns("");
    this.setLnr(1);
    this.setIdnr(5555545);
    this.setUNIXCommand("");
    this.setUNIXOVTLnr(1);
    this.setUNIXOs("");
    this.setUNIXVersion("");
  }
  
  /**
   * Instantiates a new vara UNIX rows.
   *
   * @param properties the properties
   */
  public VaraUnixRows(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Sets the WINDOW S columns.
   *
   * @param archiveKey1 the new WINDOW S columns
   */
  public void setUNIX_Columns(String archiveKey1)
  {
    properties.setProperty("UNIX_Columns", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the WINDOW S columns
   * @returns the When ArchiveKey1
   */
  public String getUNIX_Columns()
  {
    return properties.getProperty("UNIX_Columns");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param archiveKey2 the new UNIX command
   */
  public void setUNIXCommand(String archiveKey2)
  {
    properties.setProperty("UNIX_Command", archiveKey2);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the name
   * @returns the When ArchiveKey1
   */
  public String getName()
  {
    return properties.getProperty("UNIX_Command");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param hw the new lnr
   */
  public void setLnr(Integer hw)
  {
    properties.setProperty("UNIX_Lnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the lnr
   * @returns the When ArchiveKey1
   */
  public String getLnr()
  {
    return properties.getProperty("UNIX_Lnr");
  }
  
  /**
   * Sets the idnr.
   *
   * @param hw the new idnr
   */
  public void setIdnr(Integer hw)
  {
    properties.setProperty("UNIX_OH_Idnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the idnr
   * @returns the When ArchiveKey1
   */
  public String getIdnr()
  {
    return properties.getProperty("UNIX_OH_Idnr");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param icon the new UNIX os
   */
  public void setUNIXOs(String icon)
  {
    properties.setProperty("UNIX_OS", icon);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the UNIX os
   * @returns the When ArchiveKey1
   */
  public String getUNIXOs()
  {
    return properties.getProperty("UNIX_OS");
  }
  
  /**
   * Sets the UNIXOVT lnr.
   *
   * @param hw the new UNIXOVT lnr
   */
  public void setUNIXOVTLnr(Integer hw)
  {
    properties.setProperty("UNIX_OVT_Lnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the UNIXOVT lnr
   * @returns the When ArchiveKey1
   */
  public String getUNIXOVTLnr()
  {
    return properties.getProperty("UNIX_OVT_Lnr");
  }
  
  /**
   * Sets the UNIX version.
   *
   * @param icon the new UNIX version
   */
  public void setUNIXVersion(String icon)
  {
    properties.setProperty("UNIX_Version", icon);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the UNIX version
   * @returns the When ArchiveKey1
   */
  public String getUNIXVersion()
  {
    return properties.getProperty("UNIX_Version");
  }

}
