/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

/**
 * This class represents an VARADefinition object,
 *  defines types of VARAS
 * 
 * @author sahana s ;sahana.b.s@capgemini.com
 * @version 1.0
 * @since 1.8
 */
public class VARADefinition
{
  
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA definition.
   */
  public VARADefinition()
  {
    this.properties = new Properties();
    this.setState(1);
  }

  /**
   * Instantiates a new VARA definition.
   *
   * @param properties the properties
   */
  public VARADefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Sets the variables.
   *
   * @param varaStatic the new variables
   */
  public void setVariables(VARAStatic varaStatic)
  {
    properties.getProperty("Variables");
  }

  /**
   * Sets the backend.
   *
   * @param varaBack the new backend
   */
  public void setBackend(VARABackend varaBack)
  {
    properties.getProperty("BACKEND");
  }

  /**
   * Sets the exec.
   *
   * @param varaExec the new exec
   */
  public void setExec(VARAExec varaExec)
  {
    properties.getProperty("EXEC");
  }

  /**
   * Sets the file list.
   *
   * @param varafile the new file list
   */
  public void setFileList(VARAFilelist varafile)
  {
    properties.getProperty("FILELIST");
  }

  /**
   * Sets the multi.
   *
   * @param varamulti the new multi
   */
  public void setMulti(VARAMulti varamulti)
  {
    properties.getProperty("MULTI");
  }

  /**
   * Sets the sql.
   *
   * @param varaSql the new sql
   */
  public void setSql(VARASQL varaSql)
  {
    properties.getProperty("SQL");
  }

  /**
   * Sets the sqli.
   *
   * @param varaSqli the new sqli
   */
  public void setSqli(VARASQLI varaSqli)
  {
    properties.getProperty("SQLI");
  }

  /**
   * Sets the xml.
   *
   * @param varaXML the new xml
   */
  public void setXML(VARAEventXMLDefinition varaXML)
  {
    properties.getProperty("XML");
  }

}
