package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionCitFactory
{
  public ConnectionCit getDefaultConnectionCit();
  public ConnectionCit parseConnectionCitFromSource();
}
