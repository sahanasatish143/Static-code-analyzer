package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class Tabs implements Iterable<VaraTab>
{
 Properties properties;
  
  /** The rows. */
  private ArrayList<VaraTab> tabs;
  public Tabs(Properties properties)
  {
    this.properties = properties;
    this.tabs = new ArrayList<VaraTab>(); 
  }
  public Tabs()
  {
    this.properties = new Properties();
    this.tabs = new ArrayList<VaraTab>(); 
  }
  public void add(VaraTab members)
  {
    tabs.add(members);
  }

  @Override
  public Iterator<VaraTab> iterator()
  {
   
    return tabs.iterator();
  }

}
