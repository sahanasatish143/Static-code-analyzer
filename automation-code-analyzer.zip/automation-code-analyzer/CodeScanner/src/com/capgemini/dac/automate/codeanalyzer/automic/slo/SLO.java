/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.slo;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

/**
 * This class represents an Automic SLO object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class SLO extends AutomicExecutableObject
{
  private SLOFulfillment sloFulfillment;
  private SLOSelection sloSelection;
  private SLOAttribute sloAttribute;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * SLO object in the context of an editor or in a code translator.
   */
  public SLO()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the SLOFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for SLO.
   * @see SLOFactory
   */
  public SLO(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for SLOFulfillment
   *
   * @return the SLOFulfillment value
   */
  public SLOFulfillment getSLOFulfillment()
  {
    return sloFulfillment;
  }

  /**
   * Standard setter for SLOFulfillment
   *
   * @param SLOFulfillment the SLOFulfillment value to set
   */
  public void setSLOFulfillment(SLOFulfillment sloFulfillment)
  {
    this.sloFulfillment = sloFulfillment;
  }

  /**
   * Standard getter for SLOSelection
   *
   * @return the SLOSelection value
   */
  public SLOSelection getSLOSelection()
  {
    return sloSelection;
  }

  /**
   * Standard setter for SLOSelection
   *
   * @param SLOSelection the SLOSelection value to set
   */
  public void setSLOSelection(SLOSelection sloSelection)
  {
    this.sloSelection = sloSelection;
  }

  /**
   * Standard getter for SLOAttribute
   *
   * @return the SLOAttribute value
   */
  public SLOAttribute getSLOAttribute()
  {
    return sloAttribute;
  }

  /**
   * Standard setter for SLOAttribute
   *
   * @param SLOAttribute the SLOAttribute value to set
   */
  public void setSLOAttribute(SLOAttribute sloAttribute)
  {
    this.sloAttribute = sloAttribute;
  }
}
