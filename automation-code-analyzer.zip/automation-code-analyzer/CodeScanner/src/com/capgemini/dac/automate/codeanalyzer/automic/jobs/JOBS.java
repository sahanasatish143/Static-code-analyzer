/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;
import com.capgemini.dac.automate.codeanalyzer.automic.core.OutputScan;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBS extends AutomicExecutableObject
{
  private JOBSOutputReg jobsOutputReg;
  private JOBSAttribute jobsAttribute;
  private JOBSCITAttribute jobsCITAttribute;
  private JOBSVMSAttribute jobsVMSAttribute;
  private JOBSCIT jobsCIT;
  private JOBSR3Attribute jobsR3Attribute;
  private JOBSR3FormAttribute jobsR3FormAttribute;
  private JOBSPSAttribute jobsPSAttribute;
  private JOBSPSFormAttribute jobsPSFormAttribute;
  private JOBSSIEBELAttribute jobsSIEBELAttribute;
  private JOBSOS400Attribute jobsOS400Attribute;
  private JOBSMVSAttribute jobsMVSAttribute;
  private JOBSOAAttribute jobsOAAttribute;
  private JOBSNSKAttribute jobsNSKAttribute;
  private JOBSMPEAttribute jobsMPEAttribute;
  private JOBSGCOS8Attribute jobsGCOS8Attribute;
  private JOBSBS2000Attribute jobsBS2000Attribute;
  private JOBSWindowsAttribute jobsWindowsAttribute;
  private JOBSUnixAttribute jobsUnixAttribute;
  private JOBSSQLAttribute jobsSQLAttribute;
  private JOBSSQLFormAttribute jobsSQLFormAttribute;
  private AutomicScript jobsScript;
  private AutomicScript jobsPreScript;
  private AutomicScript jobsPostScript;
  private AutomicScript jobsIPostScript;
  private OutputScan outputScan;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBS object in the context of an editor or in a code translator.
   */
  public JOBS()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBS.
   * @see JOBSFactory
   */
  public JOBS(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for JOBSOutputReg
   *
   * @return the JOBSOutputReg value
   */
  public JOBSOutputReg getJOBSOutputReg()
  {
    return jobsOutputReg;
  }

  /**
   * Standard setter for JOBSOutputReg
   *
   * @param JOBSOutputReg the JOBSOutputReg value to set
   */
  public void setJOBSOutputReg(JOBSOutputReg jobsOutputReg)
  {
    this.jobsOutputReg = jobsOutputReg;
  }

  /**
   * Standard getter for JOBSPSAttribute
   *
   * @return the JOBSPSAttribute value
   */
  public JOBSPSAttribute getJOBSPSAttribute()
  {
    return jobsPSAttribute;
  }

  /**
   * Standard setter for JOBSPSAttribute
   *
   * @param JOBSPSAttribute the JOBSPSAttribute value to set
   */
  public void setJOBSPSAttribute(JOBSPSAttribute jobsAttribute)
  {
    this.jobsPSAttribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSPSFormAttribute
   *
   * @return the JOBSPSFormAttribute value
   */
  public JOBSPSFormAttribute getJOBSPSFormAttribute()
  {
    return jobsPSFormAttribute;
  }

  /**
   * Standard setter for JOBSPSFormAttribute
   *
   * @param JOBSPSFormAttribute the JOBSPSFormAttribute value to set
   */
  public void setJOBSPSFormAttribute(JOBSPSFormAttribute jobsAttribute)
  {
    this.jobsPSFormAttribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSR3Attribute
   *
   * @return the JOBSR3Attribute value
   */
  public JOBSR3Attribute getJOBSR3Attribute()
  {
    return jobsR3Attribute;
  }

  /**
   * Standard setter for JOBSR3Attribute
   *
   * @param JOBSR3Attribute the JOBSR3Attribute value to set
   */
  public void setJOBSR3Attribute(JOBSR3Attribute jobsAttribute)
  {
    this.jobsR3Attribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSR3FormAttribute
   *
   * @return the JOBSR3FormAttribute value
   */
  public JOBSR3FormAttribute getJOBSR3FormAttribute()
  {
    return jobsR3FormAttribute;
  }

  /**
   * Standard setter for JOBSR3FormAttribute
   *
   * @param JOBSR3FormAttribute the JOBSR3FormAttribute value to set
   */
  public void setJOBSR3FormAttribute(JOBSR3FormAttribute jobsAttribute)
  {
    this.jobsR3FormAttribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSAttribute
   *
   * @return the JOBSAttribute value
   */
  public JOBSAttribute getJOBSAttribute()
  {
    return jobsAttribute;
  }

  /**
   * Standard setter for JOBSAttribute
   *
   * @param JOBSAttribute the JOBSAttribute value to set
   */
  public void setJOBSAttribute(JOBSAttribute jobsAttribute)
  {
    this.jobsAttribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSUnixAttribute
   *
   * @return the JOBSUnixAttribute value
   */
  public JOBSUnixAttribute getJOBSUnixAttribute()
  {
    return jobsUnixAttribute;
  }

  /**
   * Standard setter for JOBSUnixAttribute
   *
   * @param JOBSUnixAttribute the JOBSUnixAttribute value to set
   */
  public void setJOBSUnixAttribute(JOBSUnixAttribute jobsAttribute)
  {
    this.jobsUnixAttribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSWindowsAttribute
   *
   * @return the JOBSWindowsAttribute value
   */
  public JOBSWindowsAttribute getJOBSWindowsAttribute()
  {
    return jobsWindowsAttribute;
  }

  /**
   * Standard setter for JOBSWindowsAttribute
   *
   * @param JOBSWindowsAttribute the JOBSWindowsAttribute value to set
   */
  public void setJOBSWindowsAttribute(JOBSWindowsAttribute jobsAttribute)
  {
    this.jobsWindowsAttribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSVMSAttribute
   *
   * @return the JOBSVMSAttribute value
   */
  public JOBSVMSAttribute getJOBSVMSAttribute()
  {
    return jobsVMSAttribute;
  }

  /**
   * Standard setter for JOBSVMSAttribute
   *
   * @param JOBSVMSAttribute the JOBSVMSAttribute value to set
   */
  public void setJOBSVMSAttribute(JOBSVMSAttribute jobsAttribute)
  {
    this.jobsVMSAttribute = jobsAttribute;
  }

  /**
   * Standard getter for JOBSCITAttribute
   *
   * @return the JOBSCITAttribute value
   */
  public JOBSCITAttribute getJOBSCITAttribute()
  {
    return jobsCITAttribute;
  }

  /**
   * Standard setter for JOBSCITAttribute
   *
   * @param JOBSCITAttribute the JOBSCITAttribute value to set
   */
  public void setJOBSCITAttribute(JOBSCITAttribute jobsCITAttribute)
  {
    this.jobsCITAttribute = jobsCITAttribute;
  }

  /**
   * Standard getter for JOBSCIT
   *
   * @return the JOBSCIT value
   */
  public JOBSCIT getJOBSCIT()
  {
    return jobsCIT;
  }

  /**
   * Standard setter for JOBSCIT
   *
   * @param JOBSCIT the JOBSCIT value to set
   */
  public void setJOBSCIT(JOBSCIT jobsCIT)
  {
    this.jobsCIT = jobsCIT;
  }

  /**
   * Standard setter for AutomicScript
   *
   * @param AutomicScript the AutomicScript value to set
   */
  public void setScript(AutomicScript script)
  {
    this.jobsScript = script;

  }

  /**
   * Standard getter for AutomicScript
   *
   * @return the AutomicScript value
   */
  public AutomicScript getScript()
  {
    return this.jobsScript;
  }

  /**
   * Standard setter for AutomicScript
   *
   * @param AutomicScript the AutomicScript value to set
   */
  public void setPreScript(AutomicScript script)
  {

    this.jobsPreScript = script;
  }

  /**
   * Standard getter for AutomicScript
   *
   * @return the AutomicScript value
   */
  public AutomicScript getPreScript()
  {
    return this.jobsPreScript;
  }

  /**
   * Sets the out scan.
   *
   * @param outScan the new out scan
   */
  public void setOutScan(OutputScan outScan)
  {
    this.outputScan = outScan;
  }

  /**
   * Gets the out scan.
   *
   * @return the out scan
   */
  public OutputScan getOutScan()
  {
    return this.outputScan;
  }

  /**
   * Standard setter for AutomicScript
   *
   * @param AutomicScript the AutomicScript value to set
   */
  public void setPostScript(AutomicScript script)
  {
    this.jobsPostScript = script;

  }

  /**
   * Standard getter for AutomicScript
   *
   * @return the AutomicScript value
   */
  public AutomicScript getPostScript()
  {
    return this.jobsPostScript;
  }

  /**
   * Standard setter for AutomicScript
   *
   * @param AutomicScript the AutomicScript value to set
   */
  public void setIPostScript(AutomicScript script)
  {
    this.jobsIPostScript = script;

  }

  /**
   * Standard getter for AutomicScript
   *
   * @return the AutomicScript value
   */
  public AutomicScript getIPostScript()
  {
    return this.jobsIPostScript;
  }

  /**
   * Standard getter for JOBSSIEBELAttribute
   *
   * @return the JOBSSIEBELAttribute value
   */
  public JOBSSIEBELAttribute getJOBSSIEBELAttribute()
  {
    return jobsSIEBELAttribute;
  }

  /**
   * Standard setter for JOBSSIEBELAttribute
   *
   * @param JOBSSIEBELAttribute the JOBSSIEBELAttribute value to set
   */
  public void setJOBSSIEBELAttribute(JOBSSIEBELAttribute jobsSIEBELAttribute)
  {
    this.jobsSIEBELAttribute = jobsSIEBELAttribute;
  }

  /**
   * Standard getter for JOBSOS400Attribute
   *
   * @return the JOBSOS400Attribute value
   */
  public JOBSOS400Attribute getJOBSOS400Attribute()
  {
    return jobsOS400Attribute;
  }

  /**
   * Standard setter for JOBSOS400Attribute
   *
   * @param JOBSOS400Attribute the JOBSOS400Attribute value to set
   */
  public void setJOBSOS400Attribute(JOBSOS400Attribute jobsOS400Attribute)
  {
    this.jobsOS400Attribute = jobsOS400Attribute;
  }

  /**
   * Standard getter for JOBSMVSAttribute
   *
   * @return the JOBSMVSAttribute value
   */
  public JOBSMVSAttribute getJOBSMVSAttribute()
  {
    return jobsMVSAttribute;
  }

  /**
   * Standard setter for JOBSAMVSttribute
   *
   * @param JOBSAMVSttribute the JOBSAMVSttribute value to set
   */
  public void setJOBSMVSAttribute(JOBSMVSAttribute jobsMVSAttribute)
  {
    this.jobsMVSAttribute = jobsMVSAttribute;
  }

  /**
   * Standard getter for JOBSOAAttribute
   *
   * @return the JOBSOAAttribute value
   */
  public JOBSOAAttribute getJOBSOAAttribute()
  {
    return jobsOAAttribute;
  }

  /**
   * Standard setter for JOBSOAAttribute
   *
   * @param JOBSOAAttribute the JOBSOAAttribute value to set
   */
  public void setJOBSOAAttribute(JOBSOAAttribute jobsOAAttribute)
  {
    this.jobsOAAttribute = jobsOAAttribute;
  }

  /**
   * Standard getter for JOBSNSKAttribute
   *
   * @return the JOBSNSKAttribute value
   */
  public JOBSNSKAttribute getJOBSNSKAttribute()
  {
    return jobsNSKAttribute;
  }

  /**
   * Standard setter for JOBSNSKAttribute
   *
   * @param JOBSNSKAttribute the JOBSNSKAttribute value to set
   */
  public void setJOBSNSKAttribute(JOBSNSKAttribute jobsNSKAttribute)
  {
    this.jobsNSKAttribute = jobsNSKAttribute;
  }

  /**
   * Standard getter for JOBSMPEAttribute
   *
   * @return the JOBSMPEAttribute value
   */
  public JOBSMPEAttribute getJOBSMPEAttribute()
  {
    return jobsMPEAttribute;
  }

  /**
   * Standard setter for JOBSMPEAttribute
   *
   * @param JOBSMPEAttribute the JOBSMPEAttribute value to set
   */
  public void setJOBSMPEAttribute(JOBSMPEAttribute jobsMPEAttribute)
  {
    this.jobsMPEAttribute = jobsMPEAttribute;
  }

  /**
   * Standard getter for JOBSGCOS8Attribute
   *
   * @return the JOBSGCOS8Attribute value
   */
  public JOBSGCOS8Attribute getJOBSGCOS8Attribute()
  {
    return jobsGCOS8Attribute;
  }

  /**
   * Standard setter for JOBSGCOS8Attribute
   *
   * @param JOBSGCOS8Attribute the JOBSGCOS8Attribute value to set
   */
  public void setJOBSGCOS8Attribute(JOBSGCOS8Attribute jobsGCOS8Attribute)
  {
    this.jobsGCOS8Attribute = jobsGCOS8Attribute;
  }

  /**
   * Standard getter for JOBSBS2000Attribute
   *
   * @return the JOBSBS2000Attribute value
   */
  public JOBSBS2000Attribute getJOBSBS2000Attribute()
  {
    return jobsBS2000Attribute;
  }

  /**
   * Standard setter for JOBSBS2000Attribute
   *
   * @param JOBSBS2000Attribute the JOBSBS2000Attribute value to set
   */
  public void setJOBSBS2000Attribute(JOBSBS2000Attribute jobsBS2000Attribute)
  {
    this.jobsBS2000Attribute = jobsBS2000Attribute;
  }

  /**
   * Standard setter for JOBSSQLAttribute
   *
   * @param JOBSSQLAttribute the JOBSSQLAttribute value to set
   */
  public void setJOBSSQLAttribute(JOBSSQLAttribute jobsSQLAttribute)
  {
    this.jobsSQLAttribute = jobsSQLAttribute;
  }

  /**
   * Standard getter for JOBSSQLAttribute
   *
   * @return the JOBSSQLAttribute value
   */
  public JOBSSQLAttribute getJOBSSQLAttribute()
  {
    return jobsSQLAttribute;
  }

  /**
   * Standard setter for JOBSSQLFormAttribute
   *
   * @param JOBSSQLFormAttribute the JOBSSQLFormAttribute value to set
   */
  public void setJOBSSQLFormAttribute(JOBSSQLFormAttribute jobsSQLAttribute)
  {
    this.jobsSQLFormAttribute = jobsSQLAttribute;
  }

  /**
   * Standard getter for JOBSSQLFormAttribute
   *
   * @return the JOBSSQLFormAttribute value
   */
  public JOBSSQLFormAttribute getJOBSSQLFormAttribute()
  {
    return jobsSQLFormAttribute;
  }
}