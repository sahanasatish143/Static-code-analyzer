/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class TaskCheckpoint
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public TaskCheckpoint()
  {
    this.properties = new Properties();
    this.setCaleKeyName("");
    this.setCaleName("");
    this.setId(0);
    this.setCaleKeyName("");
    this.setCaleName("");
    this.setId(0);
    this.setCaleKeyName("");
    this.setCaleName("");
    this.setId(0);
    this.setCaleKeyName("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskCheckpoint(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Standard setter for CaleKeyName
   *
   * @param caleKeyName the CaleKeyName value to set
   */
  public void setCaleKeyName(String caleKeyName)
  {
    properties.setProperty("CaleKeyName", caleKeyName);
  }

  /**
   * Standard getter for CaleKeyName
   *
   * @returns the CaleKeyName value
   */
  public String getCaleKeyName()
  {
    return properties.getProperty("CaleKeyName");
  }
  
  /**
   * Standard setter for CaleName
   *
   * @param caleName the CaleName value to set
   */
  public void setCaleName(String caleName)
  {
    properties.setProperty("CaleName", caleName);
  }

  /**
   * Standard getter for CaleName
   *
   * @returns the CaleName value
   */
  public String getCaleName()
  {
    return properties.getProperty("CaleName");
  }
  
  /**
   * Standard setter for id
   *
   * @param id the id value to set
   */
  public void setId(Integer id)
  {
    properties.setProperty("id", id.toString());
  }

  /**
   * Standard getter for id
   *
   * @returns the id value
   */
  public Integer getId()
  {
    return Integer.parseInt(properties.getProperty("id"));
  }
}