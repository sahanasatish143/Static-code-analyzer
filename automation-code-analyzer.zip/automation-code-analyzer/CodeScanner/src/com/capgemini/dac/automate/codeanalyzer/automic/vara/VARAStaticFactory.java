package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARAStaticFactory
{
  public VARAStatic getDefaultVARAStatic();
  public VARAStatic parseVARAStaticFromSource();
}
