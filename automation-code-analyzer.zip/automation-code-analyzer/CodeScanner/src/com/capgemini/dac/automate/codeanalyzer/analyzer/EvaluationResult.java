/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.analyzer;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.0
 */
public class EvaluationResult
{
  String errorMessage;
  String value;
  boolean pass;
  
  public EvaluationResult(String message, String actualValue, boolean pass)
  {
    this.errorMessage = message;
    this.value = actualValue;
    this.pass = pass;
  }
  
  public String getMessage()
  {
    return this.errorMessage;  
  }
  
  public String getActualValue()
  {
    return this.value;
  }
}