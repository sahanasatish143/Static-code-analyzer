package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARADefinitionFactory
{
  public VARADefinition getDefaultVARADefinition();
  public VARADefinition parseVARADefinitionFromSource();
}
