/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;




/**
 * The Class VARABackend.
 */
public class VARABackend
{
  
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA backend.
   */
  public VARABackend()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new VARA backend.
   *
   * @param properties the properties
   */
  public VARABackend(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the host dst.
   *
   * @param hostAttrType the new host dst
   */
  public void setHostDst(String hostAttrType)
  {
    properties.setProperty("HostDst", hostAttrType);
  }

  /**
   * Gets the host dst.
   *
   * @return the host dst
   */
  public String getHostDst()
  {
    return properties.getProperty("HostDst");
  }

  /**
   * Sets the apply task H.
   *
   * @param applyTaskH the new apply task H
   */
  public void setApplyTaskH(String applyTaskH)
  {
    properties.setProperty("applyTaskH", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getApplyTaskH()
  {
    return properties.getProperty("applyTaskH");
  }

  /**
   * Sets the login.
   *
   * @param login the new login
   */
  public void setLogin(String login)
  {
    properties.setProperty("Login", login);
  }

  /**
   * Gets the login.
   *
   * @return the login
   */
  public String getLogin()
  {
    return properties.getProperty("Login");
  }

  /**
   * Sets the apply task L.
   *
   * @param applyTaskL the new apply task L
   */
  public void setApplyTaskL(String applyTaskL)
  {
    properties.setProperty("applyTaskL", applyTaskL);
  }

  /**
   * Gets the apply task L.
   *
   * @return the apply task L
   */
  public String getApplyTaskL()
  {
    return properties.getProperty("applyTaskL");
  }

  /**
   * Sets the resultformat.
   *
   * @param resultformat the new resultformat
   */
  public void setResultformat(String resultformat)
  {
    properties.setProperty("resultformat", resultformat);
  }

  /**
   * Gets the resultformat.
   *
   * @return the resultformat
   */
  public String getResultformat()
  {
    return properties.getProperty("resultformat");
  }
  public void setTabs(Tabs parseMembersFromSource)
  {
    properties.getProperty("Tabs");
  }
  public void setWINDOWS(WINDOWS parseMembersFromSource)
  {
    properties.getProperty("WINDOWS");
  }
  public void setUNIX(UNIX parseMembersFromSource)
  {
    properties.getProperty("UNIX");
  }
}
