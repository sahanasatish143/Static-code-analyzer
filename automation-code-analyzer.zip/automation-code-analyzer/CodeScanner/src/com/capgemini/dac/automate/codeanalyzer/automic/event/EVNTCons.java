/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

/**
 * This class represents an Automic EVNTCons object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNTCons
{

  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVNTCons object in the context of an editor or in a code translator.
   */
  public EVNTCons()
  {
    this.properties = new Properties();

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVNTConsFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVNTCons.
   * @see EVNTConsFactory
   */
  public EVNTCons(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for OS400_MsgType
   *
   * @param OS400_MsgType the OS400_MsgType value to set
   */
  public void setOS400_MsgType(Integer oS400_MsgType)
  {
    properties.setProperty("OS400_MsgType", oS400_MsgType.toString());
  }

  /**
   * Standard getter for OS400_MsgType
   *
   * @return the OS400_MsgType value
   */
  public Integer getOS400_MsgType()
  {
    return Integer.parseInt(properties.getProperty("OS400_MsgType"));
  }

  /**
   * Standard setter for OS400_Severity
   *
   * @param OS400_Severity the OS400_Severity value to set
   */
  public void setOS400_Severity(Integer oS400_Severity)
  {
    properties.setProperty("OS400_Severity", oS400_Severity.toString());
  }

  /**
   * Standard getter for OS400_Severity
   *
   * @return the OS400_Severity value
   */
  public Integer getOS400_Severity()
  {
    return Integer.parseInt(properties.getProperty("OS400_Severity"));
  }

  /**
   * Standard setter for LoginDst
   *
   * @param LoginDst the LoginDst value to set
   */
  public void setLoginDst(String loginDst)
  {
    properties.setProperty("LoginDst", loginDst);
  }

  /**
   * Standard getter for LoginDst
   *
   * @return the LoginDst value
   */
  public String getLoginDst()
  {
    return properties.getProperty("LoginDst");
  }

  /**
   * Standard setter for HostDst
   *
   * @param HostDst the HostDst value to set
   */
  public void setHostDst(String hostDst)
  {
    properties.setProperty("HostDst", hostDst);
  }

  /**
   * Standard getter for HostDst
   *
   * @return the HostDst value
   */
  public String getHostDst()
  {
    return properties.getProperty("HostDst");
  }

  /**
   * Standard setter for HostType
   *
   * @param HostType the HostType value to set
   */
  public void setHostType(String hostType)
  {
    properties.setProperty("HostType", hostType);
  }

  /**
   * Standard getter for HostType
   *
   * @return the HostType value
   */
  public String getHostType()
  {
    return properties.getProperty("HostType");
  }

  /**
   * Standard setter for OS400_Filter
   *
   * @param OS400_Filter the OS400_Filter value to set
   */
  public void setOS400_Filter(String oS400_Filter)
  {
    properties.setProperty("OS400_Filter", oS400_Filter);
  }

  /**
   * Standard getter for OS400_Filter
   *
   * @return the OS400_Filter value
   */
  public String getOS400_Filter()
  {
    return properties.getProperty("OS400_Filter");
  }
}
