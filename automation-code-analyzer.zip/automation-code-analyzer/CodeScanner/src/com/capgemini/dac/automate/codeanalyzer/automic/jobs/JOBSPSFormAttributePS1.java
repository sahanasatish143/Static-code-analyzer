/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSPSFormAttributePS1
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSPSFormAttributePS1 object in the context of an editor or in a code
   * translator.
   */
  public JOBSPSFormAttributePS1()
  {
    this.properties = new Properties();
    this.setConnection("");
    this.setLogininfo("");
    this.setPassword("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSPSFormAttributePS1Factory interface. All children objects
   * ,inherited from AutomicObject, will be null and are expected to be injected
   * through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSPSFormAttributePS1.
   * @see JOBSPSFormAttributePS1Factory
   */
  public JOBSPSFormAttributePS1(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Connection.
   *
   * @param Connection the Connection value to set
   */
  public void setConnection(String connection)
  {
    properties.setProperty("Connection", connection);
  }

  /**
   * Standard getter for Connection.
   *
   * @return the Connection
   * @returns the Connection value
   */
  public String getConnection()
  {
    return properties.getProperty("Connection");
  }

  /**
   * Standard setter for Logininfo.
   *
   * @param Logininfo the Logininfo value to set
   */
  public void setLogininfo(String logininfo)
  {
    properties.setProperty("Logininfo", logininfo);
  }

  /**
   * Standard getter for Logininfo.
   *
   * @return the Logininfo
   * @returns the Logininfo value
   */
  public String getLogininfo()
  {
    return properties.getProperty("Logininfo");
  }

  /**
   * Standard setter for Password.
   *
   * @param Password the Password value to set
   */
  public void setPassword(String password)
  {
    properties.setProperty("Password", password);
  }

  /**
   * Standard getter for Password.
   *
   * @return the password
   * @returns the Password value
   */
  public String getPassword()
  {
    return properties.getProperty("Password");
  }
}
