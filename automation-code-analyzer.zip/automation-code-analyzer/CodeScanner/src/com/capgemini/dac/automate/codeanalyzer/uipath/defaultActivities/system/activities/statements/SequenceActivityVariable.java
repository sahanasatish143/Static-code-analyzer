/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * This class represents an UiPath Sequence Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class SequenceActivityVariable implements Iterable<SequenceVariable>
{
  Properties properties;
  ArrayList<SequenceVariable> sequenceVariable;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the SequenceActivityVariableFactory interface. All children objects
   * ,inherited from UiPathObject, will be null and are expected to be injected
   * through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for Sequence.
   * @see SequenceActivityVariableFactory
   */
  public SequenceActivityVariable(Properties properties)
  {
    this.properties = properties;
    sequenceVariable = new ArrayList<SequenceVariable>();

  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * Sequence Activity in the context of an editor or in a code translator.
   */
  public SequenceActivityVariable()
  {
    this.properties = new Properties();
    sequenceVariable = new ArrayList<SequenceVariable>();
  }

  @Override
  public Iterator<SequenceVariable> iterator()
  {
    return sequenceVariable.iterator();
  }

  public void add(SequenceVariable variables)
  {
    sequenceVariable.add(variables);

  }

}
