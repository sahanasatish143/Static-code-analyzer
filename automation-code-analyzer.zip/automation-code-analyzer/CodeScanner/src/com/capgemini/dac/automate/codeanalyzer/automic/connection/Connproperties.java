package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class Connproperties implements Iterable<ConnectionRow>
{
  /** The properties. */
  Properties properties;

  /** The rows. */
  private ArrayList<ConnectionRow> rows;

  /**
   * Instantiates a new members.
   */
  public Connproperties(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<ConnectionRow>();
  }

  public Connproperties()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<ConnectionRow>();
  }

  /**
   * Constructor meant to be used by a factory adhering to the memberFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */

  public void setOCVType(Integer state)
  {
    properties.setProperty("OCV_Type", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state value
   */
  public Integer getOCVType()
  {
    return Integer.parseInt(properties.getProperty("OCV_Type"));
  }
  public void add(ConnectionRow members)
  {
    rows.add(members);
  }

  @Override
  public Iterator<ConnectionRow> iterator()
  {
    return rows.iterator();
  }

}
