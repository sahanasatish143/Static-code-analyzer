package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARASQLIFactory
{
  public VARASQLI getDefaultVARASQLI();
  public VARASQLI parseVARASQLIFromSource();
}
