/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class PromptBox implements Iterable<DynPromptBoxElement>
{
  Properties properties;
  List<DynPromptBoxElement> elements;

  public PromptBox()
  {
    this.properties = new Properties();
    this.elements =  new ArrayList<DynPromptBoxElement>();
    this.setPromptset("");
    this.setPrptmode(0);
  }
  
  public PromptBox(Properties properties)
  {
    this.properties = properties;
    this.elements =  new ArrayList<DynPromptBoxElement>();
  }
  
  /**
   * Standard setter for promptset
   *
   * @param promptset the promptset value to set
   */
  public void setPromptset(String promptset)
  {
    properties.setProperty("promptset", promptset);
  }

  /**
   * Standard getter for promptset
   *
   * @returns the promptset value
   */
  public String getPromptset()
  {
    return properties.getProperty("promptset");
  }
  
  /**
   * Standard setter for prptmode
   *
   * @param prptmode the prptmode value to set
   */
  public void setPrptmode(Integer prptmode)
  {
    properties.setProperty("prptmode", prptmode.toString());
  }

  /**
   * Standard getter for prptmode
   *
   * @returns the prptmode value
   */
  public Integer getPrptmode()
  {
    return Integer.parseInt(properties.getProperty("prptmode"));
  }

  public void add(DynPromptBoxElement element)
  {
    this.elements.add(element);
  }
 
  @Override
  public Iterator<DynPromptBoxElement> iterator()
  {
    return this.elements.iterator();
  }
}