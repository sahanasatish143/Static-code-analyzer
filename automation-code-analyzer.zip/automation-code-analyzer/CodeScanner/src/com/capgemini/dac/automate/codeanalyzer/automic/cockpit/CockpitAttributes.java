/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.cockpit;

import java.util.Properties;

/**
 * This class represents an Automic CockpitAttributes under CPIT object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CockpitAttributes
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CockpitAttributes interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CockpitAttributes.
   * @see CockpitAttributesFactory
   */
  public CockpitAttributes(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CockpitAttributes under CPIT object in the context of an editor or in a code
   * translator.
   */
  public CockpitAttributes()
  {
    this.properties = new Properties();
    this.setFrmHeight(5355);
    this.setFrmWidth(9600);
    this.setResName("");
  }

  /**
   * Standard setter for FrmHeight
   *
   * @param FrmHeight the FrmHeight value to set
   */
  public void setFrmHeight(Integer frmHeight)
  {
    properties.setProperty("FrmHeight", frmHeight.toString());
  }

  /**
   * Standard getter for FrmHeight
   *
   * @return the FrmHeight value
   */
  public Integer getFrmHeight()
  {
    return Integer.parseInt(properties.getProperty("FrmHeight"));
  }

  /**
   * Standard setter for FrmWidth
   *
   * @param FrmWidth the FrmWidth value to set
   */
  public void setFrmWidth(Integer frmWidth)
  {
    properties.setProperty("frmWidth", frmWidth.toString());
  }

  /**
   * Standard getter for FrmWidth
   *
   * @return the FrmWidth value
   */
  public Integer getFrmWidth()
  {
    return Integer.parseInt(properties.getProperty("frmWidth"));
  }

  /**
   * Standard setter for ResName
   *
   * @param ResName the ResName value to set
   */
  public void setResName(String resName)
  {
    properties.setProperty("resName", resName);
  }

  /**
   * Standard getter for ResName
   *
   * @return the ResName value
   */
  public String getResName()
  {
    return properties.getProperty("resName");
  }
}
