/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jsch;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;

/**
 * This class represents an Automic JSCH(Job Scheduler) object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JSCH extends AutomicExecutableObject
{
  private JSCHAttribute jschattr;
  private JSCHDefinition jschDefinition;
  private AutomicScript jschScript;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JSCH object in the context of an editor or in a code translator.
   */
  public JSCH()
  {
    this.properties = new Properties();

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JSCHFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JSCH.
   * @see JSCHFactory
   */
  public JSCH(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for JSCHAttribute
   *
   * @param JSCHAttribute the JSCHAttribute value to set
   */
  public void setJSCHAttribute(JSCHAttribute attributes)
  {
    this.jschattr = attributes;
  }

  /**
   * Standard getter for JSCHAttribute
   *
   * @return the JSCHAttribute value
   */
  public JSCHAttribute getJSCHAttribute()
  {
    return this.jschattr;
  }

  /**
   * Standard getter for JSCHDefinition
   *
   * @return the JSCHDefinition value
   */
  public JSCHDefinition getJSCHDefinition()
  {
    return this.jschDefinition;
  }

  /**
   * Standard setter for JSCHDefinition
   *
   * @param JSCHDefinition the JSCHDefinition value to set
   */
  public void setJSCHDefinition(JSCHDefinition structure)
  {
    this.jschDefinition = structure;
  }

  /**
   * Standard setter for AutomicScript
   *
   * @param AutomicScript the AutomicScript value to set
   */
  public void setScript(AutomicScript script)
  {
    this.jschScript = script;
  }

  /**
   * Standard getter for AutomicScript
   *
   * @return the AutomicScript value
   */
  public AutomicScript getScript()
  {
    return this.jschScript;
  }

}
