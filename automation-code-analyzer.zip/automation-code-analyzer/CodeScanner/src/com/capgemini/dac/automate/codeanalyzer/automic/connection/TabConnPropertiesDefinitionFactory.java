package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface TabConnPropertiesDefinitionFactory
{
  public TabConnPropertiesDefinition getDefaultTabConnPropertiesDefinition();

  public TabConnPropertiesDefinition parseTabConnPropertiesDefinitionFromSource();
}
