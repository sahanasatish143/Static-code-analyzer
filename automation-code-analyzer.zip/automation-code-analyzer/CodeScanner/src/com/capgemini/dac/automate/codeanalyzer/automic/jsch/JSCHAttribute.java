/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jsch;

import java.util.Properties;

/**
 * This class represents an Automic JSCHAttribute in JSCH(Job Scheduler) object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JSCHAttribute
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JSCHAttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JSCHAttribute.
   * @see JSCHAttributeFactory
   */
  public JSCHAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JSCHAttribute object in the context of an editor or in a code translator.
   */
  public JSCHAttribute()
  {
    this.properties = new Properties();
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for queue
   *
   * @param queue the state value to set
   */
  public void setQueue(String queue)
  {
    properties.setProperty("Queue", queue);
  }

  /**
   * Standard getter for queue
   *
   * @return the queue value
   */
  public String getQueue()
  {
    return properties.getProperty("Queue");
  }

  /**
   * Standard setter for ChildQueue
   *
   * @param ChildQueue the ChildQueue value to set
   */
  public void setChildQueue(String childQueue)
  {
    properties.setProperty("ChildQueue", childQueue);
  }

  /**
   * Standard getter for ChildQueue
   *
   * @return the ChildQueue value
   */
  public String getChildQueue()
  {
    return properties.getProperty("ChildQueue");
  }

  /**
   * Standard setter for StartType
   *
   * @param startType the StartType value to set
   */
  public void setStartType(String startType)
  {
    properties.setProperty("StartType", startType);
  }

  /**
   * Standard getter for StartType
   *
   * @return the StartType value
   */
  public String getStartType()
  {
    return properties.getProperty("StartType");
  }

  /**
   * Standard setter for ExtRepDef
   *
   * @param extRepDef the ExtRepDef value to set
   */
  public void setExtRepDef(Integer extRepDef)
  {
    properties.setProperty("ExtRepDef", extRepDef.toString());
  }

  /**
   * Standard getter for ExtRepDef
   *
   * @return the ExtRepDef value
   */
  public Integer getExtRepDef()
  {
    return Integer.parseInt(properties.getProperty("ExtRepDef"));
  }

  /**
   * Standard setter for ExtRepAll
   *
   * @param extRepAll the ExtRepAll value to set
   */
  public void setExtRepAll(Integer extRepAll)
  {
    properties.setProperty("ExtRepAll", extRepAll.toString());
  }

  /**
   * Standard getter for ExtRepAll
   *
   * @return the ExtRepAll value
   */
  public Integer getExtRepAll()
  {
    return Integer.parseInt(properties.getProperty("ExtRepAll"));
  }

  /**
   * Standard setter for ExtRepNone
   *
   * @param extRepNone the ExtRepNone value to set
   */
  public void setExtRepNone(Integer extRepNone)
  {
    properties.setProperty("ExtRepNone", extRepNone.toString());
  }

  /**
   * Standard getter for ExtRepNone
   *
   * @return the ExtRepNone value
   */
  public Integer getExtRepNone()
  {
    return Integer.parseInt(properties.getProperty("ExtRepNone"));
  }

  /**
   * Standard setter for IntAccount
   *
   * @param intAccount the IntAccount value to set
   */
  public void setIntAccount(String intAccount)
  {
    properties.setProperty("IntAccount", intAccount);
  }

  /**
   * Standard getter for IntAccount
   *
   * @return the IntAccount value
   */
  public String getIntAccount()
  {
    return properties.getProperty("IntAccount");
  }

  /**
   * Standard setter for ActAtRun
   *
   * @param actAtRun the ActAtRun value to set
   */
  public void setActAtRun(Integer actAtRun)
  {
    properties.setProperty("ActAtRun", actAtRun.toString());
  }

  /**
   * Standard getter for ActAtRun
   *
   * @return the ActAtRun value
   */
  public Integer getActAtRun()
  {
    return Integer.parseInt(properties.getProperty("ActAtRun"));
  }

  /**
   * Standard setter for Period
   *
   * @param Period the Period value to set
   */
  public void setPeriod(Integer period)
  {
    properties.setProperty("Period", period.toString());
  }

  /**
   * Standard getter for Period
   *
   * @return the Period value
   */
  public Integer getPeriod()
  {
    return Integer.parseInt(properties.getProperty("Period"));
  }

  /**
   * Standard setter for StartTime
   *
   * @param StartTime the StartTime value to set
   */
  public void setStartTime(String startTime)
  {
    properties.setProperty("StartTime", startTime);
  }

  /**
   * Standard getter for StartTime
   *
   * @return the StartTime value
   */
  public String getStartTime()
  {
    return (properties.getProperty("StartTime"));
  }

  /**
   * Standard setter for UC4Priority
   *
   * @param uC4Priority the UC4Priority value to set
   */
  public void setUC4Priority(Integer uC4Priority)
  {
    properties.setProperty("UC4Priority", uC4Priority.toString());
  }

  /**
   * Standard getter for UC4Priority
   *
   * @return the UC4Priority value
   */
  public Integer getUC4Priority()
  {
    return Integer.parseInt(properties.getProperty("UC4Priority"));
  }

  /**
   * Standard setter for MpElse1
   *
   * @param mpElse1 the MpElse1 value to set
   */
  public void setMpElse1(Integer mpElse1)
  {
    properties.setProperty("MpElse1", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @return the MpElse1 value
   */
  public Integer getMpElse1()
  {
    return Integer.parseInt(properties.getProperty("MpElse1"));
  }

  /**
   * Standard setter for MpElse2
   *
   * @param mpElse2 the MpElse2 value to set
   */
  public void setMpElse2(Integer mpElse2)
  {
    properties.setProperty("MpElse2", mpElse2.toString());
  }

  /**
   * Standard getter for MpElse2
   *
   * @return the MpElse2 value
   */
  public Integer getMpElse2()
  {
    return Integer.parseInt(properties.getProperty("MpElse2"));
  }

  /**
   * Standard setter for TZ
   *
   * @param tZ the TZ value to set
   */
  public void setTZ(String tZ)
  {
    properties.setProperty("TZ", tZ);
  }

  /**
   * Standard getter for TZ
   *
   * @return the TZ value
   */
  public String getTZ()
  {
    return properties.getProperty("TZ");
  }

  /**
   * Standard setter for MaxParallel2
   *
   * @param maxParallel2 the MaxParallel2 value to set
   */
  public void setMaxParallel2(Integer maxParallel2)
  {
    properties.setProperty("MaxParallel2", maxParallel2.toString());
  }

  /**
   * Standard getter for MaxParallel2
   *
   * @return the MaxParallel2 value
   */
  public Integer getMaxParallel2()
  {
    return Integer.parseInt(properties.getProperty("MaxParallel2"));
  }

  /**
   * Standard setter for RWhen
   *
   * @param RWhen the RWhen value to set
   */
  public void setRWhen(String rWhen)
  {
    properties.setProperty("RWhen", rWhen);
  }

  /**
   * Standard getter for RWhen
   *
   * @return the RWhen value
   */
  public String getRWhen()
  {
    return properties.getProperty("RWhen");
  }

  /**
   * Standard setter for RExecute
   *
   * @param RExecute the RExecute value to set
   */
  public void setRExecute(String rExecute)
  {
    properties.setProperty("RExecute", rExecute);
  }

  /**
   * Standard getter for RExecute
   *
   * @return the RExecute value
   */
  public String getRExecute()
  {
    return properties.getProperty("RExecute");
  }

}
