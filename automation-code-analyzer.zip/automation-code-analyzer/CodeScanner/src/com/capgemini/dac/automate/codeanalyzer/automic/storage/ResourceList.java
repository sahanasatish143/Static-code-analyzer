/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.storage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * This class represents an Automic ResourceList under STORE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class ResourceList implements Iterable<ResourceListROW>
{
  Properties properties;
  private ArrayList<ResourceListROW> resourceListRows;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the ResourceListFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for ResourceList.
   * @see ResourceListFactory
   */
  public ResourceList(Properties properties)
  {
    this.properties = properties;
    this.resourceListRows = new ArrayList<ResourceListROW>();
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * ResourceList under STORE object in the context of an editor or in a code
   * translator.
   */
  public ResourceList()
  {
    this.properties = new Properties();
    this.resourceListRows = new ArrayList<ResourceListROW>();
  }

  /**
   * Adds a ResourceListROW to the list.
   *
   * @param the the ResourceListROW to add to the collection
   */
  public void add(ResourceListROW rows)
  {
    resourceListRows.add(rows);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the ResourceListROW in the collection
   */
  @Override
  public Iterator<ResourceListROW> iterator()
  {
    return resourceListRows.iterator();
  }

}
