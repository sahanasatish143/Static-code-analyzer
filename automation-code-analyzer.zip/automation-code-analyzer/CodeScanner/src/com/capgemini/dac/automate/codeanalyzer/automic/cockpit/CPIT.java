/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.cockpit;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;

/**
 * This class represents an Automic CPIT object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CPIT extends AutomicExecutableObject
{
  private CPITDefinition cpitDefinition;
  private AutomicScript mainCPITScript;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CPIT object in the context of an editor or in a code translator.
   */
  public CPIT()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CPITFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CPIT.
   * @see CPITFactory
   */
  public CPIT(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for CPITDefinition
   *
   * @return the CPITDefinition value
   */
  public CPITDefinition getCPITDefinition()
  {
    return cpitDefinition;
  }

  /**
   * Standard setter for CPITDefinition
   *
   * @param CPITDefinition the CPITDefinition value to set
   */
  public void setCPITDefinition(CPITDefinition cpitDefinition)
  {
    this.cpitDefinition = cpitDefinition;
  }

  /**
   * Standard getter for mainScript
   *
   * @return the mainScript value
   */
  public void setScript(AutomicScript cpit)
  {
    this.mainCPITScript = cpit;
  }

  /**
   * Standard setter for mainScript
   *
   * @param mainScript the mainScript value to set
   */
  public AutomicScript getScript()
  {
    return this.mainCPITScript;
  }

}
