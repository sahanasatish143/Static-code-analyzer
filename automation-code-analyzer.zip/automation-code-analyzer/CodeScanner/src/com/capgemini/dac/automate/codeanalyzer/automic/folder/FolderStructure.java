/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.folder;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

/**
 * 
 * 
 * @author
 * @version 1.0
 * @since 1.8
 */
public class FolderStructure implements Iterable<FolderItem>
{
  Properties properties;
  List<FolderItem> items;

  public FolderStructure()
  {
    this.properties = new Properties();
    items = new ArrayList<FolderItem>();
    this.setIncludeExternalObjects(1);
  }

  public FolderStructure(Properties properties)
  {
    this.properties = properties;
    items = new ArrayList<FolderItem>();
  }

  public void setIncludeExternalObjects(Integer flag)
  {
    properties.setProperty("includeExternalObjects", flag.toString());
  }

  public Integer getIncludeExternalObjects()
  {
    return Integer.parseInt(properties.getProperty("includeExternalObjects"));
  }

  public void add(FolderItem item)
  {
    items.add(item);
  }

  @Override
  public Iterator<FolderItem> iterator()
  {
    return items.iterator();
  }
}