/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

/**
 * This class represents an Automic VARA object.
 * 
 * @author sahana s ;sahana.b.s@capgemini.com
 * @version 1.0
 * @since 1.8
 */
public class VARA extends AutomicExecutableObject
{
  private VARAAttr varAttr;
  private VARADefinition varaDefinition;

  public VARA()
  {
    this.properties = new Properties();
  }

  public VARA(Properties properties)
  {
    this.properties = properties;
  }

  public void setVaraAtt(VARAAttr varAttr)
  {
    this.varAttr = varAttr;

  }

  public VARAAttr getVaraAtt()
  {
    return this.varAttr;
  }

  public void setVaraDefinition(VARADefinition varaDefinition)
  {
    this.varaDefinition = varaDefinition;

  }

  public VARADefinition getVaraDefinition()
  {
    return this.varaDefinition;
  }

}