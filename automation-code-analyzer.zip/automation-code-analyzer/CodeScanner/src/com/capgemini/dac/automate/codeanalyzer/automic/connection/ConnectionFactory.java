package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionFactory
{
  public Connection getDefaultConnection();
  public Connection parseConnectionFromSource();
}
