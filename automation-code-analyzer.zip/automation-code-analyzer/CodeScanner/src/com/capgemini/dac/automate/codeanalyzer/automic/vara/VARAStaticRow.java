package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VaraStaticRow
{
  Properties properties;
  public VaraStaticRow()
  {
    this.properties = new Properties();
    this.setName("");
    this.setValue("");
    this.setValue1("");
    this.setValue2("");
    this.setValue3("");
    this.setValue4("");
}
  public VaraStaticRow(Properties properties)
  {
    this.properties = properties;
  }
  public void setName(String archiveKey1)
  {
    properties.setProperty("Name", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getName()
  {
    return properties.getProperty("Name");
  }
  public void setValue(String archiveKey1)
  {
    properties.setProperty("Value", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getValue()
  {
    return properties.getProperty("Value");
  }
  public void setValue1(String archiveKey1)
  {
    properties.setProperty("Value1", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getValue1()
  {
    return properties.getProperty("Value1");
  }
  public void setValue2(String archiveKey1)
  {
    properties.setProperty("Value1", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getValue2()
  {
    return properties.getProperty("Value1");
  }
  public void setValue3(String archiveKey1)
  {
    properties.setProperty("Value3", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getValue3()
  {
    return properties.getProperty("Value3");
  }
  public void setValue4(String archiveKey1)
  {
    properties.setProperty("Value4", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getValue4()
  {
    return properties.getProperty("Value4");
  }
}
