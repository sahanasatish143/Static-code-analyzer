/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.calendar;

import java.util.Properties;

/**
 * This class represents an Automic GroupO under CALE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class GroupO extends GroupA
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the GroupOFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for GroupO.
   * @see GroupOFactory
   */
  public GroupO(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * GroupO under CALE object in the context of an editor or in a code translator.
   */
  public GroupO()
  {
    this.properties = new Properties();

  }
}
