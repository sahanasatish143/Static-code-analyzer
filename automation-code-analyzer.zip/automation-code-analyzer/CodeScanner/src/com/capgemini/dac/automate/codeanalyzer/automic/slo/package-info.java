/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

/**
 * Data classes for for Automic SLO components.
 * <p>
 * These classes contain the structures that represent the Automic SLO object.
 *
 * @author Abhishek Tenneti; abhishek.tenneti@capgemini.com
 * @version 1.0
 * @since 1.8
 */
package com.capgemini.dac.automate.codeanalyzer.automic.slo;