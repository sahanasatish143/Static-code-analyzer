/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.period;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;



// TODO: Auto-generated Javadoc
/**
 * The Class Period.
 *
 * @author SAHANA S
 * @version 1.0
 * @since 1.0
 */
public class Period extends AutomicExecutableObject
{
  
  /** The period attributes. */
  private PeriodDefinition periodDefinitions;
  
  

  /**
   * Instantiates a new period.
   */
  public Period()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new period.
   *
   * @param properties the properties
   */
  public Period(Properties properties)
  {
    this.properties = properties;
  }

  

  /**
   * Sets the script attributes.
   *
   * @param periodDefinitions the new script attributes
   */
  public void setPeriodDefinitionFactory(PeriodDefinition periodDefinitions)
  {
    this.periodDefinitions = periodDefinitions;
  }

  /**
   * Gets the period attributes.
   *
   * @return the period attributes
   */
  public PeriodDefinition getPeriodDefinitionFactory()
  {
    return this.periodDefinitions;
  }
}
