/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * This class represents an UiPath Sequence Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class SequenceVariableDefault
{
  Properties properties;
  SequenceVariableDefaultLiteral variableDefault;
  Properties visualBasicValue;
  Map<String, Properties> tagAttributes;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * SequenceVariableDefault Activity in the context of an editor or in a code
   * translator.
   */
  public SequenceVariableDefault()
  {
    properties = new Properties();
    variableDefault = new SequenceVariableDefaultLiteral();
    tagAttributes = new HashMap<String, Properties>();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the SequenceVariableDefaultFactory interface. All children objects
   * ,inherited from UiPathObject, will be null and are expected to be injected
   * through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   *                   properties for SequenceVariableDefault.
   * @see SequenceVariableDefaultFactory
   */
  public SequenceVariableDefault(Properties properties)
  {
    this.properties = properties;
    variableDefault = new SequenceVariableDefaultLiteral();
    tagAttributes = new HashMap<String, Properties>();
  }

  /**
   * Standard setter for SequenceVariableDefaultLiteral
   *
   * @param sequence the SequenceVariableDefaultLiteral value to set
   */
  public void setVariableDefaultLiteral(SequenceVariableDefaultLiteral sequence)
  {
    this.variableDefault = sequence;
  }

  /**
   * Standard getter for SequenceVariableDefaultLiteral
   *
   * @return the SequenceVariableDefaultLiteral value
   */
  public SequenceVariableDefaultLiteral getVariableDefaultLiteral()
  {
    return this.variableDefault;
  }

  public void setVisualBasicValue(Properties properties)
  {
    this.visualBasicValue = properties;
  }

  public void setAddAttributes(String currentName, Properties attributes)
  {
    tagAttributes.put(currentName, attributes);
  }
}
