/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jsch;

import java.util.Properties;

/**
 * Represents a single after block of an Automic JSCH object JSCHStructure task.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.8
 */
public class JSCHTaskAfter
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JSCHTaskAfter object in the context of an editor or in a code translator.
   */
  public JSCHTaskAfter()
  {
    this.properties = new Properties();
    this.setActFlag(1);
    this.setErlstStDays(0);
    this.setErlstStTime("00:00");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JSCHTaskAfterFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JSCHTaskAfter.
   * @see JSCHTaskAfterFactory
   */
  public JSCHTaskAfter(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for ActFlag
   *
   * @param actFlag the ActFlag value to set
   */
  public void setActFlag(Integer actFlag)
  {
    properties.setProperty("ActFlag", actFlag.toString());
  }

  /**
   * Standard getter for ActFlag
   *
   * @returns the ActFlag value
   */
  public Integer getActFlag()
  {
    return Integer.parseInt(properties.getProperty("ActFlag"));
  }

  /**
   * Standard setter for ErlstStDays
   *
   * @param erlstStDays the ErlstStDays value to set
   */
  public void setErlstStDays(Integer erlstStDays)
  {
    properties.setProperty("ErlstStDays", erlstStDays.toString());
  }

  /**
   * Standard getter for ErlstStDays
   *
   * @returns the ErlstStDays value
   */
  public Integer getErlstStDays()
  {
    return Integer.parseInt(properties.getProperty("ErlstStDays"));
  }

  /**
   * Standard setter for ErlstStTime
   *
   * @param erlstStTime the ErlstStTime value to set
   */
  public void setErlstStTime(String erlstStTime)
  {
    properties.setProperty("ErlstStTime", erlstStTime);
  }

  /**
   * Standard getter for ErlstStTime
   *
   * @returns the ErlstStTime value
   */
  public String getErlstStTime()
  {
    return properties.getProperty("ErlstStTime");
  }

}