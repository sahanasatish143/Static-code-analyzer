/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.slo;

import java.util.Properties;

/**
 * This class represents an Automic SLOAttribute object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class SLOAttribute
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the SLOAttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for SLOAttribute.
   * @see SLOAttributeFactory
   */
  public SLOAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * SLOAttribute object in the context of an editor or in a code translator.
   */
  public SLOAttribute()
  {
    this.properties = new Properties();
  }

  /**
   * Standard setter for Enabled
   *
   * @param Enabled the Enabled value to set
   */
  public void setEnabled(Integer enabled)
  {
    properties.setProperty("Enabled", enabled.toString());
  }

  /**
   * Standard getter for Enabled
   *
   * @return the Enabled value
   */
  public Integer getEnabled()
  {
    return Integer.parseInt(properties.getProperty("Enabled"));
  }

  /**
   * Standard setter for MonitorModePerm
   *
   * @param MonitorModePerm the MonitorModePerm value to set
   */
  public void setMonitorModePerm(Integer monitorModePerm)
  {
    properties.setProperty("MonitorModePerm", monitorModePerm.toString());
  }

  /**
   * Standard getter for MonitorModePerm
   *
   * @return the MonitorModePerm value
   */
  public Integer getMonitorModePerm()
  {
    return Integer.parseInt(properties.getProperty("MonitorModePerm"));
  }

  /**
   * Standard setter for MonitorModeLdt
   *
   * @param MonitorModeLdt the MonitorModeLdt value to set
   */
  public void setMonitorModeLdt(Integer monitorModeLdt)
  {
    properties.setProperty("MonitorModeLdt", monitorModeLdt.toString());
  }

  /**
   * Standard getter for MonitorModeLdt
   *
   * @return the MonitorModeLdt value
   */
  public Integer getMonitorModeLdt()
  {
    return Integer.parseInt(properties.getProperty("MonitorModeLdt"));
  }

  /**
   * Standard setter for MonitorFrom
   *
   * @param MonitorFrom the MonitorFrom value to set
   */
  public void setMonitorFrom(String monitorFrom)
  {
    properties.setProperty("MonitorFrom", monitorFrom);
  }

  /**
   * Standard getter for MonitorFrom
   *
   * @return the MonitorFrom value
   */
  public String getMonitorFrom()
  {
    return properties.getProperty("MonitorFrom");
  }

  /**
   * Standard setter for MonitorTo
   *
   * @param MonitorTo the MonitorTo value to set
   */
  public void setMonitorTo(String monitorTo)
  {
    properties.setProperty("MonitorTo", monitorTo);
  }

  /**
   * Standard getter for MonitorTo
   *
   * @return the MonitorTo value
   */
  public String getMonitorTo()
  {
    return properties.getProperty("MonitorTo");
  }

  /**
   * Standard setter for TZ
   *
   * @param TZ the TZ value to set
   */
  public void setTZ(String tZ)
  {
    properties.setProperty("TZ", tZ);
  }

  /**
   * Standard getter for TZ
   *
   * @return the TZ value
   */
  public String getTZ()
  {
    return properties.getProperty("TZ");
  }
}
