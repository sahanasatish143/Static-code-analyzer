/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jsch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * Represents a collection of Tasks for an Automic JSCH object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.8
 */
public class JSCHStructure implements Iterable<JSCHTask>
{
  Properties properties;
  private ArrayList<JSCHTask> tasks;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JSCHStructure object in the context of an editor or in a code translator.
   */
  public JSCHStructure()
  {
    this.properties = new Properties();
    this.tasks = new ArrayList<JSCHTask>();
    this.setState(1);
    this.setMsgNr(0);
    this.setPeriod(1);
    this.setStartTime("00:00");
    this.setMode("design");
    this.setOptions("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JSCHStructureFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JSCHStructure.
   * @see JSCHStructureFactory
   */
  public JSCHStructure(Properties properties)
  {
    this.properties = properties;
    this.tasks = new ArrayList<JSCHTask>();
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for MsgNr
   *
   * @param MsgNr the MsgNr value to set
   */
  public void setMsgNr(Integer msgNr)
  {
    properties.setProperty("MsgNr", msgNr.toString());
  }

  /**
   * Standard getter for MsgNr
   *
   * @returns the MsgNr value
   */
  public Integer getMsgNr()
  {
    return Integer.parseInt(properties.getProperty("MsgNr"));
  }

  /**
   * Standard setter for Period
   *
   * @param Period the Period value to set
   */
  public void setPeriod(Integer period)
  {
    properties.setProperty("Period", period.toString());
  }

  /**
   * Standard getter for Period
   *
   * @returns the Period value
   */
  public Integer getPeriod()
  {
    return Integer.parseInt(properties.getProperty("Period"));
  }

  /**
   * Standard setter for StartTime
   *
   * @param StartTime the StartTime value to set
   */
  public void setStartTime(String StartTime)
  {
    properties.setProperty("StartTime", StartTime);
  }

  /**
   * Standard getter for StartTime
   *
   * @returns the StartTime value
   */
  public String getStartTime()
  {
    return properties.getProperty("StartTime");
  }

  /**
   * Standard setter for mode
   *
   * @param mode the mode value to set
   */
  public void setMode(String mode)
  {
    properties.setProperty("mode", mode);
  }

  /**
   * Standard getter for mode
   *
   * @returns the mode value
   */
  public String getMode()
  {
    return properties.getProperty("mode");
  }

  /**
   * Standard setter for OPTIONS
   *
   * @param options the OPTIONS value to set
   */
  public void setOptions(String options)
  {
    properties.setProperty("OPTIONS", options);
  }

  /**
   * Standard getter for OPTIONS
   *
   * @returns the OPTIONS value
   */
  public String getOptions()
  {
    return properties.getProperty("OPTIONS");
  }

  /**
   * Adds a JSCHTask to the list.
   *
   * @param the the JSCHTask to add to the collection
   */
  public void add(JSCHTask task)
  {
    tasks.add(task);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the JSCHTasks in the collection
   */
  @Override
  public Iterator<JSCHTask> iterator()
  {
    return tasks.iterator();
  }
}
