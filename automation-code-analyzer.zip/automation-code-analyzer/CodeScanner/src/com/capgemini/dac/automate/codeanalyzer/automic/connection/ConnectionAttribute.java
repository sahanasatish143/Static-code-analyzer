/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

/**
 * The Class ConnectionAttribute.
 */
public class ConnectionAttribute
{
  /** The properties. */
  Properties properties;
 
  /**
   * Instantiates a new connection attribute.
   */
  public ConnectionAttribute()
  {
    this.properties = new Properties();


  }

  /**
   * Instantiates a new connection attribute.
   *
   * @param properties the properties
   */
  public ConnectionAttribute(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }
  
  
  /**
   * Sets the http.
   *
   * @param modeA the new http
   */
  public void setHttp(Integer modeA)
  {
    properties.setProperty("HTTP", modeA.toString());
  }

  
  /**
   * Gets the http.
   *
   * @return the http
   */
  public String getHttp()
  {
    return properties.getProperty("HTTP");
  }

  /**
   * Sets the rfc.
   *
   * @param modeF the new rfc
   */
  public void setRfc(Integer modeF)
  {
    properties.setProperty("RFC", modeF.toString());
  }

  
  /**
   * Gets the rfc.
   *
   * @return the rfc
   */
  public String getRfc()
  {
    return properties.getProperty("RFC");
  }
  public void setCitcont(CitPanel citpanel)
  {
    properties.getProperty("citpanel");
  }
}
