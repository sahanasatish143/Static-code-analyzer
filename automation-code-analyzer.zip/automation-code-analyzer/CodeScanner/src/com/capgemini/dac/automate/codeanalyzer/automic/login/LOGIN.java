/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.login;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

public class LOGIN extends AutomicExecutableObject
{
  private LOGINDefinition loginDefinition;

  public LOGIN()
  {
    this.properties = new Properties();
  }

  public LOGIN(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for loginDefinition
   *
   * @return the loginDefinition value
   */
  public LOGINDefinition getLOGINDefinition()
  {
    return loginDefinition;
  }

  /**
   * Standard setter for loginDefinition
   *
   * @param loginDefinition the loginDefinition value to set
   */
  public void setLOGINDefinition(LOGINDefinition loginDefinition)
  {
    this.loginDefinition = loginDefinition;
  }
}