/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobf;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;
import com.capgemini.dac.automate.codeanalyzer.automic.core.OutputScan;

/**
 * The Class JOBF.
 */
public class JOBF extends AutomicExecutableObject
{

  /** The jobf definition. */
  private JobFDefinition jobfDefinition;

  /** The jobf attr. */
  private JobFAttr jobfAttr;

  /** The out scan. */
  private OutputScan outScan;

  /** The main script. */
  private AutomicScript mainScript;

  /**
   * Instantiates a new jobf.
   */
  public JOBF()
  {
    super();
  }

  /**
   * Instantiates a new jobf.
   *
   * @param properties the properties
   */
  public JOBF(Properties properties)
  {
    super(properties);
  }

  /**
   * Sets the jobf definition.
   *
   * @param jobfDefinition the new jobf definition
   */
  public void setJobfDefinition(JobFDefinition jobfDefinition)
  {
    this.jobfDefinition = jobfDefinition;
  }

  /**
   * Gets the jobf definition.
   *
   * @return the jobf definition
   */
  public JobFDefinition getJobfDefinition()
  {
    return this.jobfDefinition;
  }

  /**
   * Sets the jobf attr.
   *
   * @param jobfAttr the new jobf attr
   */
  public void setJobfAttr(JobFAttr jobfAttr)
  {
    this.jobfAttr = jobfAttr;
  }

  /**
   * Gets the jobf attr.
   *
   * @return the jobf attr
   */
  public JobFAttr getJobfAttr()
  {
    return this.jobfAttr;
  }

  /**
   * Sets the out scan.
   *
   * @param outScan the new out scan
   */
  public void setOutScan(OutputScan outScan)
  {
    this.outScan = outScan;
  }

  /**
   * Gets the out scan.
   *
   * @return the out scan
   */
  public OutputScan getOutScan()
  {
    return this.outScan;
  }

  /**
   * Sets the script.
   *
   * @param script the new script
   */
  public void setScript(AutomicScript script)
  {
    this.mainScript = script;
  }

  /**
   * Gets the script.
   *
   * @return the script
   */
  public AutomicScript getScript()
  {
    return this.mainScript;
  }

}