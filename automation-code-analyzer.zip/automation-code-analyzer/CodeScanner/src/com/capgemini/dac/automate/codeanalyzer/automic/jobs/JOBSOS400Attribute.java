/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSOS400Attribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSOS400Attribute object in the context of an editor or in a code
   * translator.
   */
  public JOBSOS400Attribute()
  {
    this.properties = new Properties();
    this.setQPJOBLOG(1);
    this.setALL(0);
    this.setCMD(1);
    this.setILECL(0);
    this.setREXX(0);
    this.setJobName("");
    this.setPriority("");
    this.setJobDescription("");
    this.setJobQueue("");
    this.setRootingData("");

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSOS400AttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSOS400Attribute.
   * @see JOBSOS400AttributeFactory
   */
  public JOBSOS400Attribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for QPJOBLOG.
   *
   * @param QPJOBLOG the QPJOBLOG value to set
   */
  public void setQPJOBLOG(Integer qPJOBLOG)
  {
    properties.setProperty("QPJOBLOG", qPJOBLOG.toString());
  }

  /**
   * Standard getter for QPJOBLOG.
   *
   * @return the QPJOBLOG
   * @returns the QPJOBLOG value
   */
  public Integer getQPJOBLOG()
  {
    return Integer.parseInt(properties.getProperty("QPJOBLOG"));
  }

  /**
   * Standard setter for ALL.
   *
   * @param ALL the ALL value to set
   */
  public void setALL(Integer all)
  {
    properties.setProperty("ALL", all.toString());
  }

  /**
   * Standard getter for ALL.
   *
   * @return the ALL
   * @returns the ALL value
   */
  public Integer getALL()
  {
    return Integer.parseInt(properties.getProperty("ALL"));
  }

  /**
   * Standard setter for CMD.
   *
   * @param CMD the CMD value to set
   */
  public void setCMD(Integer cmd)
  {
    properties.setProperty("CMD", cmd.toString());
  }

  /**
   * Standard getter for CMD.
   *
   * @return the CMD
   * @returns the CMD value
   */
  public Integer getCMD()
  {
    return Integer.parseInt(properties.getProperty("CMD"));
  }

  /**
   * Standard setter for ILECL.
   *
   * @param ILECL the ILECL value to set
   */
  public void setILECL(Integer iLECL)
  {
    properties.setProperty("ILECL", iLECL.toString());
  }

  /**
   * Standard getter for ILECL.
   *
   * @return the ILECL
   * @returns the ILECL value
   */
  public Integer getILECL()
  {
    return Integer.parseInt(properties.getProperty("ILECL"));
  }

  /**
   * Standard setter for REXX.
   *
   * @param REXX the REXX value to set
   */
  public void setREXX(Integer rexx)
  {
    properties.setProperty("REXX", rexx.toString());
  }

  /**
   * Standard getter for REXX.
   *
   * @return the REXX
   * @returns the REXX value
   */
  public Integer getREXX()
  {
    return Integer.parseInt(properties.getProperty("REXX"));
  }

  /**
   * Standard setter for Priority.
   *
   * @param Priority the Priority value to set
   */
  public void setPriority(String priority)
  {
    properties.setProperty("Priority", priority);
  }

  /**
   * Standard getter for Priority.
   *
   * @return the Priority
   * @returns the Priority value
   */
  public String getPriority()
  {
    return (properties.getProperty("Priority"));
  }

  /**
   * Standard setter for JobName.
   *
   * @param JobName the JobName value to set
   */
  public void setJobName(String jobName)
  {
    properties.setProperty("JobName", jobName);
  }

  /**
   * Standard getter for JobName.
   *
   * @return the JobName
   * @returns the JobName value
   */
  public String getJobName()
  {
    return properties.getProperty("JobName");
  }

  /**
   * Standard setter for JobQueue.
   *
   * @param JobQueue the JobQueue value to set
   */
  public void setJobQueue(String jobQueue)
  {
    properties.setProperty("JobQueue", jobQueue);
  }

  /**
   * Standard getter for JobQueue.
   *
   * @return the JobQueue
   * @returns the JobQueue value
   */
  public String getJobQueue()
  {
    return properties.getProperty("JobQueue");
  }

  /**
   * Standard setter for JobDescription.
   *
   * @param JobDescription the JobDescription value to set
   */
  public void setJobDescription(String jobDescription)
  {
    properties.setProperty("JobDescription", jobDescription);
  }

  /**
   * Standard getter for JobDescription.
   *
   * @return the JobDescription
   * @returns the JobDescription value
   */
  public String getJobDescription()
  {
    return properties.getProperty("JobDescription");
  }

  /**
   * Standard setter for RootingData.
   *
   * @param RootingData the RootingData value to set
   */
  public void setRootingData(String rootingData)
  {
    properties.setProperty("RootingData", rootingData);
  }

  /**
   * Standard getter for RootingData.
   *
   * @return the RootingData
   * @returns the RootingData value
   */
  public String getRootingData()
  {
    return properties.getProperty("RootingData");
  }
}
