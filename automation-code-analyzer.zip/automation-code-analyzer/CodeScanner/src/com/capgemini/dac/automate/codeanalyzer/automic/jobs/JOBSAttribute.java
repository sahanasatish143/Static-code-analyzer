/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.jobp.JobPAttr;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSAttribute extends JobPAttr
{

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSAttribute object in the context of an editor or in a code translator.
   */
  public JOBSAttribute()
  {
    this.properties = new Properties();
    this.setHostDst("");
    this.setHostATTR_Type("");
    this.setCodeName("");
    this.setLogin("");
    this.setAttDialog(0);
    this.setConsumption(0);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSAttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSAttribute.
   * @see JOBSAttributeFactory
   */
  public JOBSAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /* *//**
        * Standard setter for state.
        *
        * @param state the state value to set
        */
  /*
   * public void setState(Integer state) { properties.setProperty("state",
   * state.toString()); }
   * 
   *//**
      * Standard getter for state.
      *
      * @return the state
      * @returns the state value
      *//*
         * public Integer getState() { return
         * Integer.parseInt(properties.getProperty("state")); }
         */

  /**
   * Standard setter for AttDialog.
   *
   * @param AttDialog the AttDialog value to set
   */
  public void setAttDialog(Integer attDialog)
  {
    properties.setProperty("AttDialog", attDialog.toString());
  }

  /**
   * Standard getter for AttDialog.
   *
   * @return the AttDialog
   * @returns the AttDialog value
   */
  public Integer getAttDialog()
  {
    return Integer.parseInt(properties.getProperty("AttDialog"));
  }

  /**
   * Standard setter for Consumption.
   *
   * @param Consumption the Consumption value to set
   */
  public void setConsumption(Integer consumption)
  {
    properties.setProperty("Consumption", consumption.toString());
  }

  /**
   * Standard getter for Consumption.
   *
   * @return the Consumption
   * @returns the Consumption value
   */
  public Integer getConsumption()
  {
    return Integer.parseInt(properties.getProperty("Consumption"));
  }

  /**
   * Standard setter for HostDst.
   *
   * @param HostDst the HostDst value to set
   */
  public void setHostDst(String hostDst)
  {
    properties.setProperty("HostDst", hostDst);
  }

  /**
   * Standard getter for HostDst.
   *
   * @return the HostDst
   * @returns the HostDst value
   */
  public String getHostDst()
  {
    return properties.getProperty("HostDst");
  }

  /**
   * Standard setter for HostATTR_Type.
   *
   * @param HostATTR_Type the HostATTR_Type value to set
   */
  public void setHostATTR_Type(String hostATTR_Type)
  {
    properties.setProperty("HostATTR_Type", hostATTR_Type);
  }

  /**
   * Standard getter for HostATTR_Type.
   *
   * @return the HostATTR_Type
   * @returns the HostATTR_Type value
   */
  public String getHostATTR_Type()
  {
    return properties.getProperty("HostATTR_Type");
  }

  /**
   * Standard setter for CodeName.
   *
   * @param CodeName the CodeName value to set
   */
  public void setCodeName(String codeName)
  {
    properties.setProperty("CodeName", codeName);
  }

  /**
   * Standard getter for CodeName.
   *
   * @return the CodeName
   * @returns the CodeName value
   */
  public String getCodeName()
  {
    return properties.getProperty("CodeName");
  }

  /**
   * Standard setter for Login.
   *
   * @param Login the Login value to set
   */
  public void setLogin(String login)
  {
    properties.setProperty("Login", login);
  }

  /**
   * Standard getter for Login.
   *
   * @return the Login
   * @returns the Login value
   */
  public String getLogin()
  {
    return properties.getProperty("Login");
  }
}
