package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VARASQL
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA backend.
   */
  public VARASQL()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new VARA backend.
   *
   * @param properties the properties
   */
  public VARASQL(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the host dst.
   *
   * @param hostAttrType the new host dst
   */
  public void setConn(String hostAttrType)
  {
    properties.setProperty("Conn", hostAttrType);
  }

  /**
   * Gets the host dst.
   *
   * @return the host dst
   */
  public String getConn()
  {
    return properties.getProperty("Conn");
  }

  public void setLogin(String applyTaskH)
  {
    properties.setProperty("Login", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getLogin()
  {
    return properties.getProperty("Login");
  }
  /**
   * Sets the resultformat.
   *
   * @param preferTaskHost the new resultformat
   */
  public void setprefUserLogin(Integer preferTaskHost)
  {
    properties.setProperty("prefUserLogin", preferTaskHost.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the resultformat
   * @returns the state value
   */
  public Integer getprefUserLogin()
  {
    return Integer.parseInt(properties.getProperty("prefUserLogin"));
  }

  public void setsql(String applyTaskH)
  {
    properties.setProperty("sql", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getsql()
  {
    return properties.getProperty("sql");
  }
  public void setresultformat(String applyTaskH)
  {
    properties.setProperty("resultformat", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getresultformat()
  {
    return properties.getProperty("resultformat");
  }
  public void setBindParams(String applyTaskH)
  {
    properties.setProperty("BindParams", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getBindParams()
  {
    return properties.getProperty("BindParams");
  }

}
