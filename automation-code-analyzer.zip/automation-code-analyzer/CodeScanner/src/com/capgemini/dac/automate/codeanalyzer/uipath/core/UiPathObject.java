/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.Properties;

/**
 * 
 * @version 1.0
 * @since 1.0
 */
public abstract class UiPathObject
{
  protected Properties properties;

  /**
   * Default constructor. Meant to be called by a sub-class, not directly.
   */
  protected UiPathObject()
  {
    this.setProperties(new Properties());
  }

  /**
   * 
   */
  protected UiPathObject(Properties properties)
  {
    this.setProperties(properties);
  }

  /**
   * Standard setter for name.
   * 
   * 
   */
  protected void setProperties(Properties properties)
  {
    this.properties = properties;
  }
}