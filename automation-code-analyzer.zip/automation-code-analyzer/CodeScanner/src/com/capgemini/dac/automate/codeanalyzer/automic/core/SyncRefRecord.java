/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * Represents a sync reference record declaration in an Automic executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class SyncRefRecord
{
  private Properties properties;
  
  /**
   * Constructor to build a default Runtime object.
   */
  public SyncRefRecord()
  {
    this.properties = new Properties();
    this.setAbend("");
    this.setElse("");
    this.setEnd("");
    this.setName("");
    this.setStart("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the SyncRefRecordFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public SyncRefRecord(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Standard setter for Abend
   *
   * @param abend the Abend value to set
   */
  public void setAbend(String abend)
  {
    properties.setProperty("Abend", abend);
  }

  /**
   * Standard getter for Abend
   *
   * @return the Abend value
   */
  public String getAbend()
  {
    return properties.getProperty("Abend");
  }

  /**
   * Standard setter for Else
   *
   * @param Else the Else value to set
   */
  public void setElse(String Else)
  {
    properties.setProperty("Else", Else);
  }

  /**
   * Standard getter for Else
   *
   * @return the Else value
   */
  public String Else()
  {
    return properties.getProperty("Else");
  }

  /**
   * Standard setter for End
   *
   * @param end the End value to set
   */
  public void setEnd(String end)
  {
    properties.setProperty("End", end.toString());
  }

  /**
   * Standard getter for End
   *
   * @return the End value
   */
  public String getEnd()
  {
    return properties.getProperty("End");
  }

  /**
   * Standard setter for Name
   *
   * @param name the Name value to set
   */
  public void setName(String name)
  {
    properties.setProperty("Name", name);
  }

  /**
   * Standard getter for Name
   *
   * @return the Name value
   */
  public String Name()
  {
    return properties.getProperty("Name");
  }

  /**
   * Standard setter for Start
   *
   * @param start the Start value to set
   */
  public void setStart(String start)
  {
    properties.setProperty("Start", start);
  }

  /**
   * Standard getter for Start
   *
   * @return the Start value
   */
  public String Start()
  {
    return properties.getProperty("Start");
  }
}