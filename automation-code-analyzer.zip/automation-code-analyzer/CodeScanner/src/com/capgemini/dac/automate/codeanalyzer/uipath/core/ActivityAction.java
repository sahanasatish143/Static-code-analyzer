/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * This class represents an UiPath Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class ActivityAction extends UiPathObject
{
  private ActionArgument activityActionArgument;
  private List<UiPathObject> activity;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * ActivityAction Activity in the context of an editor or in a code translator.
   */
  public ActivityAction()
  {
    this.properties = new Properties();
    activityActionArgument = new ActionArgument();
    activity = new ArrayList<UiPathObject>();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the ActionFactory interface. All children objects ,inherited from
   * UiPathObject, will be null and are expected to be injected through setters by
   * the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   *                   properties for ActivityAction.
   * @see ActivityActionFactory
   */

  public ActivityAction(Properties properties)
  {
    this.setProperties(properties);
    activityActionArgument = new ActionArgument();
    activity = new ArrayList<UiPathObject>();
  }

  /**
   * Standard setter for ActionArgument
   *
   * @param activityActionArgument the ActionArgument value to set
   */
  public void setActionArgument(ActionArgument activityActionArgument)
  {
    this.activityActionArgument = activityActionArgument;
  }

  /**
   * Standard getter for ActionArgument
   *
   * @return the ActionArgument value
   */
  public ActionArgument getActionArgument()
  {
    return this.activityActionArgument;
  }

  public void add(UiPathObject object)
  {
    activity.add(object);
  }
}