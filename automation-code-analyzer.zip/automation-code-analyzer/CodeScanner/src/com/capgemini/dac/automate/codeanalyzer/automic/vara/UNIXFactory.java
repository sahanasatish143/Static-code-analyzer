package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface UNIXFactory
{
  public UNIX getDefaultUNIX();
  public UNIX parseUNIXFromSource();
}
