/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.hostg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * The Class Members.
 *
 * @author 
 * @version 1.0
 * @since 1.0
 */
public class Members implements Iterable<Row>
{
  
  /** The properties. */
  Properties properties;
  
  /** The rows. */
  private ArrayList<Row> rows;
  
  /**
   * Instantiates a new members.
   */
  public Members(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<Row>(); 
  }
  public Members()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<Row>(); 
  }
  /**
   * Constructor meant to be used by a factory adhering to the memberFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  
 
  public void add(Row members)
  {
   rows.add(members);
  }
  @Override
  public Iterator<Row> iterator()
  {
     return rows.iterator();
  }
  
  }