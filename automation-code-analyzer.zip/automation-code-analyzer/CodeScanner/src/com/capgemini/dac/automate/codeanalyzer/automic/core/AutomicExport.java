/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.folder.FolderStructure;

/**
 * This class is a container for all the objects that reside in an Automic export.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.0
 */
public class AutomicExport implements Iterable<AutomicObject>
{
  private Properties properties;
  private FolderStructure folders;
  private List<AutomicObject> objects;
  
  /**
   * Default constructor. Meant to be called by a sub-class, not directly.
   */
  public AutomicExport()
  {
    properties = new Properties();
    folders = new FolderStructure();
    objects = new ArrayList<AutomicObject>();
    this.setClientvers("0.0.0");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the AutomicExportFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for AutomicExport.
   * @see AutomicExportFactory
   */
  public AutomicExport(Properties properties)
  {
    this.properties = properties;
    folders = new FolderStructure();
    objects = new ArrayList<AutomicObject>();    
  }
  
  /**
   * Standard setter for clientvers
   *
   * @param version the clientvers value to set
   */  
  public void setClientvers(String version)
  {
    properties.setProperty("clientvers", version);
  }
  
   /**
    * Standard getter for clientvers
    *
    * @return \ the clientvers section of the object
    */
  public String getClientvers()
  {
    return properties.getProperty("clientvers");
  }
  
  /**
   * Standard setter for folders
   *
   * @param folders the folders value to set
   */  public void setFolders(FolderStructure folders)
  {
    this.folders = folders;
  }
  
   /**
    * Standard getter for folders
    *
    * @return a reference to the folders section of the object
    */
  public FolderStructure getFolders()
  {
    return folders;
  }
  
  /**
   * Standard setter for objects
   *
   * @param objects i list of the Automic objects to set
   */  public void setObjects(List<AutomicObject> objects)
  {
    this.objects = objects;
  }
  
   /**
    * add an Automic objects to the exports collection
    *
    * @param object the object to be added
    */
  public void add(AutomicObject object)
  {
    objects.add(object);
  }
  
  /**
   * This get the iterator for the list of Automic objects 
   *
   * @return an iterator for the object list
   */
  @Override
  public Iterator<AutomicObject> iterator()
  {
    return objects.iterator();
  }
}