package com.capgemini.dac.automate.codeanalyzer.automic.login;

public interface LOGINFactory
{
  public LOGIN getDefaultLOGIN();

  /**
   * Parses the LOGIN definition from source.
   *
   * @return the LOGIN definition
   */
  public LOGIN parseLOGINFromSource();
}
