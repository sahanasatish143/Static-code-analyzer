/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSGCOS8Attribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSGCOS8Attribute object in the context of an editor or in a code
   * translator.
   */
  public JOBSGCOS8Attribute()
  {
    this.properties = new Properties();
    this.setUrgency("");
    this.setSnumb("");
    this.setIdent("");
    this.setJclJob("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSGCOS8AttributeeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSGCOS8Attribute.
   * @see JOBSGCOS8AttributeFactory
   */
  public JOBSGCOS8Attribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Urgency.
   *
   * @param Urgency the Urgency value to set
   */
  public void setUrgency(String urgency)
  {
    properties.setProperty("Urgency", urgency);
  }

  /**
   * Standard getter for Urgency.
   *
   * @return the Urgency
   * @returns the Urgency value
   */
  public String getUrgency()
  {
    return properties.getProperty("Urgency");
  }

  /**
   * Standard setter for Snumb.
   *
   * @param Snumb the Snumb value to set
   */
  public void setSnumb(String snumb)
  {
    properties.setProperty("Snumb", snumb);
  }

  /**
   * Standard getter for Snumb.
   *
   * @return the Snumb
   * @returns the Snumb value
   */
  public String getSnumb()
  {
    return properties.getProperty("Snumb");
  }

  /**
   * Standard setter for Ident.
   *
   * @param Ident the Ident value to set
   */
  public void setIdent(String ident)
  {
    properties.setProperty("Ident", ident);
  }

  /**
   * Standard getter for Ident.
   *
   * @return the Ident
   * @returns the Ident value
   */
  public String getIdent()
  {
    return properties.getProperty("Ident");
  }

  /**
   * Standard setter for JclJob.
   *
   * @param JclJob the JclJob value to set
   */
  public void setJclJob(String jclJob)
  {
    properties.setProperty("JclJob", jclJob);
  }

  /**
   * Standard getter for JclJob.
   *
   * @return the JclJob
   * @returns the JclJob value
   */
  public String getJclJob()
  {
    return properties.getProperty("JclJob");
  }
}
