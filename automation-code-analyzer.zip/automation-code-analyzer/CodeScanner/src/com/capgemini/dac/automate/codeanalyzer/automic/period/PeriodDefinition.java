/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.period;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class PeriodDefinition.
 *
 * @author sahana s
 * @version 1.0
 * @since 1.0
 */
public class PeriodDefinition
{

/** The properties. */
Properties properties;
  
  /**
   * Instantiates a new period attribute.
   *
   * @param properties the properties
   */
  public PeriodDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Instantiates a new period attribute.
   */
  public PeriodDefinition()
  {
    this.properties = new Properties();
  }

  
  /**
   * Standard setter for ModeEvery.
   *
   * @param modeEvery the new mode every
   */
  public void setModeEvery(String modeEvery)
  {
    properties.setProperty("ModeEvery", modeEvery);
  }

  /**
   * Standard getter for ModeEvery.
   *
   * @return the ModeEvery value
   */
  public String getModeEvery()
  {
    return properties.getProperty("ModeEvery");
  }
 
  /**
   * Standard setter for ModeGap.
   *
   * @param modeGap the new mode gap
   */
  public void setModeGap(String modeGap)
  {
    properties.setProperty("ModeGap", modeGap);
  }

  /**
   * Standard getter for ModeGap.
   *
   * @return the ModeGap value
   */
  public String getModeGap()
  {
    return properties.getProperty("ModeGap");
  }

  /**
   * Standard setter for OperatorOR.
   *
   * @param modeOnce the new mode once
   */
  public void setModeOnce(String modeOnce)
  {
    properties.setProperty("ModeOnce", modeOnce);
  }

  /**
   * Standard getter for modeOnce.
   *
   * @return the modeOnce value
   */
  public String getModeOnce()
  {
    return properties.getProperty("ModeOnce");
  }
  
  /**
   * Standard setter for Every.
   *
   * @param every the new every
   */
  public void setEvery(String every)
  {
    properties.setProperty("Every", every);
  }

  /**
   * Standard getter for Every.
   *
   * @return the Every value
   */
  public String getEvery()
  {
    return properties.getProperty("Every");
  }

  /**
   * Standard setter for Gap.
   *
   * @param gap the new gap
   */
  public void setGap(String gap)
  {
    properties.setProperty("Gap", gap);
  }

  /**
   * Standard getter for Gap.
   *
   * @return the Gap value
   */
  public String getGap()
  {
    return properties.getProperty("Gap");
  }

  /**
   * Standard setter for once.
   *
   * @param once the new once
   */
  public void setOnce(String once)
  {
    properties.setProperty("Once", once);
  }

  /**
   * Standard getter for Once.
   *
   * @return the  Once
   */
  public String getOnce()
  {
    return properties.getProperty("Once");
  }

  /**
   * Standard setter for Overlap.
   *
   * @param overlap the new overlap
   */
  public void setOverlap(String overlap)
  {
    properties.setProperty("Overlap", overlap);
  }

  /**
   * Standard getter for Overlap.
   *
   * @return the Overlap value
   */
  public String getOverlap()
  {
    return properties.getProperty("Overlap");
  }

  /**
   * Standard setter for FromTime.
   *
   * @param fromTime the new from time
   */
  public void setFromTime(String fromTime)
  {
    properties.setProperty("FromTime", fromTime);
  }

  /**
   * Standard getter for FromTime.
   *
   * @return the FromTime value
   */
  public String getFromTime()
  {
    return properties.getProperty("FromTime");
  }

  /**
   * Standard setter for ToTime.
   *
   * @param toTime the new to time
   */
  public void setToTime(String toTime)
  {
    properties.setProperty("ToTime", toTime);
  }

  /**
   * Standard getter for ToTime.
   *
   * @return the ToTime value
   */
  public String getToTime()
  {
    return properties.getProperty("ToTime");
  }

  /**
   * Standard setter for Adjust.
   *
   * @param adjust the new adjust
   */
  public void setAdjust(String adjust)
  {
    properties.setProperty("Adjust", adjust);
  }

  /**
   * Standard getter for Adjust.
   *
   * @return the Adjust value
   */
  public String getAdjust()
  {
    return properties.getProperty("Adjust");
  }

  /**
   * Standard setter for DaysModeW.
   *
   * @param daysModeW the new days mode W
   */
  public void setDaysModeW(String daysModeW)
  {
    properties.setProperty("DaysModeW", daysModeW);
  }

  /**
   * Standard getter for DaysModeW.
   *
   * @return the DaysModeW value
   */
  public String getDaysModeW()
  {
    return properties.getProperty("DaysModeW");
  }

  /**
   * Standard setter for DaysModeC.
   *
   * @param daysModeC the new days mode C
   */
  public void setDaysModeC(String daysModeC)
  {
    properties.setProperty("DaysModeC", daysModeC);
  }

  /**
   * Standard getter for DaysModeC.
   *
   * @return the DaysModeC value
   */
  public String getDaysModeC()
  {
    return properties.getProperty("DaysModeC");
  }

  /**
   * Standard setter for weekdays.
   *
   * @param weekdays the new weekdays
   */
  public void setWeekdays(String weekdays)
  {
    properties.setProperty("Weekdays", weekdays);
  }

  /**
   * Standard getter for weekdays.
   *
   * @return the weekdays value
   */
  public String getWeekdays()
  {
    return properties.getProperty("Weekdays");
  }

  /**
   * Standard setter for Calendars.
   *
   * @param calendars the new calendars
   */
  public void setCalendars(String calendars)
  {
    properties.setProperty("Calendars", calendars);
  }

  /**
   * Standard getter for calendars.
   *
   * @return the calendars value
   */
  public String getCalendars()
  {
    return properties.getProperty("Calendars");
  }

  /**
   * Standard setter for CaleTypeO.
   *
   * @param caleTypeO the new cale type O
   */
  public void setCaleTypeO(String caleTypeO)
  {
    properties.setProperty("CaleTypeO", caleTypeO);
  }

  /**
   * Standard getter for CaleTypeO.
   *
   * @return the CaleTypeO value
   */
  public String getCaleTypeO()
  {
    return properties.getProperty("CaleTypeO");
  }

  /**
   * Standard setter for caleTypeN.
   *
   * @param caleTypeN the new cale type N
   */
  public void setCaleTypeN(String caleTypeN)
  {
    properties.setProperty("CaleTypeN", caleTypeN);
  }

  /**
   * Standard getter for CaleTypeN.
   *
   * @return the CaleTypeN value
   */
  public String getCaleTypeN()
  {
    return properties.getProperty("CaleTypeN");
  }

  /**
   * Standard setter for CaleTypeA.
   *
   * @param caleTypeA the new cale type A
   */
  public void setCaleTypeA(String caleTypeA)
  {
    properties.setProperty("CaleTypeA", caleTypeA);
  }

  /**
   * Standard getter for CaleTypeA.
   *
   * @return the CaleTypeA value
   */
  public String getCaleTypeA()
  {
    return properties.getProperty("CaleTypeA");
  }

  /**
   * Standard setter for ModeNoEnd.
   *
   * @param modeNoEnd the new mode no end
   */
  public void setModeNoEnd(String modeNoEnd)
  {
    properties.setProperty("ModeNoEnd", modeNoEnd);
  }

  /**
   * Standard getter for ModeNoEnd.
   *
   * @return the ModeNoEnd value
   */
  public String getModeNoEnd()
  {
    return properties.getProperty("ModeNoEnd");
  }

  /**
   * Standard setter for ModeEndDate.
   *
   * @param modeEndDate the new mode end date
   */
  public void setModeEndDate(String modeEndDate)
  {
    properties.setProperty("ModeEndDate", modeEndDate);
  }

  /**
   * Standard getter for ModeEndDate.
   *
   * @return the ModeEndDate value
   */
  public String getModeEndDate()
  {
    return properties.getProperty("ModeEndDate");
  }

  /**
   * Standard setter for ModeMaxRuns.
   *
   * @param modeMaxRuns the new mode max runs
   */
  public void setModeMaxRuns(String modeMaxRuns)
  {
    properties.setProperty("ModeMaxRuns", modeMaxRuns);
  }

  /**
   * Standard getter for ModeMaxRuns.
   *
   * @return the ModeMaxRuns value
   */
  public String getModeMaxRuns()
  {
    return properties.getProperty("ModeMaxRuns");
  }
  
  /**
   * Standard setter for RangeStart.
   *
   * @param rangeStart the new range start
   */
  public void setRangeStart(String rangeStart)
  {
    properties.setProperty("RangeStart", rangeStart);
  }

  /**
   * Standard getter for RangeStart.
   *
   * @return the RangeStart value
   */
  public String getRangeStart()
  {
    return properties.getProperty("RangeStart");
  }
  
  /**
   * Standard setter for RangeEnd.
   *
   * @param rangeEnd the new range end
   */
  public void setRangeEnd(String rangeEnd)
  {
    properties.setProperty("RangeEnd", rangeEnd);
  }

  /**
   * Standard getter for RangeEnd.
   *
   * @return the RangeEnd value
   */
  public String getRangeEnd()
  {
    return properties.getProperty("RangeEnd");
  }
  
  /**
   * Standard setter for MaxRuns.
   *
   * @param maxRuns the new max runs
   */
  public void setMaxRuns(String maxRuns)
  {
    properties.setProperty("MaxRuns", maxRuns);
  }

  /**
   * Standard getter for MaxRuns.
   *
   * @return the MaxRuns value
   */
  public String getMaxRuns()
  {
    return properties.getProperty("MaxRuns");
  }

  

  
}
