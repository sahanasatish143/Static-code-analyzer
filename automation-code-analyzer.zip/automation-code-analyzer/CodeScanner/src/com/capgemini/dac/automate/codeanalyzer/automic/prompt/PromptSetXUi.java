/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.prompt;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class PromptSetXUi.
 *
 * @author sahana s
 * @version 1.0
 * @since 1.0
 */
public class PromptSetXUi
{

/** The properties. */
private Properties properties;
  
  /**
   * Instantiates a new prompt set X ui.
   */
  public PromptSetXUi() {
    this.properties = new Properties();
    this.setState(1);
    this.setXUiEditor("");
  }
    
    /**
     * Instantiates a new prompt set X ui.
     *
     * @param properties the properties
     */
    public PromptSetXUi(Properties properties)
    {
      this.properties = properties;
    }

    /**
     * Standard setter for state.
     *
     * @param state the state value to set
     */
    public void setState(Integer state)
    {
      properties.setProperty("state", state.toString());
    }

    /**
     * Standard getter for state.
     *
     * @return the state
     * @returns the state value
     */
    public Integer getState()
    {
      return Integer.parseInt(properties.getProperty("state"));
    }

    /**
     * Standard setter for XUIEDITOR.
     *
     * @param xUiEditor the new x ui editor
     */
    public void setXUiEditor(String xUiEditor)
    {
      properties.setProperty("XUIEDITOR", xUiEditor);
    }

    /**
     * Standard getter for XUIEDITOR.
     *
     * @return the x ui editor
     * @returns the XUIEDITOR value
     */
    public String getXUiEditor()
    {
      return properties.getProperty("XUIEDITOR");
    }
  }

