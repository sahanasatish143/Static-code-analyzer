package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

public class ConnectionRFC
{
  /** The properties. */
  Properties properties;
 
  /**
   * Instantiates a new connection attribute.
   */
  public ConnectionRFC()
  {
    this.properties = new Properties();


  }

  /**
   * Instantiates a new connection attribute.
   *
   * @param properties the properties
   */
  public ConnectionRFC(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }
  
  public void setCitcont(RFCPanel citpanel)
  {
    properties.getProperty("RFCPANEL");
  }
}
