package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnpropertiesFactory
{
  public Connproperties getDefaultConnproperties();
  public Connproperties parseConnpropertiesFromSource();
}
