/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSUnixAttribute extends JOBSVMSAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSUnixAttribute object in the context of an editor or in a code translator.
   */
  public JOBSUnixAttribute()
  {
    this.properties = new Properties();
    this.setShellScript(1);
    this.setCommand(0);
    this.setShell("");
    this.setShellOptions("");
    this.setCom("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSUnixAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSUnixAttribute.
   * @see JOBSUnixAttributeFactory
   */
  public JOBSUnixAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Command.
   *
   * @param Command the Command value to set
   */
  public void setCommand(Integer command)
  {
    properties.setProperty("Command", command.toString());
  }

  /**
   * Standard getter for Command.
   *
   * @return the Command
   * @returns the Command value
   */
  public Integer getCommand()
  {
    return Integer.parseInt(properties.getProperty("Command"));
  }

  /**
   * Standard setter for ShellScript.
   *
   * @param ShellScript the ShellScript value to set
   */
  public void setShellScript(Integer shellScript)
  {
    properties.setProperty("ShellScript", shellScript.toString());
  }

  /**
   * Standard getter for ShellScript.
   *
   * @return the ShellScript
   * @returns the ShellScript value
   */
  public Integer getShellScript()
  {
    return Integer.parseInt(properties.getProperty("ShellScript"));
  }

  /**
   * Standard setter for Shell.
   *
   * @param Shell the Shell value to set
   */
  public void setShell(String shell)
  {
    properties.setProperty("Shell", shell);
  }

  /**
   * Standard getter for Shell.
   *
   * @return the Shell
   * @returns the Shell value
   */
  public String getShell()
  {
    return properties.getProperty("Shell");
  }

  /**
   * Standard setter for ShellOptions.
   *
   * @param ShellOptions the ShellOptions value to set
   */
  public void setShellOptions(String shellOptions)
  {
    properties.setProperty("ShellOptions", shellOptions);
  }

  /**
   * Standard getter for ShellOptions.
   *
   * @return the ShellOptions
   * @returns the ShellOptions value
   */
  public String getShellOptions()
  {
    return properties.getProperty("ShellOptions");
  }

  /**
   * Standard setter for Com.
   *
   * @param Com the Com value to set
   */
  public void setCom(String com)
  {
    properties.setProperty("Com", com);
  }

  /**
   * Standard getter for Com.
   *
   * @return the Com
   * @returns the Com value
   */
  public String getCom()
  {
    return properties.getProperty("Com");
  }

}
