/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jsch;

import java.util.Properties;

/**
 * Represents a single calendar block of an Automic JSCH object JSCHStructure
 * task.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.8
 */
public class JSCHTaskCalendar
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JSCHTaskCalendar object in the context of an editor or in a code translator.
   */
  public JSCHTaskCalendar()
  {
    this.properties = new Properties();
    this.setCaleKeyName("");
    this.setCaleName("");
    this.setId(0);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JSCHTaskCalendarFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JSCHTaskCalendar.
   * @see JSCHTaskCalendarFactory
   */
  public JSCHTaskCalendar(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for CaleKeyName
   *
   * @param caleKeyName the CaleKeyName value to set
   */
  public void setCaleKeyName(String caleKeyName)
  {
    properties.setProperty("CaleKeyName", caleKeyName);
  }

  /**
   * Standard getter for CaleKeyName
   *
   * @returns the CaleKeyName value
   */
  public String getCaleKeyName()
  {
    return properties.getProperty("CaleKeyName");
  }

  /**
   * Standard setter for CaleName
   *
   * @param caleName the CaleName value to set
   */
  public void setCaleName(String caleName)
  {
    properties.setProperty("CaleName", caleName);
  }

  /**
   * Standard getter for CaleName
   *
   * @returns the CaleName value
   */
  public String getCaleName()
  {
    return properties.getProperty("CaleName");
  }

  /**
   * Standard setter for id
   *
   * @param id the id value to set
   */
  public void setId(Integer id)
  {
    properties.setProperty("id", id.toString());
  }

  /**
   * Standard getter for id
   *
   * @returns the id value
   */
  public Integer getId()
  {
    return Integer.parseInt(properties.getProperty("id"));
  }
}