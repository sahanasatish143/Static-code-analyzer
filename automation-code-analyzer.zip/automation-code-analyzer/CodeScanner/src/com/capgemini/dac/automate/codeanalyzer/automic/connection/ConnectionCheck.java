/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

/**
 * The Class ConnectionCheck.
 */
public class ConnectionCheck
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new connection attribute.
   */
  public ConnectionCheck()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new connection attribute.
   *
   * @param properties the properties
   */
  public ConnectionCheck(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Sets the conn check image.
   *
   * @param hostAttrType the new conn check image
   */
  public void setConnCheckImage(String hostAttrType)
  {
    properties.setProperty("conn.check.image", hostAttrType);
  }

  
  /**
   * Gets the conn check image.
   *
   * @return the conn check image
   */
  public String getConnCheckImage()
  {
    return properties.getProperty("conn.check.image");
  }

 
  /**
   * Sets the conn check info.
   *
   * @param citName the new conn check info
   */
  public void setConnCheckInfo(String citName)
  {
    properties.setProperty("conn.check.info", citName);
  }

  
  /**
   * Gets the conn check info.
   *
   * @return the conn check info
   */
  public String getConnCheckInfo()
  {
    return properties.getProperty("conn.check.info");
  }
}
