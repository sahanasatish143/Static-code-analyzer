package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

public class ConnectionSQL
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new connection attribute.
   */
  public ConnectionSQL()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new connection attribute.
   *
   * @param properties the properties
   */
  public ConnectionSQL(Properties properties)
  {
    this.properties = properties;

  }

  public void setCitcont(CitPanel citpanel)
  {
    properties.getProperty("citpanel");
  }
  public void setConnectionSettings(ConnectionSettings citpanel)
  {
    properties.getProperty("connection.settings");
  }
  public void setConnCheck(ConnectionCheck citpanel)
  {
    properties.getProperty("conn.check");
  }
}
