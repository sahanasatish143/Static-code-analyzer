/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Represents a dynamic value node declaration in an Automic executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class DynValueNode implements DynNode
{
  private Properties properties;
  private List<DynValueRow> rows;
  
  /**
   * Constructor to build a default DynValueNode object.
   */
  public DynValueNode()
  {
    this.properties = new Properties();
    rows = new ArrayList<DynValueRow>();
    this.setState(1);
    this.setContent(1);
    this.setId("VALUE");
    this.setName("Variables");
    this.setParent("");
    this.setType("VALUE");
    this.setMode(1);
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the DynValueNodeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public DynValueNode(Properties properties)
  {
    this.properties = properties;
    rows = new ArrayList<DynValueRow>();
  }

  /**
   * Appends a new dynamic value row to the node's list.
   *
   * @param row variable record to be added
   */
  public void add(DynValueRow row)
  {
    rows.add(row);
  }
  
  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for content
   *
   * @param content the content value to set
   */
  public void setContent(Integer content)
  {
    properties.setProperty("content", content.toString());
  }

  /**
   * Standard getter for content
   *
   * @returns the content value
   */
  public Integer getContent()
  {
    return Integer.parseInt(properties.getProperty("content"));
  }

  /**
   * Standard setter for id
   *
   * @param id the id value to set
   */
  public void setId(String id)
  {
    properties.setProperty("id", id);
  }

  /**
   * Standard getter for id
   *
   * @returns the id value
   */
  public String getId()
  {
    return properties.getProperty("id");
  }

  /**
   * Standard setter for name
   *
   * @param name the name value to set
   */
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }

  /**
   * Standard getter for name
   *
   * @returns the name value
   */
  public String getName()
  {
    return properties.getProperty("name");
  }

  /**
   * Standard setter for parent
   *
   * @param parent the parent value to set
   */
  public void setParent(String parent)
  {
    properties.setProperty("parent", parent);
  }

  /**
   * Standard getter for parent
   *
   * @returns the parent value
   */
  public String getParent()
  {
    return properties.getProperty("parent");
  }

  /**
   * Standard setter for type
   *
   * @param type the type value to set
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Standard getter for type
   *
   * @returns the type value
   */
  public String getType()
  {
    return properties.getProperty("type");
  }

  /**
   * Standard setter for Mode
   *
   * @param Mode the Mode value to set
   */
  public void setMode(Integer Mode)
  {
    properties.setProperty("Mode", Mode.toString());
  }

  /**
   * Standard getter for Mode
   *
   * @returns the Mode value
   */
  public Integer getMode()
  {
    return Integer.parseInt(properties.getProperty("Mode"));
  }
}