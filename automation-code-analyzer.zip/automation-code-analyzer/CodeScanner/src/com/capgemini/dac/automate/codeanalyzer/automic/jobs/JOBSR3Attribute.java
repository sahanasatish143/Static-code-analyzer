/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSR3Attribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSR3Attribute object in the context of an editor or in a code translator.
   */
  public JOBSR3Attribute()
  {
    this.properties = new Properties();
    this.setOptReportSAPL(0);
    this.setOptReportSSTP(0);
    this.setOptReportSSTC(0);
    this.setOptReportSSPL(0);
    this.setOptReportSLOG(0);
    this.setOptReportSSJJI(0);
    this.setLanguage("");
    this.setJobName("");
    this.setJobClass("C");
    this.setTargetSystem("");
    this.setDeleteJob(1);
    this.setNoDelOnErr("");
    this.setUseLoginObject("");
    this.setAsSoon(1);
    this.setImmediately(0);
    this.setSAP_Recipent("");
    this.setSAP_AddressType("");
    this.setSAP_Express("");
    this.setSAP_Copy(0);
    this.setSAP_BlindCopy(0);
    this.setSAP_NoForward("");
    this.setSAP_NoPrint("");
    this.setSAP_Deliver("");
    this.setSAP_StatusByMail("");
    this.setSAP_JobType(2);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSR3AttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSR3Attribute.
   * @see JOBSR3AttributeFactory
   */
  public JOBSR3Attribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for OptReportSAPL.
   *
   * @param OptReportSAPL the OptReportSAPL value to set
   */
  public void setOptReportSAPL(Integer optReportSAPL)
  {
    properties.setProperty("OptReportSAPL", optReportSAPL.toString());
  }

  /**
   * Standard getter for OptReportSAPL.
   *
   * @return the OptReportSAPL
   * @returns the OptReportSAPL value
   */
  public Integer getOptReportSAPL()
  {
    return Integer.parseInt(properties.getProperty("OptReportSAPL"));
  }

  /**
   * Standard setter for OptReportSSTP.
   *
   * @param OptReportSSTP the OptReportSSTP value to set
   */
  public void setOptReportSSTP(Integer optReportSSTP)
  {
    properties.setProperty("OptReportSSTP", optReportSSTP.toString());
  }

  /**
   * Standard getter for OptReportSSTP.
   *
   * @return the OptReportSSTP
   * @returns the OptReportSSTP value
   */
  public Integer getOptReportSSTP()
  {
    return Integer.parseInt(properties.getProperty("OptReportSSTP"));
  }

  /**
   * Standard setter for OptReportSSTC.
   *
   * @param OptReportSSTC the OptReportSSTC value to set
   */
  public void setOptReportSSTC(Integer optReportSSTC)
  {
    properties.setProperty("OptReportSSTC", optReportSSTC.toString());
  }

  /**
   * Standard getter for OptReportSSTC.
   *
   * @return the OptReportSSTC
   * @returns the OptReportSSTC value
   */
  public Integer getOptReportSSTC()
  {
    return Integer.parseInt(properties.getProperty("OptReportSSTC"));
  }

  /**
   * Standard setter for OptReportSSPL.
   *
   * @param OptReportSSPL the OptReportSSPL value to set
   */
  public void setOptReportSSPL(Integer optReportSSPL)
  {
    properties.setProperty("OptReportSSPL", optReportSSPL.toString());
  }

  /**
   * Standard getter for OptReportSSPL.
   *
   * @return the OptReportSSPL
   * @returns the OptReportSSPL value
   */
  public Integer getOptReportSSPL()
  {
    return Integer.parseInt(properties.getProperty("OptReportSSPL"));
  }

  /**
   * Standard setter for OptReportSLOG.
   *
   * @param OptReportSLOG the OptReportSLOG value to set
   */
  public void setOptReportSLOG(Integer optReportSLOG)
  {
    properties.setProperty("OptReportSLOG", optReportSLOG.toString());
  }

  /**
   * Standard getter for OptReportSLOG.
   *
   * @return the OptReportSLOG
   * @returns the OptReportSLOG value
   */
  public Integer getOptReportSLOG()
  {
    return Integer.parseInt(properties.getProperty("OptReportSLOG"));
  }

  /**
   * Standard setter for OptReportSSJJI.
   *
   * @param OptReportSSJJI the OptReportSSJJI value to set
   */
  public void setOptReportSSJJI(Integer optReportSSJJI)
  {
    properties.setProperty("OptReportSSJJI", optReportSSJJI.toString());
  }

  /**
   * Standard getter for OptReportSSJJI.
   *
   * @return the OptReportSSJJI
   * @returns the OptReportSSJJI value
   */
  public Integer getOptReportSSJJI()
  {
    return Integer.parseInt(properties.getProperty("OptReportSSJJI"));
  }

  /**
   * Standard setter for DeleteJob.
   *
   * @param DeleteJob the DeleteJob value to set
   */
  public void setDeleteJob(Integer deleteJob)
  {
    properties.setProperty("DeleteJob", deleteJob.toString());
  }

  /**
   * Standard getter for DeleteJob.
   *
   * @return the DeleteJob
   * @returns the DeleteJob value
   */
  public Integer getDeleteJob()
  {
    return Integer.parseInt(properties.getProperty("DeleteJob"));
  }

  /**
   * Standard setter for AsSoon.
   *
   * @param AsSoon the AsSoon value to set
   */
  public void setAsSoon(Integer asSoon)
  {
    properties.setProperty("AsSoon", asSoon.toString());
  }

  /**
   * Standard getter for AsSoon.
   *
   * @return the AsSoon
   * @returns the AsSoon value
   */
  public Integer getAsSoon()
  {
    return Integer.parseInt(properties.getProperty("AsSoon"));
  }

  /**
   * Standard setter for Immediately.
   *
   * @param Immediately the Immediately value to set
   */
  public void setImmediately(Integer immediately)
  {
    properties.setProperty("Immediately", immediately.toString());
  }

  /**
   * Standard getter for Immediately.
   *
   * @return the Immediately
   * @returns the Immediately value
   */
  public Integer getImmediately()
  {
    return Integer.parseInt(properties.getProperty("Immediately"));
  }

  /**
   * Standard setter for SAP_Copy.
   *
   * @param SAP_Copy the SAP_Copy value to set
   */
  public void setSAP_Copy(Integer sap_Copy)
  {
    properties.setProperty("SAP_Copy", sap_Copy.toString());
  }

  /**
   * Standard getter for SAP_Copy.
   *
   * @return the SAP_Copy
   * @returns the SAP_Copy value
   */
  public Integer getSAP_Copy()
  {
    return Integer.parseInt(properties.getProperty("SAP_Copy"));
  }

  /**
   * Standard setter for SAP_BlindCopy.
   *
   * @param SAP_BlindCopy the SAP_BlindCopy value to set
   */
  public void setSAP_BlindCopy(Integer sap_BlindCopy)
  {
    properties.setProperty("SAP_BlindCopy", sap_BlindCopy.toString());
  }

  /**
   * Standard getter for SAP_BlindCopy.
   *
   * @return the SAP_BlindCopy
   * @returns the SAP_BlindCopy value
   */
  public Integer getSAP_BlindCopy()
  {
    return Integer.parseInt(properties.getProperty("SAP_BlindCopy"));
  }

  /**
   * Standard setter for SAP_JobType.
   *
   * @param SAP_JobType the SAP_JobType value to set
   */
  public void setSAP_JobType(Integer sap_JobType)
  {
    properties.setProperty("SAP_JobType", sap_JobType.toString());
  }

  /**
   * Standard getter for SAP_JobType.
   *
   * @return the SAP_JobType
   * @returns the SAP_JobType value
   */
  public Integer getSAP_JobType()
  {
    return Integer.parseInt(properties.getProperty("SAP_JobType"));
  }

  /**
   * Standard setter for Language.
   *
   * @param Language the Language value to set
   */
  public void setLanguage(String language)
  {
    properties.setProperty("Language", language);
  }

  /**
   * Standard getter for Language.
   *
   * @return the Language
   * @returns the Language value
   */
  public String getLanguage()
  {
    return properties.getProperty("Language");
  }

  /**
   * Standard setter for JobName.
   *
   * @param JobName the JobName value to set
   */
  public void setJobName(String jobName)
  {
    properties.setProperty("JobName", jobName);
  }

  /**
   * Standard getter for JobName.
   *
   * @return the JobName
   * @returns the JobName value
   */
  public String getJobName()
  {
    return properties.getProperty("JobName");
  }

  /**
   * Standard setter for JobClass.
   *
   * @param JobClass the JobClass value to set
   */
  public void setJobClass(String jobClass)
  {
    properties.setProperty("JobClass", jobClass);
  }

  /**
   * Standard getter for JobClass.
   *
   * @return the JobClass
   * @returns the JobClass value
   */
  public String getJobClass()
  {
    return properties.getProperty("JobClass");
  }

  /**
   * Standard setter for TargetSystem.
   *
   * @param TargetSystem the TargetSystem value to set
   */
  public void setTargetSystem(String targetSystem)
  {
    properties.setProperty("TargetSystem", targetSystem);
  }

  /**
   * Standard getter for TargetSystem.
   *
   * @return the TargetSystem
   * @returns the TargetSystem value
   */
  public String getTargetSystem()
  {
    return properties.getProperty("TargetSystem");
  }

  /**
   * Standard setter for NoDelOnErr.
   *
   * @param NoDelOnErr the NoDelOnErr value to set
   */
  public void setNoDelOnErr(String noDelOnErr)
  {
    properties.setProperty("NoDelOnErr", noDelOnErr);
  }

  /**
   * Standard getter for NoDelOnErr.
   *
   * @return the NoDelOnErr
   * @returns the NoDelOnErr value
   */
  public String getNoDelOnErr()
  {
    return properties.getProperty("NoDelOnErr");
  }

  /**
   * Standard setter for UseLoginObject.
   *
   * @param UseLoginObject the UseLoginObject value to set
   */
  public void setUseLoginObject(String useLoginObject)
  {
    properties.setProperty("UseLoginObject", useLoginObject);
  }

  /**
   * Standard getter for UseLoginObject.
   *
   * @return the UseLoginObject
   * @returns the UseLoginObject value
   */
  public String getUseLoginObject()
  {
    return properties.getProperty("UseLoginObject");
  }

  /**
   * Standard setter for SAP_Recipent.
   *
   * @param SAP_Recipent the SAP_Recipent value to set
   */
  public void setSAP_Recipent(String sap_Recipent)
  {
    properties.setProperty("SAP_Recipent", sap_Recipent);
  }

  /**
   * Standard getter for SAP_Recipent.
   *
   * @return the SAP_Recipent
   * @returns the SAP_Recipent value
   */
  public String getSAP_Recipent()
  {
    return properties.getProperty("SAP_Recipent");
  }

  /**
   * Standard setter for SAP_AddressType.
   *
   * @param SAP_AddressType the SAP_AddressType value to set
   */
  public void setSAP_AddressType(String sap_AddressType)
  {
    properties.setProperty("SAP_AddressType", sap_AddressType);
  }

  /**
   * Standard getter for SAP_AddressType.
   *
   * @return the SAP_AddressType
   * @returns the SAP_AddressType value
   */
  public String getSAP_AddressType()
  {
    return properties.getProperty("SAP_AddressType");
  }

  /**
   * Standard setter for SAP_Express.
   *
   * @param SAP_Express the SAP_Express value to set
   */
  public void setSAP_Express(String sap_Express)
  {
    properties.setProperty("SAP_Express", sap_Express);
  }

  /**
   * Standard getter for SAP_Express.
   *
   * @return the SAP_Express
   * @returns the SAP_Express value
   */
  public String getSAP_Express()
  {
    return properties.getProperty("SAP_Express");
  }

  /**
   * Standard setter for SAP_NoForward.
   *
   * @param SAP_NoForward the SAP_NoForward value to set
   */
  public void setSAP_NoForward(String sap_NoForward)
  {
    properties.setProperty("SAP_NoForward", sap_NoForward);
  }

  /**
   * Standard getter for SAP_NoForward.
   *
   * @return the SAP_NoForward
   * @returns the SAP_NoForward value
   */
  public String getSAP_NoForward()
  {
    return properties.getProperty("SAP_NoForward");
  }

  /**
   * Standard setter for SAP_NoPrint.
   *
   * @param SAP_NoPrint the SAP_NoPrint value to set
   */
  public void setSAP_NoPrint(String sap_NoPrint)
  {
    properties.setProperty("SAP_NoPrint", sap_NoPrint);
  }

  /**
   * Standard getter for SAP_NoPrint.
   *
   * @return the SAP_NoPrint
   * @returns the SAP_NoPrint value
   */
  public String getSAP_NoPrint()
  {
    return properties.getProperty("SAP_NoPrint");
  }

  /**
   * Standard setter for SAP_Deliver.
   *
   * @param SAP_Deliver the SAP_Deliver value to set
   */
  public void setSAP_Deliver(String sap_Deliver)
  {
    properties.setProperty("SAP_Deliver", sap_Deliver);
  }

  /**
   * Standard getter for SAP_Deliver.
   *
   * @return the SAP_Deliver
   * @returns the SAP_Deliver value
   */
  public String getSAP_Deliver()
  {
    return properties.getProperty("SAP_Deliver");
  }

  /**
   * Standard setter for SAP_StatusByMail.
   *
   * @param SAP_StatusByMail the SAP_StatusByMail value to set
   */
  public void setSAP_StatusByMail(String sap_StatusByMail)
  {
    properties.setProperty("SAP_StatusByMail", sap_StatusByMail);
  }

  /**
   * Standard getter for SAP_StatusByMail.
   *
   * @return the SAP_StatusByMail
   * @returns the SAP_StatusByMail value
   */
  public String getSAP_StatusByMail()
  {
    return properties.getProperty("SAP_StatusByMail");
  }
}
