/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate.codeanalyzer.automic.queue;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

/**
 * This class represents an Automic Queue object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class Queue extends AutomicExecutableObject
{
  private QueueDefinition queueDefinition;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * Queue object in the context of an editor or in a code translator.
   */
  public Queue()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the QueueFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for Queue.
   * @see QueueFactory
   */
  public Queue(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for QueueDefinition
   *
   * @return the QueueDefinition value
   */
  public QueueDefinition getQueueDefinition()
  {
    return queueDefinition;
  }

  /**
   * Standard setter for QueueDefinition
   *
   * @param QueueDefinition the QueueDefinition value to set
   */
  public void setQueueDefinition(QueueDefinition queueDefinition)
  {
    this.queueDefinition = queueDefinition;
  }

}
