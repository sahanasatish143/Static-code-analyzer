package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface CitPanelFactory
{
  public CitPanel getDefaultCitPanel();
  public CitPanel parseCitPanelFromSource();
}
