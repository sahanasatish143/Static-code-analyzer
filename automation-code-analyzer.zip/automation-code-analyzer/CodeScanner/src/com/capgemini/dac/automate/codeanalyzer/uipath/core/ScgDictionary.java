package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.Properties;

public class ScgDictionary
{
  Properties properties;
  Properties xBoolean;
  Properties avPoint;
  Properties avSize;
  Properties avPointCollection;

  public ScgDictionary()
  {
    this.properties = new Properties();
    xBoolean = new Properties();
    avPoint = new Properties();
    avSize = new Properties();
    avPointCollection = new Properties();
    this.setBoolean("");
    this.setPoint("");
    this.setSize("");
    this.setPointCollection("");
  }

  public ScgDictionary(Properties properties)
  {
    this.properties = properties;
    xBoolean = new Properties();
    avPoint = new Properties();
    avSize = new Properties();
    avPointCollection = new Properties();

  }

  public String getBoolean()
  {
    return properties.getProperty("Boolean");
  }

  public void setBoolean(String bool)
  {
    properties.setProperty("Boolean", bool);
  }

  public String getPoint()
  {
    return properties.getProperty("Point");
  }

  public void setPoint(String point)
  {
    properties.setProperty("Point", point);
  }

  public String getSize()
  {
    return properties.getProperty("Size");
  }

  public void setSize(String size)
  {
    properties.setProperty("Size", size);
  }

  public String getPointCollection()
  {
    return properties.getProperty("PointCollection");
  }

  public void setPointCollection(String point)
  {
    properties.setProperty("PointCollection", point);
  }

  public void setBoolean(Properties bool)
  {
    this.xBoolean = bool;
    // properties.setProperty("Boolean", bool.toString());
  }

  public void setPoint(Properties point)
  {
    this.avPoint = point;
    // properties.setProperty("Boolean", bool.toString());
  }

  public void setSize(Properties size)
  {
    this.avSize = size;

  }

  public void setPointCollection(Properties point)
  {

    this.avPointCollection = point;
  }
}
