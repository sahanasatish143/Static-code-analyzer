/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * Represents a collection of Tasks for an Automic JobP object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class JobStructure implements Iterable<Task>
{
  Properties properties;
  private ArrayList<Task> tasks;

  /**
   * Constructor to build a default JobStructure object.
   */
  public JobStructure()
  {
    this.properties = new Properties();
    this.tasks = new ArrayList<Task>();
    this.setState(1);
    this.setMode("design");
    this.setOptions("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the JobStructureFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public JobStructure(Properties properties)
  {
    this.properties = properties;
    this.tasks = new ArrayList<Task>();
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for mode
   *
   * @param mode the mode value to set
   */
  public void setMode(String mode)
  {
    properties.setProperty("mode", mode);
  }

  /**
   * Standard getter for mode
   *
   * @returns the mode value
   */
  public String getMode()
  {
    return properties.getProperty("mode");
  }

  /**
   * Standard setter for OPTIONS
   *
   * @param options the OPTIONS value to set
   */
  public void setOptions(String options)
  {
    properties.setProperty("OPTIONS", options);
  }

  /**
   * Standard getter for OPTIONS
   *
   * @returns the OPTIONS value
   */
  public String getOptions()
  {
    return properties.getProperty("OPTIONS");
  }

  /**
   * Adds a Task to the list.
   *
   * @param the the Task to add to the collection
   */
  public void add(Task task)
  {
    tasks.add(task);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the Tasks in the collection
   */
  @Override
  public Iterator<Task> iterator()
  {
    return tasks.iterator();
  }
}