/*
* Copyright (c) 2019-20, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

/**
 * This interface represents a factory class for building a {@link IfLoop}
 * activity.
 * <p>
 * In order to comply with this interface the implementing class needs to return
 * a complete with all children populated.
 * <p>
 * For the method getDefaultIfLoop it should be sufficient to call the default
 * constructor for IfLoop.
 * <p>
 * The method parseIfLoopFromSource is intended for non-default uses. This can
 * be achieved by calling the default constructor and then using the setters to
 * populate the values or by using the properties constructor, IfLoop
 * (Properties properties). In the second case the factory will need to inject a
 * fully populated properties block and then inject a populated Header object.
 * <p>
 * Properties that need to be in the properties block are:
 * <ul>
 * <li>name : the name of the object. the value needs to adhere to UiPath naming
 * standards.</li>
 * </ul>
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.8
 */
public interface IfLoopFactory
{
  /**
   * @return A IfLoop activity with default values.
   */
  public IfLoop getDefaultIfLoop();

  /**
   * @return A IfLoop activity completely populated by the factory.
   */
  public IfLoop parseIfLoopFromSource();
}