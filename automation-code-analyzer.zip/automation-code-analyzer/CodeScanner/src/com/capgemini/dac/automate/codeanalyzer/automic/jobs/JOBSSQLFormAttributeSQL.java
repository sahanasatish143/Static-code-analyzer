/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSSQLFormAttributeSQL
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSSQLFormAttributeSQL object in the context of an editor or in a code
   * translator.
   */
  public JOBSSQLFormAttributeSQL()
  {
    this.properties = new Properties();
    this.setFormshost("");
    this.setLogininfo("");
    this.setPassword("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSSQLFormAttributeSQLFactory interface. All children objects
   * ,inherited from AutomicObject, will be null and are expected to be injected
   * through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSSQLFormAttributeSQL.
   * @see JOBSSQLFormAttributeSQLFactory
   */
  public JOBSSQLFormAttributeSQL(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Formshost.
   *
   * @param Formshost the Formshost value to set
   */
  public void setFormshost(String formshost)
  {
    properties.setProperty("Formshost", formshost);
  }

  /**
   * Standard getter for Formshost.
   *
   * @return the Formshost
   * @returns the Formshost value
   */
  public String getFormshost()
  {
    return properties.getProperty("Formshost");
  }

  /**
   * Standard setter for Logininfo.
   *
   * @param Logininfo the Logininfo value to set
   */
  public void setLogininfo(String logininfo)
  {
    properties.setProperty("Logininfo", logininfo);
  }

  /**
   * Standard getter for Logininfo.
   *
   * @return the Logininfo
   * @returns the Logininfo value
   */
  public String getLogininfo()
  {
    return properties.getProperty("Logininfo");
  }

  /**
   * Standard setter for Password.
   *
   * @param Password the Password value to set
   */
  public void setPassword(String password)
  {
    properties.setProperty("Password", password);
  }

  /**
   * Standard getter for Password.
   *
   * @return the Password
   * @returns the Password value
   */
  public String getPassword()
  {
    return properties.getProperty("Password");
  }
}
