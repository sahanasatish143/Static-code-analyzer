/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSMVSAttribute extends JOBSCITAttribute
{

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSMVSAttribute object in the context of an editor or in a code translator.
   */
  public JOBSMVSAttribute()
  {
    this.properties = new Properties();
    this.setMVS_TypeUC4(1);
    this.setMVS_TypeJCL(0);
    this.setMVS_TypeMVS(0);
    this.setMVS_TypeAEJCL(0);
    this.setMVS_ComplJobOut(2);
    this.setMVS_PugreJob(2);
    this.setMVS_RelMsgClass(2);
    this.setMVS_JobName("");
    this.setMVS_JobClass("");
    this.setMVS_ProgName("");
    this.setMVS_Account("");
    this.setMVS_Priority("");
    this.setMVS_MsgLevel("");
    this.setMVS_MsgClass("");
    this.setMVS_Notify("");
    this.setMVS_Schenv("");
    this.setMVS_Params("");
    this.setMVS_FileName("");
    this.setMVS_GetMsgClass("");
    this.setMVS_RouteMsgClass("");
    this.setMVS_DetermineRetcode("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSMVSAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSMVSAttribute.
   * @see JOBSMVSAttributeFactory
   */
  public JOBSMVSAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for MVS_TypeUC4.
   *
   * @param MVS_TypeUC4 the MVS_TypeUC4 value to set
   */
  public void setMVS_TypeUC4(Integer mvs_TypeUC4)
  {
    properties.setProperty("MVS_TypeUC4", mvs_TypeUC4.toString());
  }

  /**
   * Standard getter for MVS_TypeUC4.
   *
   * @return the MVS_TypeUC4
   * @returns the MVS_TypeUC4 value
   */
  public Integer getMVS_TypeUC4()
  {
    return Integer.parseInt(properties.getProperty("MVS_TypeUC4"));
  }

  /**
   * Standard setter for MVS_TypeJCL.
   *
   * @param MVS_TypeJCL the MVS_TypeJCL value to set
   */
  public void setMVS_TypeJCL(Integer mvs_TypeJCL)
  {
    properties.setProperty("MVS_TypeJCL", mvs_TypeJCL.toString());
  }

  /**
   * Standard getter for MVS_TypeJCL.
   *
   * @return the MVS_TypeJCL
   * @returns the MVS_TypeJCL value
   */
  public Integer getMVS_TypeJCL()
  {
    return Integer.parseInt(properties.getProperty("MVS_TypeJCL"));
  }

  /**
   * Standard setter for MVS_TypeMVS.
   *
   * @param MVS_TypeMVS the MVS_TypeMVS value to set
   */
  public void setMVS_TypeMVS(Integer mvs_TypeMVS)
  {
    properties.setProperty("MVS_TypeMVS", mvs_TypeMVS.toString());
  }

  /**
   * Standard getter for MVS_TypeMVS.
   *
   * @return the MVS_TypeMVS
   * @returns the MVS_TypeMVS value
   */
  public Integer getMVS_TypeMVS()
  {
    return Integer.parseInt(properties.getProperty("MVS_TypeMVS"));
  }

  /**
   * Standard setter for MVS_TypeAEJCL.
   *
   * @param MVS_TypeAEJCL the MVS_TypeAEJCL value to set
   */
  public void setMVS_TypeAEJCL(Integer mvs_TypeAEJCL)
  {
    properties.setProperty("MVS_TypeAEJCL", mvs_TypeAEJCL.toString());
  }

  /**
   * Standard getter for MVS_TypeAEJCL.
   *
   * @return the MVS_TypeAEJCL
   * @returns the MVS_TypeAEJCL value
   */
  public Integer getMVS_TypeAEJCL()
  {
    return Integer.parseInt(properties.getProperty("MVS_TypeAEJCL"));
  }

  /**
   * Standard setter for MVS_ComplJobOut.
   *
   * @param MVS_ComplJobOut the MVS_ComplJobOut value to set
   */
  public void setMVS_ComplJobOut(Integer mvs_ComplJobOut)
  {
    properties.setProperty("MVS_ComplJobOut", mvs_ComplJobOut.toString());
  }

  /**
   * Standard getter for MVS_ComplJobOut.
   *
   * @return the MVS_ComplJobOut
   * @returns the MVS_ComplJobOut value
   */
  public Integer getMVS_ComplJobOut()
  {
    return Integer.parseInt(properties.getProperty("MVS_ComplJobOut"));
  }

  /**
   * Standard setter for MVS_PugreJob.
   *
   * @param MVS_PugreJob the MVS_PugreJob value to set
   */
  public void setMVS_PugreJob(Integer mvs_PugreJob)
  {
    properties.setProperty("MVS_PugreJob", mvs_PugreJob.toString());
  }

  /**
   * Standard getter for MVS_PugreJob.
   *
   * @return the MVS_PugreJob
   * @returns the MVS_PugreJob value
   */
  public Integer getMVS_PugreJob()
  {
    return Integer.parseInt(properties.getProperty("MVS_PugreJob"));
  }

  /**
   * Standard setter for MVS_RelMsgClass.
   *
   * @param MVS_RelMsgClass the MVS_RelMsgClass value to set
   */
  public void setMVS_RelMsgClass(Integer mvs_RelMsgClass)
  {
    properties.setProperty("MVS_RelMsgClass", mvs_RelMsgClass.toString());
  }

  /**
   * Standard getter for MVS_RelMsgClass.
   *
   * @return the MVS_RelMsgClass
   * @returns the MVS_RelMsgClass value
   */
  public Integer getMVS_RelMsgClass()
  {
    return Integer.parseInt(properties.getProperty("MVS_RelMsgClass"));
  }

  /**
   * Standard setter for MVS_JobName.
   *
   * @param MVS_JobName the MVS_JobName value to set
   */
  public void setMVS_JobName(String mvs_JobName)
  {
    properties.setProperty("MVS_JobName", mvs_JobName);
  }

  /**
   * Standard getter for MVS_JobName.
   *
   * @return the MVS_JobName
   * @returns the MVS_JobName value
   */
  public String getMVS_JobName()
  {
    return properties.getProperty("MVS_JobName");
  }

  /**
   * Standard setter for MVS_Schenv.
   *
   * @param MVS_Schenv the MVS_Schenv value to set
   */
  public void setMVS_Schenv(String mvs_Schenv)
  {
    properties.setProperty("MVS_Schenv", mvs_Schenv);
  }

  /**
   * Standard getter for MVS_Schenv.
   *
   * @return the MVS_Schenv
   * @returns the MVS_Schenv value
   */
  public String getMVS_Schenv()
  {
    return properties.getProperty("MVS_Schenv");
  }

  /**
   * Standard setter for MVS_JobClass.
   *
   * @param MVS_JobClass the MVS_JobClass value to set
   */
  public void setMVS_JobClass(String mvs_JobClass)
  {
    properties.setProperty("MVS_JobClass", mvs_JobClass);
  }

  /**
   * Standard getter for MVS_JobClass.
   *
   * @return the MVS_JobClass
   * @returns the MVS_JobClass value
   */
  public String getMVS_JobClass()
  {
    return properties.getProperty("MVS_JobClass");
  }

  /**
   * Standard setter for MVS_ProgName.
   *
   * @param MVS_ProgName the MVS_ProgName value to set
   */
  public void setMVS_ProgName(String mvs_ProgName)
  {
    properties.setProperty("MVS_ProgName", mvs_ProgName);
  }

  /**
   * Standard getter for MVS_ProgName.
   *
   * @return the MVS_ProgName
   * @returns the MVS_ProgName value
   */
  public String getMVS_ProgName()
  {
    return properties.getProperty("MVS_ProgName");
  }

  /**
   * Standard setter for MVS_Account.
   *
   * @param MVS_Account the MVS_Account value to set
   */
  public void setMVS_Account(String mvs_Account)
  {
    properties.setProperty("MVS_Account", mvs_Account);
  }

  /**
   * Standard getter for MVS_Account.
   *
   * @return the MVS_Account
   * @returns the MVS_Account value
   */
  public String getMVS_Account()
  {
    return properties.getProperty("MVS_Account");
  }

  /**
   * Standard setter for MVS_Priority.
   *
   * @param MVS_Priority the MVS_Priority value to set
   */
  public void setMVS_Priority(String mvs_Priority)
  {
    properties.setProperty("MVS_Priority", mvs_Priority);
  }

  /**
   * Standard getter for MVS_Priority.
   *
   * @return the MVS_Priority
   * @returns the MVS_Priority value
   */
  public String getMVS_Priority()
  {
    return properties.getProperty("MVS_Priority");
  }

  /**
   * Standard setter for MVS_MsgLevel.
   *
   * @param MVS_MsgLevel the MVS_MsgLevel value to set
   */
  public void setMVS_MsgLevel(String mvs_MsgLevel)
  {
    properties.setProperty("MVS_MsgLevel", mvs_MsgLevel);
  }

  /**
   * Standard getter for MVS_MsgLevel.
   *
   * @return the MVS_MsgLevel
   * @returns the MVS_MsgLevel value
   */
  public String getMVS_MsgLevel()
  {
    return properties.getProperty("MVS_MsgLevel");
  }

  /**
   * Standard setter for MVS_MsgClass.
   *
   * @param MVS_MsgClass the MVS_MsgClass value to set
   */
  public void setMVS_MsgClass(String mvs_MsgClass)
  {
    properties.setProperty("MVS_MsgClass", mvs_MsgClass);
  }

  /**
   * Standard getter for MVS_MsgClass.
   *
   * @return the MVS_MsgClass
   * @returns the MVS_MsgClass value
   */
  public String getMVS_MsgClass()
  {
    return properties.getProperty("MVS_MsgClass");
  }

  /**
   * Standard setter for MVS_Notify.
   *
   * @param MVS_Notify the MVS_Notify value to set
   */
  public void setMVS_Notify(String mvs_Notify)
  {
    properties.setProperty("MVS_Notify", mvs_Notify);
  }

  /**
   * Standard getter for MVS_Notify.
   *
   * @return the MVS_Notify
   * @returns the MVS_Notify value
   */
  public String getMVS_Notify()
  {
    return properties.getProperty("MVS_Notify");
  }

  /**
   * Standard setter for MVS_Params.
   *
   * @param MVS_Params the MVS_Params value to set
   */
  public void setMVS_Params(String mvs_Params)
  {
    properties.setProperty("MVS_Params", mvs_Params);
  }

  /**
   * Standard getter for MVS_Params.
   *
   * @return the MVS_Params
   * @returns the MVS_Params value
   */
  public String getMVS_Params()
  {
    return properties.getProperty("MVS_Params");
  }

  /**
   * Standard setter for MVS_FileName.
   *
   * @param MVS_FileName the MVS_FileName value to set
   */
  public void setMVS_FileName(String mvs_FileName)
  {
    properties.setProperty("MVS_FileName", mvs_FileName);
  }

  /**
   * Standard getter for MVS_FileName.
   *
   * @return the MVS_FileName
   * @returns the MVS_FileName value
   */
  public String getMVS_FileName()
  {
    return properties.getProperty("MVS_FileName");
  }

  /**
   * Standard setter for MVS_GetMsgClass.
   *
   * @param MVS_GetMsgClass the MVS_GetMsgClass value to set
   */
  public void setMVS_GetMsgClass(String mvs_GetMsgClass)
  {
    properties.setProperty("MVS_GetMsgClass", mvs_GetMsgClass);
  }

  /**
   * Standard getter for MVS_GetMsgClass.
   *
   * @return the MVS_GetMsgClass
   * @returns the MVS_GetMsgClass value
   */
  public String getMVS_GetMsgClass()
  {
    return properties.getProperty("MVS_GetMsgClass");
  }

  /**
   * Standard setter for MVS_RouteMsgClass.
   *
   * @param MVS_RouteMsgClass the MVS_RouteMsgClass value to set
   */
  public void setMVS_RouteMsgClass(String mvs_RouteMsgClass)
  {
    properties.setProperty("MVS_RouteMsgClass", mvs_RouteMsgClass);
  }

  /**
   * Standard getter for MVS_RouteMsgClass.
   *
   * @return the MVS_RouteMsgClass
   * @returns the MVS_RouteMsgClass value
   */
  public String getMVS_RouteMsgClass()
  {
    return properties.getProperty("MVS_RouteMsgClass");
  }

  /**
   * Standard setter for MVS_DetermineRetcode.
   *
   * @param MVS_DetermineRetcode the MVS_DetermineRetcode value to set
   */
  public void setMVS_DetermineRetcode(String mvs_DetermineRetcode)
  {
    properties.setProperty("MVS_DetermineRetcode", mvs_DetermineRetcode);
  }

  /**
   * Standard getter for MVS_DetermineRetcode.
   *
   * @return the MVS_DetermineRetcode
   * @returns the MVS_DetermineRetcode value
   */
  public String getMVS_DetermineRetcode()
  {
    return properties.getProperty("MVS_DetermineRetcode");
  }
}
