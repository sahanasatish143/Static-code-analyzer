/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.calendar;

import java.util.Properties;

/**
 * This class represents an Automic KeywordDynamic under CALE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class KeywordDynamic
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the KeywordDynamicFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for KeywordDynamic.
   * @see KeywordDynamicFactory
   */
  public KeywordDynamic(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * KeywordDynamic under CALE object in the context of an editor or in a code
   * translator.
   */
  public KeywordDynamic()
  {
    this.properties = new Properties();
    this.setDirection("");
    this.setInterval(1);
    this.setIntervalEnd(null);
    this.setIntervalStart(null);
    this.setPeriod(1);
    this.setPeriodEnd(null);
    this.setPeriodStart(null);
    this.setDefDays("");
  }

  /**
   * Standard setter for Direction
   *
   * @param Direction the Direction value to set
   */
  public void setDirection(String direction)
  {
    properties.setProperty("direction", direction);
  }

  /**
   * Standard getter for Direction
   *
   * @return the Direction value
   */
  public String getDirection()
  {
    return properties.getProperty("direction");
  }

  /**
   * Standard setter for DefDays
   *
   * @param DefDays the DefDays value to set
   */
  public void setDefDays(String defDays)
  {
    properties.setProperty("defDays", defDays);
  }

  /**
   * Standard getter for DefDays
   *
   * @return the DefDays value
   */
  public String getDefDays()
  {
    return properties.getProperty("defDays");
  }

  /**
   * Standard setter for PeriodStart
   *
   * @param PeriodStart the PeriodStart value to set
   */
  public void setPeriodStart(Integer periodStart)
  {
    properties.setProperty("periodStart", periodStart.toString());
  }

  /**
   * Standard getter for PeriodStart
   *
   * @return the PeriodStart value
   */
  public Integer getPeriodStart()
  {
    return Integer.parseInt(properties.getProperty("periodStart"));
  }

  /**
   * Standard setter for Period
   *
   * @param Period the Period value to set
   */
  public void setPeriod(Integer period)
  {
    properties.setProperty("period", period.toString());
  }

  /**
   * Standard getter for Period
   *
   * @return the Period value
   */
  public Integer getPeriod()
  {
    return Integer.parseInt(properties.getProperty("period"));
  }

  /**
   * Standard setter for PeriodEnd
   *
   * @param PeriodEnd the PeriodEnd value to set
   */
  public void setPeriodEnd(Integer periodEnd)
  {
    properties.setProperty("periodEnd", periodEnd.toString());
  }

  /**
   * Standard getter for PeriodEnd
   *
   * @return the PeriodEnd value
   */
  public Integer getPeriodEnd()
  {
    return Integer.parseInt(properties.getProperty("periodEnd"));
  }

  /**
   * Standard setter for Interval
   *
   * @param Interval the Interval value to set
   */
  public void setInterval(Integer interval)
  {
    properties.setProperty("interval", interval.toString());
  }

  /**
   * Standard getter for Interval
   *
   * @return the Interval value
   */
  public Integer getInterval()
  {
    return Integer.parseInt(properties.getProperty("interval"));
  }

  /**
   * Standard setter for IntervalStart
   *
   * @param IntervalStart the IntervalStart value to set
   */
  public void setIntervalStart(Integer intervalStart)
  {
    properties.setProperty("intervalStart", intervalStart.toString());
  }

  /**
   * Standard getter for IntervalStart
   *
   * @return the IntervalStart value
   */
  public Integer getIntervalStart()
  {
    return Integer.parseInt(properties.getProperty("intervalStart"));
  }

  /**
   * Standard setter for IntervalEnd
   *
   * @param IntervalEnd the IntervalEnd value to set
   */
  public void setIntervalEnd(Integer intervalEnd)
  {
    properties.setProperty("intervalEnd", intervalEnd.toString());
  }

  /**
   * Standard getter for IntervalEnd
   *
   * @return the IntervalEnd value
   */
  public Integer getIntervalEnd()
  {
    return Integer.parseInt(properties.getProperty("intervalEnd"));
  }

  public void add(KeywordDynamic dynamic)
  {
    dynamic.add(dynamic);

  }
}
