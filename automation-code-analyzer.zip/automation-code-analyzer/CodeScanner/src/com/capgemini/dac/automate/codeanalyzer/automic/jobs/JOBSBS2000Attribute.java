/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSBS2000Attribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSBS2000Attribute object in the context of an editor or in a code
   * translator.
   */
  public JOBSBS2000Attribute()
  {
    this.properties = new Properties();
    this.setLstDb(0);
    this.setLstDbErr(0);
    this.setLstFile(0);
    this.setExpress(0);
    this.setMaxCPU(0);
    this.setPriority("");
    this.setJobClass("");
    this.setOrderName("");
    this.setEnterParameter("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSBS2000AttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSBS2000Attribute.
   * @see JOBSBS2000AttributeFactory
   */
  public JOBSBS2000Attribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for LstDb.
   *
   * @param LstDb the LstDb value to set
   */
  public void setLstDb(Integer lstDb)
  {
    properties.setProperty("LstDb", lstDb.toString());
  }

  /**
   * Standard getter for LstDb.
   *
   * @return the LstDb
   * @returns the LstDb value
   */
  public Integer getLstDb()
  {
    return Integer.parseInt(properties.getProperty("LstDb"));
  }

  /**
   * Standard setter for LstDbErr.
   *
   * @param LstDbErr the LstDbErr value to set
   */
  public void setLstDbErr(Integer lstDbErr)
  {
    properties.setProperty("LstDbErr", lstDbErr.toString());
  }

  /**
   * Standard getter for LstDbErr.
   *
   * @return the LstDbErr
   * @returns the LstDbErr value
   */
  public Integer getLstDbErr()
  {
    return Integer.parseInt(properties.getProperty("LstDbErr"));
  }

  /**
   * Standard setter for LstFile.
   *
   * @param LstFile the LstFile value to set
   */
  public void setLstFile(Integer lstFile)
  {
    properties.setProperty("LstFile", lstFile.toString());
  }

  /**
   * Standard getter for LstFile.
   *
   * @return the LstFile
   * @returns the LstFile value
   */
  public Integer getLstFile()
  {
    return Integer.parseInt(properties.getProperty("LstFile"));
  }

  /**
   * Standard setter for Express.
   *
   * @param Express the Express value to set
   */
  public void setExpress(Integer express)
  {
    properties.setProperty("Express", express.toString());
  }

  /**
   * Standard getter for Express.
   *
   * @return the Express
   * @returns the Express value
   */
  public Integer getExpress()
  {
    return Integer.parseInt(properties.getProperty("Express"));
  }

  /**
   * Standard setter for MaxCPU.
   *
   * @param MaxCPU the MaxCPU value to set
   */
  public void setMaxCPU(Integer maxCPU)
  {
    properties.setProperty("MaxCPU", maxCPU.toString());
  }

  /**
   * Standard getter for MaxCPU.
   *
   * @return the MaxCPU
   * @returns the MaxCPU value
   */
  public Integer getMaxCPU()
  {
    return Integer.parseInt(properties.getProperty("MaxCPU"));
  }

  /**
   * Standard setter for Priority.
   *
   * @param Priority the Priority value to set
   */
  public void setPriority(String priority)
  {
    properties.setProperty("Priority", priority);
  }

  /**
   * Standard getter for Priority.
   *
   * @return the Priority
   * @returns the Priority value
   */
  public String getPriority()
  {
    return properties.getProperty("Priority");
  }

  /**
   * Standard setter for JobClass.
   *
   * @param JobClass the JobClass value to set
   */
  public void setJobClass(String jobClass)
  {
    properties.setProperty("JobClass", jobClass);
  }

  /**
   * Standard getter for JobClass.
   *
   * @return the JobClass
   * @returns the JobClass value
   */
  public String getJobClass()
  {
    return properties.getProperty("JobClass");
  }

  /**
   * Standard setter for OrderName.
   *
   * @param OrderName the OrderName value to set
   */
  public void setOrderName(String orderName)
  {
    properties.setProperty("OrderName", orderName);
  }

  /**
   * Standard getter for OrderName.
   *
   * @return the OrderName
   * @returns the OrderName value
   */
  public String getOrderName()
  {
    return properties.getProperty("OrderName");
  }

  /**
   * Standard setter for EnterParameter.
   *
   * @param EnterParameter the EnterParameter value to set
   */
  public void setEnterParameter(String enterParameter)
  {
    properties.setProperty("EnterParameter", enterParameter);
  }

  /**
   * Standard getter for EnterParameter.
   *
   * @return the EnterParameter
   * @returns the EnterParameter value
   */
  public String getEnterParameter()
  {
    return properties.getProperty("EnterParameter");
  }
}
