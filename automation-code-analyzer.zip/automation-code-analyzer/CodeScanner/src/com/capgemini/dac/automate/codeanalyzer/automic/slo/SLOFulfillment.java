/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.slo;

import java.util.Properties;

/**
 * This class represents an Automic SLOFulfullment object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class SLOFulfillment
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the SLOFulfillmentFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for SLOFulfillment.
   * @seeSLOFulfillmentFactory
   */
  public SLOFulfillment(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * SLOFulfillment object in the context of an editor or in a code translator.
   */
  public SLOFulfillment()
  {
    this.properties = new Properties();
  }

  /**
   * Standard setter for ConsiderMRT
   *
   * @param ConsiderMRT the ConsiderMRT value to set
   */
  public void setConsiderMRT(Integer considerMRT)
  {
    properties.setProperty("ConsiderMRT", considerMRT.toString());
  }

  /**
   * Standard getter for ConsiderMRT
   *
   * @return the ConsiderMRT value
   */
  public Integer getConsiderMRT()
  {
    return Integer.parseInt(properties.getProperty("ConsiderMRT"));
  }

  /**
   * Standard setter for ConsiderSRT
   *
   * @param ConsiderSRT the ConsiderSRT value to set
   */
  public void setConsiderSRT(Integer considerSRT)
  {
    properties.setProperty("ConsiderSRT", considerSRT.toString());
  }

  /**
   * Standard getter for ConsiderSRT
   *
   * @return the ConsiderSRT value
   */
  public Integer getConsiderSRT()
  {
    return Integer.parseInt(properties.getProperty("ConsiderSRT"));
  }

  /**
   * Standard setter for ConsiderStat
   *
   * @param ConsiderStat the ConsiderStat value to set
   */
  public void setConsiderStat(Integer considerStat)
  {
    properties.setProperty("ConsiderStat", considerStat.toString());
  }

  /**
   * Standard getter for ConsiderStat
   *
   * @return the ConsiderStat value
   */
  public Integer getConsiderStat()
  {
    return Integer.parseInt(properties.getProperty("ConsiderStat"));
  }

  /**
   * Standard setter for ExpectStatus
   *
   * @param ExpectStatus the ExpectStatus value to set
   */
  public void setExpectStatus(String expectStatus)
  {
    properties.setProperty("ExpectStatus", expectStatus);
  }

  /**
   * Standard getter for ExpectStatus
   *
   * @return the ExpectStatus value
   */
  public String getExpectStatus()
  {
    return properties.getProperty("ExpectStatus");
  }

  /**
   * Standard setter for ConsiderStartTime
   *
   * @param ConsiderStartTime the ConsiderStartTime value to set
   */
  public void setConsiderStartTime(Integer considerStartTime)
  {
    properties.setProperty("ConsiderStartTime", considerStartTime.toString());
  }

  /**
   * Standard getter for ConsiderStartTime
   *
   * @return the ConsiderStartTime value
   */
  public Integer getConsiderStartTime()
  {
    return Integer.parseInt(properties.getProperty("ConsiderStartTime"));
  }

  /**
   * Standard setter for ConsiderEndTime
   *
   * @param ConsiderEndTime the ConsiderEndTime value to set
   */
  public void setConsiderEndTime(Integer considerEndTime)
  {
    properties.setProperty("ConsiderEndTime", considerEndTime.toString());
  }

  /**
   * Standard getter for ConsiderEndTime
   *
   * @return the ConsiderEndTime value
   */
  public Integer getConsiderEndTime()
  {
    return Integer.parseInt(properties.getProperty("ConsiderEndTime"));
  }

  /**
   * Standard setter for LatestStartTime
   *
   * @param LatestStartTime the LatestStartTime value to set
   */
  public void setLatestStartTime(Integer latestStartTime)
  {
    properties.setProperty("LatestStartTime", latestStartTime.toString());
  }

  /**
   * Standard getter for LatestStartTime
   *
   * @return the LatestStartTime value
   */
  public Integer getLatestStartTime()
  {
    return Integer.parseInt(properties.getProperty("LatestStartTime"));
  }

  /**
   * Standard setter for LatestEndTime
   *
   * @param LatestEndTime the LatestEndTime value to set
   */
  public void setLatestEndTime(Integer latestEndTime)
  {
    properties.setProperty("LatestEndTime", latestEndTime.toString());
  }

  /**
   * Standard getter for LatestEndTime
   *
   * @return the LatestEndTime value
   */
  public Integer getLatestEndTime()
  {
    return Integer.parseInt(properties.getProperty("LatestEndTime"));
  }

  /**
   * Standard setter for OnWeekdays
   *
   * @param OnWeekdays the OnWeekdays value to set
   */
  public void setOnWeekdays(Integer onWeekdays)
  {
    properties.setProperty("OnWeekdays", onWeekdays.toString());
  }

  /**
   * Standard getter for OnWeekdays
   *
   * @return the OnWeekdays value
   */
  public Integer getOnWeekdays()
  {
    return Integer.parseInt(properties.getProperty("OnWeekdays"));
  }

  /**
   * Standard setter for ExeOnFulfill
   *
   * @param ExeOnFulfill the ExeOnFulfill value to set
   */
  public void setExeOnFulfill(Integer exeOnFulfill)
  {
    properties.setProperty("ExeOnFulfill", exeOnFulfill.toString());
  }

  /**
   * Standard getter for ExeOnFulfill
   *
   * @return the ExeOnFulfill value
   */
  public Integer getExeOnFulfill()
  {
    return Integer.parseInt(properties.getProperty("ExeOnFulfill"));
  }

  /**
   * Standard setter for EmlOnFulfill
   *
   * @param EmlOnFulfill the EmlOnFulfill value to set
   */
  public void setEmlOnFulfill(Integer emlOnFulfill)
  {
    properties.setProperty("EmlOnFulfill", emlOnFulfill.toString());
  }

  /**
   * Standard getter for EmlOnFulfill
   *
   * @return the EmlOnFulfill value
   */
  public Integer getEmlOnFulfill()
  {
    return Integer.parseInt(properties.getProperty("EmlOnFulfill"));
  }

  /**
   * Standard setter for OnFulfilObj
   *
   * @param OnFulfilObj the OnFulfilObj value to set
   */
  public void setOnFulfilObj(String onFulfilObj)
  {
    properties.setProperty("OnFulfilObj", onFulfilObj);
  }

  /**
   * Standard getter for OnFulfilObj
   *
   * @return the OnFulfilObj value
   */
  public String getOnFulfilObj()
  {
    return properties.getProperty("OnFulfilObj");
  }

  /**
   * Standard setter for OnFulfillRcp
   *
   * @param OnFulfillRcp the OnFulfillRcp value to set
   */
  public void setOnFulfillRcp(String onFulfillRcp)
  {
    properties.setProperty("OnFulfillRcp", onFulfillRcp);
  }

  /**
   * Standard getter for OnFulfillRcp
   *
   * @return the OnFulfillRcp value
   */
  public String getOnFulfillRcp()
  {
    return properties.getProperty("OnFulfillRcp");
  }

  /**
   * Standard setter for OnViloatObj
   *
   * @param OnViloatObj the OnViloatObj value to set
   */
  public void setOnViloatObj(String onViloatObj)
  {
    properties.setProperty("OnViloatObj", onViloatObj);
  }

  /**
   * Standard getter for OnViloatObj
   *
   * @return the OnViloatObj value
   */
  public String getOnViloatObj()
  {
    return properties.getProperty("OnViloatObj");
  }

  /**
   * Standard setter for OnViolatRcp
   *
   * @param OnViolatRcp the OnViolatRcp value to set
   */
  public void setOnViolatRcp(String onViolatRcp)
  {
    properties.setProperty("OnViolatRcp", onViolatRcp);
  }

  /**
   * Standard getter for OnViolatRcp
   *
   * @return the OnViolatRcp value
   */
  public String getOnViolatRcp()
  {
    return properties.getProperty("OnViolatRcp");
  }

  /**
   * Standard getter for ExeOnViolat
   *
   * @return the ExeOnViolat value
   */
  public Integer getExeOnViolat()
  {
    return Integer.parseInt(properties.getProperty("ExeOnViolat"));
  }

  /**
   * Standard setter for ExeOnViolat
   *
   * @param ExeOnViolat the ExeOnViolat value to set
   */
  public void setExeOnViolat(Integer exeOnViolat)
  {
    properties.setProperty("ExeOnViolat", exeOnViolat.toString());
  }

  /**
   * Standard getter for ExeOnEmlOnViolatViolat
   *
   * @return the EmlOnViolat value
   */
  public Integer getEmlOnViolatt()
  {
    return Integer.parseInt(properties.getProperty("EmlOnViolat"));
  }

  /**
   * Standard setter for EmlOnViolat
   *
   * @param EmlOnViolat the EmlOnViolat value to set
   */
  public void setEmlOnViolat(Integer emlOnViolat)
  {
    properties.setProperty("EmlOnViolat", emlOnViolat.toString());
  }
}
