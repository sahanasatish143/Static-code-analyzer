/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class Header implements AutomicObjectHeader
{
  private Properties properties;

  public Header()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setArchiveKey1("");
    this.setArchiveKey2("");
    this.setOHSubType("");
    this.setTitle("");
  }
  
  public Header(Properties properties)
  {
    this.properties = properties;
  }
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }
  
  @Override
  public String getTitle()
  {
    return properties.getProperty("Title");
  }

  @Override
  public void setTitle(String title)
  {
    properties.setProperty("Title", title);
  }

  @Override
  public String getArchiveKey1()
  {
    return properties.getProperty("ArchiveKey1");
  }

  @Override
  public void setArchiveKey1(String key)
  {
    properties.setProperty("ArchiveKey1", key);
  }

  @Override
  public String getArchiveKey2()
  {
    return properties.getProperty("ArchiveKey2");
  }

  @Override
  public void setArchiveKey2(String key)
  {
    properties.setProperty("ArchiveKey2", key);
  }

  @Override
  public String getOHSubType()
  {
    return properties.getProperty("OH_SubType");
  }

  @Override
  public void setOHSubType(String subtype)
  {
    properties.setProperty("OH_SubType", subtype);
  }

  
}