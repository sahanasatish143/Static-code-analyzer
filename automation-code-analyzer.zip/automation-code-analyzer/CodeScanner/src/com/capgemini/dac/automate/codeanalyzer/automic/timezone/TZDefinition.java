/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.timezone;

import java.util.Properties;

/**
 * This class represents an Automic TZDefinition under TimeZone object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class TZDefinition
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the TZDefinitionFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for TZDefinition.
   * @see TZDefinitionFactory
   */
  public TZDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * TZDefinition under TimeZone object in the context of an editor or in a code
   * translator.
   */
  public TZDefinition()
  {
    this.properties = new Properties();
    this.setState(1);

  }

  /**
   * Standard setter for DlsEmi tag
   *
   * @param DlsEmi the DlsEmi value to set
   */
  public void setDlsEmi(Integer dlsEmi)
  {
    properties.setProperty("dlsEmi", dlsEmi.toString());

  }

  /**
   * Standard getter for DlsEmi tag
   *
   * @return the DlsEmi value
   */
  public Integer getDlsEmi()
  {
    return Integer.parseInt(properties.getProperty("dlsEmi"));
  }

  /**
   * Standard setter for DlsEhh tag
   *
   * @param DlsEhh the DlsEhh value to set
   */
  public void setDlsEhh(Integer dlsEhh)
  {
    properties.setProperty("dlsEhh", dlsEhh.toString());

  }

  /**
   * Standard getter for DlsEhh tag
   *
   * @return the DlsEhh value
   */
  public Integer getDlsEhh()
  {
    return Integer.parseInt(properties.getProperty("dlsEhh"));
  }

  /**
   * Standard setter for DlsEtt tag
   *
   * @param DlsEtt the DlsEtt value to set
   */
  public void setDlsEtt(Integer dlsEtt)
  {
    properties.setProperty("dlsEtt", dlsEtt.toString());

  }

  /**
   * Standard getter for DlsEtt tag
   *
   * @return the DlsEtt value
   */
  public Integer getDlsEtt()
  {
    return Integer.parseInt(properties.getProperty("dlsEtt"));
  }

  /**
   * Standard setter for DlsEwd tag
   *
   * @param DlsEwd the DlsEwd value to set
   */
  public void setDlsEwd(Integer dlsEwd)
  {
    properties.setProperty("dlsEwd", dlsEwd.toString());

  }

  /**
   * Standard getter for DlsEwd tag
   *
   * @return the DlsEwd value
   */
  public Integer getDlsEwd()
  {
    return Integer.parseInt(properties.getProperty("dlsEwd"));
  }

  /**
   * Standard setter for DlsEmo tag
   *
   * @param DlsEmo the DlsEmo value to set
   */
  public void setDlsEmo(Integer dlsEmo)
  {
    properties.setProperty("dlsEmo", dlsEmo.toString());

  }

  /**
   * Standard getter for DlsEmo tag
   *
   * @return the DlsEmo value
   */
  public Integer getDlsEmo()
  {
    return Integer.parseInt(properties.getProperty("dlsEmo"));
  }

  /**
   * Standard setter for DlsSmi tag
   *
   * @param DlsSmi the DlsSmi value to set
   */
  public void setDlsSmi(Integer dlsSmi)
  {
    properties.setProperty("dlsSmi", dlsSmi.toString());

  }

  /**
   * Standard getter for DlsSmi tag
   *
   * @return the DlsSmi value
   */
  public Integer getDlsSmi()
  {
    return Integer.parseInt(properties.getProperty("dlsSmi"));
  }

  /**
   * Standard setter for DlsShh tag
   *
   * @param DlsShh the DlsShh value to set
   */
  public void setDlsShh(Integer dlsShh)
  {
    properties.setProperty("dlsShh", dlsShh.toString());

  }

  /**
   * Standard getter for DlsShh tag
   *
   * @return the DlsShh value
   */
  public Integer getDlsShh()
  {
    return Integer.parseInt(properties.getProperty("dlsShh"));
  }

  /**
   * Standard setter for DlsSwd tag
   *
   * @param DlsSwd the DlsSwd value to set
   */
  public void setDlsSwd(Integer dlsSwd)
  {
    properties.setProperty("dlsSwd", dlsSwd.toString());

  }

  /**
   * Standard getter for DlsSwd tag
   *
   * @return the DlsSwd value
   */
  public Integer getDlsSwd()
  {
    return Integer.parseInt(properties.getProperty("dlsSwd"));
  }

  /**
   * Standard setter for DlsStt tag
   *
   * @param DlsStt the DlsStt value to set
   */
  public void setDlsStt(Integer dlsStt)
  {
    properties.setProperty("dlsStt", dlsStt.toString());

  }

  /**
   * Standard getter for DlsStt tag
   *
   * @return the DlsStt value
   */
  public Integer getDlsStt()
  {
    return Integer.parseInt(properties.getProperty("dlsStt"));
  }

  /**
   * Standard setter for DlsSmo tag
   *
   * @param DlsSmo the DlsSmo value to set
   */
  public void setDlsSmo(Integer dlsSmo)
  {
    properties.setProperty("dlsSmo", dlsSmo.toString());

  }

  /**
   * Standard getter for DlsSmo tag
   *
   * @return the DlsSmo value
   */
  public Integer getDlsSmo()
  {
    return Integer.parseInt(properties.getProperty("dlsSmo"));
  }

  /**
   * Standard setter for DlsDiffmi tag
   *
   * @param DlsDiffmi the DlsDiffmi value to set
   */
  public void setDlsDiffmi(Integer dlsDiffmi)
  {
    properties.setProperty("dlsDiffmi", dlsDiffmi.toString());

  }

  /**
   * Standard getter for DlsSmo tag
   *
   * @return the DlsDiffmi value
   */
  public Integer getDlsDiffmi()
  {
    return Integer.parseInt(properties.getProperty("dlsDiffmi"));
  }

  /**
   * Standard setter for TzDiffmi tag
   *
   * @param TzDiffmi the TzDiffmi value to set
   */
  public void setTzDiffmi(Integer tzDiffmi)
  {
    properties.setProperty("tzDiffmi", tzDiffmi.toString());

  }

  /**
   * Standard getter for TzDiffmi tag
   *
   * @return the TzDiffmi value
   */
  public Integer getTzDiffmi()
  {
    return Integer.parseInt(properties.getProperty("tzDiffmi"));
  }

  /**
   * Standard setter for TzDiffhh tag
   *
   * @param TzDiffhh the TzDiffhh value to set
   */
  public void setTzDiffhh(Integer tzDiffhh)
  {
    properties.setProperty("tzDiffhh", tzDiffhh.toString());

  }

  /**
   * Standard getter for TzDiffhh tag
   *
   * @return the TzDiffhh value
   */
  public Integer getTzDiffhh()
  {
    return Integer.parseInt(properties.getProperty("tzDiffhh"));
  }

  /**
   * Standard setter for Year tag
   *
   * @param Year the Year value to set
   */
  public void setYear(Integer year)
  {
    properties.setProperty("year", year.toString());

  }

  /**
   * Standard getter for Year tag
   *
   * @return the Year value
   */
  public Integer getYear()
  {
    return Integer.parseInt(properties.getProperty("year"));
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

}
