/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.analyzer;

import java.util.ArrayList;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExport;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicObject;
import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathExport;
import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathObject;

/**
 * 
 * 
 * @author
 * @version 1.0
 * @since 1.0
 */
public class EvaluationRuleSet
{
  ArrayList<EvaluationRule> ruleset;

  public EvaluationRuleSet()
  {
    ruleset = new ArrayList<EvaluationRule>();
  }

  public void add(EvaluationRule rule)
  {
    ruleset.add(rule);
  }

  public RuleSetEvaluationReport evaluateRuleSetAgainstAutomation(AutomicExport automation)
  {
    RuleSetEvaluationReport report = new RuleSetEvaluationReport();
    for (AutomicObject object : automation)
    {
      for (EvaluationRule rule : ruleset)
        report.add(rule.evaluate(object));
    }
    return report;
  }
}