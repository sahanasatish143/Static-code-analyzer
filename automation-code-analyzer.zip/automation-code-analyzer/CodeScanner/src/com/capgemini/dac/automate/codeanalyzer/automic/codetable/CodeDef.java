/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.codetable;

import java.util.Properties;

/**
 * This class represents an Automic CodeDef under CODE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CodeDef
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CodeDefFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CodeDef.
   * @see CodeDefFactory
   */
  public CodeDef(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CodeDef under CODE object in the context of an editor or in a code
   * translator.
   */
  public CodeDef()
  {
    this.properties = new Properties();
  }

  /**
   * Standard setter for Data
   *
   * @param Data the Data value to set
   */
  public void setData(Integer data)
  {
    properties.setProperty("data", data.toString());
  }

  /**
   * Standard getter for Data
   *
   * @return the Data value
   */
  public Integer getData()
  {
    return Integer.parseInt(properties.getProperty("data"));
  }

  /**
   * Standard setter for Attr
   *
   * @param Attr the Attr value to set
   */
  public void setAttr(Integer attr)
  {
    properties.setProperty("attr", attr.toString());
  }

  /**
   * Standard getter for Attr
   *
   * @return the Attr value
   */
  public Integer getAttr()
  {
    return Integer.parseInt(properties.getProperty("attr"));
  }
}
