package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VARAEventXMLDefinition
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA backend.
   */
  public VARAEventXMLDefinition()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new VARA backend.
   *
   * @param properties the properties
   */
  public VARAEventXMLDefinition(Properties properties)
  {
    this.properties = properties;

  }
  public void setParameters(ExecParameters parseMembersFromSource)
  {
    properties.getProperty("Parameters");
  }
  
}
