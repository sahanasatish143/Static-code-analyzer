package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VaraParametersRowsFactory
{
  public VaraParametersRows getDefaultVaraParametersRows();
  public VaraParametersRows parseVaraParametersRowsFromSource();
}
