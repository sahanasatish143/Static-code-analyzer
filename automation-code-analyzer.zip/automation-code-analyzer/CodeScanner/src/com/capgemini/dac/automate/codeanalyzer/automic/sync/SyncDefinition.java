/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.sync;

import java.util.Properties;

/**
 * This class represents an Automic SyncAttribute under Sync object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class SyncDefinition
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the SyncDefinitionFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for SyncDefinition.
   * @see SyncDefinitionFactory
   */
  public SyncDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * SyncDefinition under Sync object in the context of an editor or in a code
   * translator.
   */
  public SyncDefinition()
  {
    this.properties = new Properties();
    this.setState("");
    this.setRule("");

  }

  /**
   * Standard setter for Rule tag
   *
   * @param Rule the Rule value to set
   */
  public void setRule(String rule)
  {
    properties.setProperty("rule", rule.toString());

  }

  /**
   * Standard getter for Rule tag
   *
   * @return the Rule value
   */
  public String getRule()
  {
    return properties.getProperty("rule");
  }

  /**
   * Standard setter for State tag
   *
   * @param State the State value to set
   */
  public void setState(String state)
  {
    properties.setProperty("state", state.toString());

  }

  /**
   * Standard getter for State tag
   *
   * @return the State value
   */
  public String getState()
  {
    return properties.getProperty("state");
  }
}
