/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathObject;

/**
 * This class represents an UiPath Assign Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */

public class Assign extends UiPathObject
{

  private List<AssignToValueDefinition> assignToValueDefinition;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * Assign Activity in the context of an editor or in a code translator.
   */
  public Assign()
  {
    this.properties = new Properties();
    assignToValueDefinition = new ArrayList<AssignToValueDefinition>();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the AssignFactory interface. All children objects ,inherited from
   * UiPathObject, will be null and are expected to be injected through setters by
   * the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for Assign.
   * @see AssignFactory
   */
  public Assign(Properties properties)
  {
    this.setProperties(properties);
    assignToValueDefinition = new ArrayList<AssignToValueDefinition>();
  }

  public void add(AssignToValueDefinition object)
  {
    assignToValueDefinition.add(object);

  }
}
