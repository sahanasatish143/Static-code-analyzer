/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.queue;

import java.util.Properties;

/**
 * This class represents an Automic QueueDefinition under Queue object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class QueueDefinition
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the QueueDefinitionFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for QueueDefinition.
   * @see QueueDefinitionFactory
   */
  public QueueDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * QueueDefinition under Queue object in the context of an editor or in a code
   * translator.
   */
  public QueueDefinition()
  {
    this.properties = new Properties();
    this.setMaxSlots(-1);
    this.setPriority(200);
    this.setExceptions("");
    this.setConsiderErt(0);
    this.setTZ("");
  }

  /**
   * Standard setter for MaxSlots
   *
   * @param MaxSlots the MaxSlots value to set
   */
  public void setMaxSlots(Integer maxSlots)
  {
    properties.setProperty("maxSlots", maxSlots.toString());
  }

  /**
   * Standard getter for MaxSlots
   *
   * @return the MaxSlots value
   */
  public Integer getMaxSlots()
  {
    return Integer.parseInt(properties.getProperty("maxSlots"));
  }

  /**
   * Standard setter for ConsiderErt
   *
   * @param ConsiderErt the ConsiderErt value to set
   */
  public void setConsiderErt(Integer considerErt)
  {
    properties.setProperty("considerErt", considerErt.toString());
  }

  /**
   * Standard getter for ConsiderErt
   *
   * @return the ConsiderErt value
   */
  public Integer getConsiderErt()
  {
    return Integer.parseInt(properties.getProperty("considerErt"));
  }

  /**
   * Standard setter for Priority
   *
   * @param Priority the Priority value to set
   */
  public void setPriority(Integer priority)
  {
    properties.setProperty("priority", priority.toString());
  }

  /**
   * Standard getter for Priority
   *
   * @return the Priority value
   */
  public Integer getPriority()
  {
    return Integer.parseInt(properties.getProperty("priority"));
  }

  /**
   * Standard setter for Exceptions tag
   *
   * @param Exceptions the Exceptions value to set
   */
  public void setExceptions(String exceptions)
  {
    properties.setProperty("exceptions", exceptions);
  }

  /**
   * Standard getter for Exceptions tag
   *
   * @return the Exceptions value
   */
  public String getExceptions()
  {
    return properties.getProperty("exceptions");
  }

  /**
   * Standard setter for TZ tag
   *
   * @param TZ the TZ value to set
   */
  public void setTZ(String tZ)
  {
    properties.setProperty("tZ", tZ);
  }

  /**
   * Standard getter for TZ tag
   *
   * @return the TZ value
   */
  public String getTZ()
  {
    return properties.getProperty("tZ");
  }
}
