/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.call;

import java.util.Properties;

/**
 * This class represents an Automic NOTIFICATION under CALL object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class NOTIFICATION
{

  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the NOTIFICATIONFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for NOTIFICATION.
   * @see NOTIFICATIONFactory
   */
  public NOTIFICATION(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * NOTIFICATION under CALL object in the context of an editor or in a code
   * translator.
   */
  public NOTIFICATION()
  {
    this.properties = new Properties();
    this.setSubject("");
    this.setText("");
    this.setAttachReports("");
    this.setReportSrcDb(1);
    this.setReportSrcExt(0);
    this.setReportSrcAll(0);
    this.setAttachFile("");
  }

  /**
   * Standard setter for Subject
   *
   * @param Subject the Subject value to set
   */
  public void setSubject(String subject)
  {
    properties.setProperty("subject", subject);
  }

  /**
   * Standard getter for Subject
   *
   * @return the Subject value
   */
  public String getSubject()
  {
    return properties.getProperty("subject");
  }

  /**
   * Standard setter for Text
   *
   * @param Text the Text value to set
   */
  public void setText(String text)
  {
    properties.setProperty("text", text);
  }

  /**
   * Standard getter for Text
   *
   * @return the Text value
   */
  public String getText()
  {
    return properties.getProperty("text");
  }

  /**
   * Standard setter for AttachReports
   *
   * @param AttachReports the AttachReports value to set
   */
  public void setAttachReports(String attachReports)
  {
    properties.setProperty("attachReports", attachReports);
  }

  /**
   * Standard getter for AttachReports
   *
   * @return the AttachReports value
   */
  public String getAttachReports()
  {
    return properties.getProperty("attachReports");
  }

  /**
   * Standard setter for AttachFile
   *
   * @param AttachFile the AttachFile value to set
   */
  public void setAttachFile(String attachFile)
  {
    properties.setProperty("attachFile", attachFile);
  }

  /**
   * Standard getter for AttachFile
   *
   * @return the AttachFile value
   */
  public String getAttachFile()
  {
    return properties.getProperty("attachFile");
  }

  /**
   * Standard setter for ReportSrcDb
   *
   * @param ReportSrcDb the ReportSrcDb value to set
   */
  public void setReportSrcDb(Integer reportSrcDb)
  {
    properties.setProperty("reportSrcDb", reportSrcDb.toString());
  }

  /**
   * Standard getter for ReportSrcDb
   *
   * @return the ReportSrcDb value
   */
  public Integer getReportSrcDb()
  {
    return Integer.parseInt(properties.getProperty("reportSrcDb"));
  }

  /**
   * Standard setter for ReportSrcExt
   *
   * @param ReportSrcExt the ReportSrcExt value to set
   */
  public void setReportSrcExt(Integer reportSrcExt)
  {
    properties.setProperty("reportSrcExt", reportSrcExt.toString());
  }

  /**
   * Standard getter for ReportSrcExt
   *
   * @return the ReportSrcExt value
   */
  public Integer getReportSrcExt()
  {
    return Integer.parseInt(properties.getProperty("reportSrcExt"));
  }

  /**
   * Standard setter for ReportSrcAll
   *
   * @param ReportSrcAll the ReportSrcAll value to set
   */
  public void setReportSrcAll(Integer reportSrcAll)
  {
    properties.setProperty("reportSrcAll", reportSrcAll.toString());
  }

  /**
   * Standard getter for ReportSrcAll
   *
   * @return the ReportSrcAll value
   */
  public Integer getReportSrcAll()
  {
    return Integer.parseInt(properties.getProperty("reportSrcAll"));
  }
}
