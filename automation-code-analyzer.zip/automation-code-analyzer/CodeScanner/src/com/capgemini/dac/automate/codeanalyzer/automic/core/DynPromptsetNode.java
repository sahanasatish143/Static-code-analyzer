/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * Represents a dynamic promptset node declaration in an Automic executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class DynPromptsetNode implements DynNode
{
  private Properties properties;
  private PromptBox promptbox;

  /**
   * Constructor to build a default DynPromptsetNode object.
   */
  public DynPromptsetNode()
  {
    properties = new Properties();
    promptbox = null;
    this.setContent(1);
    this.setId("VALUE");
    this.setName("Variables");
    this.setParent("");
    this.setType("VALUE");
    this.setClient(0);
    this.setNameinner("");
    this.setIdnr(0);
    this.setOntop(0);
  }
 
  /**
   * Constructor meant to be used by a factory adhering to the DynPromptsetNodeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public DynPromptsetNode(Properties mergeProperties)
  {
    properties = new Properties();
    promptbox = null;
  }

  /**
   * Standard setter for content
   *
   * @param content the content value to set
   */
  public void setContent(Integer content)
  {
    properties.setProperty("content", content.toString());
  }

  /**
   * Standard getter for content
   *
   * @returns the content value
   */
  public Integer getContent()
  {
    return Integer.parseInt(properties.getProperty("content"));
  }

  /**
   * Standard setter for id
   *
   * @param id the id value to set
   */
  public void setId(String id)
  {
    properties.setProperty("id", id);
  }

  /**
   * Standard getter for id
   *
   * @returns the id value
   */
  public String getId()
  {
    return properties.getProperty("id");
  }

  /**
   * Standard setter for name
   *
   * @param name the name value to set
   */
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }

  /**
   * Standard getter for name
   *
   * @returns the name value
   */
  public String getName()
  {
    return properties.getProperty("name");
  }

  /**
   * Standard setter for parent
   *
   * @param parent the parent value to set
   */
  public void setParent(String parent)
  {
    properties.setProperty("parent", parent);
  }

  /**
   * Standard getter for parent
   *
   * @returns the parent value
   */
  public String getParent()
  {
    return properties.getProperty("parent");
  }

  /**
   * Standard setter for type
   *
   * @param type the type value to set
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Standard getter for type
   *
   * @returns the type value
   */
  public String getType()
  {
    return properties.getProperty("type");
  }

  /**
   * Standard setter for client
   *
   * @param client the client value to set
   */
  public void setClient(Integer client)
  {
    properties.setProperty("client", client.toString());
  }

  /**
   * Standard getter for client
   *
   * @returns the client value
   */
  public Integer getClient()
  {
    return Integer.parseInt(properties.getProperty("client"));
  }
  
  /**
   * Standard setter for idnr
   *
   * @param idnr the idnr value to set
   */
  public void setIdnr(Integer idnr)
  {
    properties.setProperty("idnr", idnr.toString());
  }

  /**
   * Standard getter for idnr
   *
   * @returns the idnr value
   */
  public Integer getIdnr()
  {
    return Integer.parseInt(properties.getProperty("idnr"));
  }
  
  /**
   * Standard setter for nameinner
   *
   * @param nameinner the nameinner value to set
   */
  public void setNameinner(String nameinner)
  {
    properties.setProperty("nameinner", nameinner.toString());
  }

  /**
   * Standard getter for nameinner
   *
   * @returns the nameinner value
   */
  public String getNameinner()
  {
    return properties.getProperty("nameinner");
  }
  
  /**
   * Standard setter for ontop
   *
   * @param ontop the ontop value to set
   */
  public void setOntop(Integer ontop)
  {
    properties.setProperty("ontop", ontop.toString());
  }

  /**
   * Standard getter for ontop
   *
   * @returns the ontop value
   */
  public Integer getOntop()
  {
    return Integer.parseInt(properties.getProperty("ontop"));
  }
  
 /**
  * Standard setter for promptbox
  *
  * @param promptbox the promptbox value to set
  */
 public void setPromptBox(PromptBox promptbox)
 {
   this.promptbox = promptbox;
 }

 /**
  * Standard getter for promptbox
  *
  * @returns the promptbox
  */
 public PromptBox getPromptBox()
 {
   return promptbox;
 }
}