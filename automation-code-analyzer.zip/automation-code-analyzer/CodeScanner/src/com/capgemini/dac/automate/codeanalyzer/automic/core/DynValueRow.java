/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * Represents a dynamic value row declaration in an Automic executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class DynValueRow
{
  private Properties properties = null;

  /**
   * Constructor to build a default DynValueRow object.
   */
  public DynValueRow()
  {
    this.properties = new Properties();
    this.setERTUsage(0);
    this.setName("");
    this.setValue("");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the DynValueRowFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public DynValueRow(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Standard setter for ERTUsage
   *
   * @param ertusage the ERTUsage value to set
   */
  public void setERTUsage(Integer ertusage){
    properties.setProperty("ERTUsage", ertusage.toString());
  }
  
  /**
   * Standard getter for ERTUsage
   *
   * @returns the row ERTUsage value
   */
  public Integer getERTUsage(){
    return Integer.parseInt(properties.getProperty("ERTUsage"));
  }
  
  /**
   * Standard setter for Name
   *
   * @param properties the properties to set
   */
  public void setName(String name){
    properties.setProperty("ERTUsage", name);
  }
  
  /**
   * Standard getter for Name
   *
   * @returns the row name
   */
  public String getName(){
    return properties.getProperty("ERTUsage");
  }
  
  /**
   * Standard setter for Value
   *
   * @param properties the properties to set
   */
  public void setValue(String value){
    properties.setProperty("Value", value);
  }
  
  /**
   * Standard getter for Value
   *
   * @returns the row value
   */
  public String getValue(){
    return properties.getProperty("Value");
  }
}