/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.hostg;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;




/**
 * The Class HostG. 
 * it extends the common 
 * base features of an Automic executable object
 */
public class HostG extends AutomicExecutableObject
{
  
  /** The HostG attributes. */
  private HostGDefinition hostGDefinitions;
  
  

  /**
   * Instantiates a new HostG.
   */
  public HostG()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new HostG.
   *
   * @param properties the properties
   */
  public HostG(Properties properties)
  {
    this.properties = properties;
  }

  

  /**
   * Sets the HostG HostGDefinition.
   *
   * @param hostGDefinitions the new host G definition
   */
  public void setHostGDefinition(HostGDefinition hostGDefinitions)
  {
    this.hostGDefinitions = hostGDefinitions;
  }

  /**
   * Gets the HostG attributes.
   *
   * @return the HostG attributes
   */
  public HostGDefinition getHostGDefinition()
  {
    return this.hostGDefinitions;
  }
}