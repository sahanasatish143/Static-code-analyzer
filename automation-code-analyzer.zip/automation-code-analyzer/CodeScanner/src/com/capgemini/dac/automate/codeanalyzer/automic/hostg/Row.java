/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.hostg;

import java.util.Properties;

public class Row
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   * Archive1="sdasd" Archive2="231232" HW="1111" Icon="FILT"
   *  Icontype="" Name="DEMO"
   *  Role="*" SW="dasdasd"
   *   SWVers="sdas" Type="F" Version="dsdfsd111"
   * @param properties2Properties 
   */
  public Row()
  {
    this.properties = new Properties();
    this.setArchiveKey1("");
    this.setArchiveKey2("");
    this.setHW(1111);
    this.setIcon("");
    this.setName("");
    this.setRole("");
    this.setSW("");
    this.setSWVers("");
    this.setType("");
    this.setVersion("");
    
  }
  public Row(Properties properties)
  {
    this.properties = properties;
  }

 
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setArchiveKey1(String archiveKey1)
  {
    properties.setProperty("ArchiveKey1", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getArchiveKey1()
  {
    return properties.getProperty("ArchiveKey1");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setArchiveKey2(String archiveKey2)
  {
    properties.setProperty("ArchiveKey2", archiveKey2);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getArchiveKey2()
  {
    return properties.getProperty("ArchiveKey2");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setHW(Integer hw)
  {
    properties.setProperty("HW", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getHW()
  {
    return properties.getProperty("HW");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setIcon(String icon)
  {
    properties.setProperty("Icon", icon);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getIcon()
  {
    return properties.getProperty("Icon");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setName(String name)
  {
    properties.setProperty("Name", name);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getName()
  {
    return properties.getProperty("Name");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setRole(String role)
  {
    properties.setProperty("Role", role);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getRole()
  {
    return properties.getProperty("Role");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setSW(String sw)
  {
    properties.setProperty("SW", sw);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getSW()
  {
    return properties.getProperty("SW");
  }
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setSWVers(String archiveKey1)
  {
    properties.setProperty("SWVers", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getSWVers()
  {
    return properties.getProperty("SWVers");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setType(String type)
  {
    properties.setProperty("Type", type);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getType()
  {
    return properties.getProperty("Type");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setVersion(String version)
  {
    properties.setProperty("Version", version);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getVersion()
  {
    return properties.getProperty("Version");
  }
  
 
  
}
