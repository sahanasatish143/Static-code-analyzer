/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

/**
 * This class represents an Automic EVNTIAValue object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNTIAValue
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVNTIAValue object in the context of an editor or in a code translator.
   */
  public EVNTIAValue()
  {
    this.properties = new Properties();
    this.setName("");
    this.setValue("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVNTIAValueFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVNTIAValue.
   * @see EVNTIAValueFactory
   */
  public EVNTIAValue(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for value
   *
   * @param value the value value to set
   */
  public void setValue(String value)
  {
    properties.setProperty("value", value);
  }

  /**
   * Standard getter for value
   *
   * @returns the value value
   */
  public String getValue()
  {
    return properties.getProperty("value");
  }

  /**
   * Standard setter for name
   *
   * @param name the name value to set
   */
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }

  /**
   * Standard getter for name
   *
   * @returns the name value
   */
  public String getName()
  {
    return properties.getProperty("name");
  }
}
