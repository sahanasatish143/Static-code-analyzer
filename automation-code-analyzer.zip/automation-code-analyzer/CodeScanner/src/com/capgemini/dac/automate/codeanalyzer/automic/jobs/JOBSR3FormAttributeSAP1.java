/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSR3FormAttributeSAP1
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSR3FormAttributeSAP1 object in the context of an editor or in a code
   * translator.
   */
  public JOBSR3FormAttributeSAP1()
  {
    this.properties = new Properties();
    this.setJobtype(2);
    this.setPrivilege(1);
    this.setFormshost("");
    this.setValues("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSR3FormAttributeSAP1Factory interface. All children objects
   * ,inherited from AutomicObject, will be null and are expected to be injected
   * through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSR3FormAttributeSAP1.
   * @see JOBSR3FormAttributeSAP1Factory
   */
  public JOBSR3FormAttributeSAP1(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Jobtype.
   *
   * @param Jobtype the Jobtype value to set
   */
  public void setJobtype(Integer Jobtype)
  {
    properties.setProperty("Jobtype", Jobtype.toString());
  }

  /**
   * Standard getter for Jobtype.
   *
   * @return the Jobtype
   * @returns the Jobtype value
   */
  public Integer getJobtype()
  {
    return Integer.parseInt(properties.getProperty("Jobtype"));
  }

  /**
   * Standard setter for Privilege.
   *
   * @param Privilege the Privilege value to set
   */
  public void setPrivilege(Integer privilege)
  {
    properties.setProperty("Privilege", privilege.toString());
  }

  /**
   * Standard getter for Privilege.
   *
   * @return the Privilege
   * @returns the Privilege value
   */
  public Integer getPrivilege()
  {
    return Integer.parseInt(properties.getProperty("Privilege"));
  }

  /**
   * Standard setter for Formshost.
   *
   * @param Formshost the Formshost value to set
   */
  public void setFormshost(String formshost)
  {
    properties.setProperty("Formshost", formshost);
  }

  /**
   * Standard getter for Formshost.
   *
   * @return the Formshost
   * @returns the Formshost value
   */
  public String getFormshost()
  {
    return properties.getProperty("Formshost");
  }

  /**
   * Standard setter for Values.
   *
   * @param Values the Values value to set
   */
  public void setValues(String values)
  {
    properties.setProperty("Values", values);
  }

  /**
   * Standard getter for Values.
   *
   * @return the Values
   * @returns the Values value
   */
  public String getValues()
  {
    return properties.getProperty("Values");
  }

}
