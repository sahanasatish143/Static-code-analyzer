package com.capgemini.dac.automate.codeanalyzer.automic.folder;

public interface FolderItem
{

}
