/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.prompt;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

import com.capgemini.dac.automate.codeanalyzer.automic.document.DOCUFactory;


/**
 * The Class Prompt.
 * This is used to parse the prompt related objects and respective tags
 *  which have
 * core executable properties and functionality
 *
 * @author sahana s
 * @version 1.0
 * @since 1.0
 */
public class Prompt extends AutomicExecutableObject
{

  /** The prompt designer. */
  private PromptDesigner promptDesigner;

  /** The prompt set X ui. */
  private PromptSetXUi promptSetXUi;

  /** The prompt set data. */
  private PromptSetData promptSetData;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * DOCU object in the context of an editor or in a code translator.
   */
  public Prompt()
  {
    super();
    this.setName("NEW_DOCUMENT");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the DOCUFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for DOCU.
   * @see DOCUFactory
   */
  public Prompt(Properties properties)
  {
    this.setProperties(properties);
  }

  /**
   * Sets the prompt designer.
   *
   * @param promptDesigner the new prompt designer
   */
  public void setPromptDesigner(PromptDesigner promptDesigner)
  {
    this.promptDesigner = promptDesigner;
  }

  /**
   * Gets the prompt designer.
   *
   * @return the prompt designer
   */
  public PromptDesigner getPromptDesigner()
  {
    return this.promptDesigner;
  }

  /**
   * Sets the prompt set X ui.
   *
   * @param promptSetXUi the new prompt set X ui
   */
  public void setPromptSetXUi(PromptSetXUi promptSetXUi)
  {
    this.promptSetXUi = promptSetXUi;
  }

  /**
   * Gets the prompt set X ui.
   *
   * @return the prompt set X ui
   */
  public PromptSetXUi getPromptSetXUi()
  {
    return this.promptSetXUi;
  }

  /**
   * Sets the prompt set data.
   *
   * @param promptSetData the new prompt set data
   */
  public void setPromptSetData(PromptSetData promptSetData)
  {
    this.promptSetData = promptSetData;
  }

  /**
   * Prompt set data.
   *
   * @return the prompt set data
   */
  public PromptSetData promptSetData()
  {
    return this.promptSetData;
  }

}