package com.capgemini.dac.automate.codeanalyzer.uipath.core;

public interface NamespacesForImplementationFactory
{
  public NamespacesForImplementation getDefaultNamespacesForImplementation();

  public NamespacesForImplementation parseNamespacesForImplementationFromSource();
}
