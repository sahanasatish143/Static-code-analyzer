/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSPSAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSPSAttribute object in the context of an editor or in a code translator.
   */
  public JOBSPSAttribute()
  {
    this.properties = new Properties();
    this.setDeleteProcess("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSPSAttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSPSAttribute.
   * @see JOBSPSAttributeFactory
   */
  public JOBSPSAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for DeleteProcess.
   *
   * @param DeleteProcess the DeleteProcess value to set
   */
  public void setDeleteProcess(String deleteProcess)
  {
    properties.setProperty("DeleteProcess", deleteProcess);
  }

  /**
   * Standard getter for DeleteProcess.
   *
   * @return the DeleteProcess
   * @returns the DeleteProcess value
   */
  public String getDeleteProcess()
  {
    return properties.getProperty("DeleteProcess");
  }

}
