package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.Properties;

public class WorkflowViewStateService
{
  Properties properties;
  private ScgDictionary scgDictionary;

  public WorkflowViewStateService()
  {
    this.properties = new Properties();
    scgDictionary = new ScgDictionary();
  }

  public WorkflowViewStateService(Properties properties)
  {
    this.properties = properties;
    scgDictionary = new ScgDictionary();
  }

  public ScgDictionary getScgDictionary()
  {
    return scgDictionary;
  }

  public void setScgDictionary(ScgDictionary scgDictionary)
  {
    this.scgDictionary = scgDictionary;
  }

}
