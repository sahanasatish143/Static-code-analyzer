/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSOutputReg
{
  private Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSOutputReg object in the context of an editor or in a code translator.
   */
  public JOBSOutputReg()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setFileReg("");
   }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSOutputRegFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSOutputReg.
   * @see JOBSOutputRegFactory
   */
  public JOBSOutputReg(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for FileReg.
   *
   * @param FileReg the FileReg value to set
   */
  public void setFileReg(String fileReg)
  {
    properties.setProperty("FileReg", fileReg);
  }

  /**
   * Standard getter for FileReg.
   *
   * @return the FileReg
   * @returns the FileReg value
   */
  public String getFileReg()
  {
    return properties.getProperty("FileReg");
  }
}
