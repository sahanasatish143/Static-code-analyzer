/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * Represents a Deployment block of an Automic JobP object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class Deployment
{
  private Properties properties;

  /**
   * Constructor to build a default Deployment object.
   */
  public Deployment()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setDeploymentFlag(0);
    this.setWFTypeA(1);
    this.setWFTypeC(0);
    this.setAppName("");
    this.setWFName("");
    this.setComponentName("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the DeploymentFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public Deployment(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for DeploymentFlag
   *
   * @param deploymentFlag the DeploymentFlag value to set
   */
  public void setDeploymentFlag(Integer deploymentFlag)
  {
    properties.setProperty("DeploymentFlag", deploymentFlag.toString());
  }

  /**
   * Standard getter for DeploymentFlag
   *
   * @returns the DeploymentFlag value
   */
  public Integer getDeploymentFlag()
  {
    return Integer.parseInt(properties.getProperty("DeploymentFlag"));
  }

  /**
   * Standard setter for WFTypeA
   *
   * @param wFTypeA the WFTypeA value to set
   */
  public void setWFTypeA(Integer wFTypeA)
  {
    properties.setProperty("WFTypeA", wFTypeA.toString());
  }

  /**
   * Standard getter for WFTypeA
   *
   * @returns the WFTypeA value
   */
  public Integer getWFTypeA()
  {
    return Integer.parseInt(properties.getProperty("WFTypeA"));
  }

  /**
   * Standard setter for WFTypeC
   *
   * @param wFTypeC the WFTypeC value to set
   */
  public void setWFTypeC(Integer wFTypeC)
  {
    properties.setProperty("WFTypeC", wFTypeC.toString());
  }

  /**
   * Standard getter for WFTypeC
   *
   * @returns the WFTypeC value
   */
  public Integer getWFTypeC()
  {
    return Integer.parseInt(properties.getProperty("WFTypeC"));
  }

  /**
   * Standard setter for AppName
   *
   * @param appName the AppName value to set
   */
  public void setAppName(String appName)
  {
    properties.setProperty("AppName", appName);
  }

  /**
   * Standard getter for AppName
   *
   * @returns the AppName value
   */
  public String getAppName()
  {
    return properties.getProperty("AppName");
  }

  /**
   * Standard setter for WFName
   *
   * @param wFName the WFName value to set
   */
  public void setWFName(String wFName)
  {
    properties.setProperty("WFName", wFName);
  }

  /**
   * Standard getter for WFName
   *
   * @returns the WFName value
   */
  public String getWFName()
  {
    return properties.getProperty("WFName");
  }

  /**
   * Standard setter for ComponentName
   *
   * @param ComponentName the ComponentName value to set
   */
  public void setComponentName(String ComponentName)
  {
    properties.setProperty("ComponentName", ComponentName);
  }

  /**
   * Standard getter for ComponentName
   *
   * @returns the ComponentName value
   */
  public String getComponentName()
  {
    return properties.getProperty("ComponentName");
  }
}