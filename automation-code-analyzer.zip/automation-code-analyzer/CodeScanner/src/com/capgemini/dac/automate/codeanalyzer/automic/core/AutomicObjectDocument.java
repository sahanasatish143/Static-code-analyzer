/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

import javax.xml.stream.XMLEventReader;

import com.capgemini.dac.automate.codeanalyzer.automic.document.DOCUFactory;

/**
 * This class holds the information in the document block of an Automic object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.0
 */
public class AutomicObjectDocument
{
  Properties properties;

  /**
   * Default constructor.
   */
  public AutomicObjectDocument()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setType("text");
    this.setBody("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the AutomicObjectDocumentFactory interface. All children objects
   * ,inherited from AutomicObject, will be null and are expected to be injected
   * through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for AutomicObjectDocument.
   * @see AutomicObjectDocumentFactory
   */
  public AutomicObjectDocument(Properties properties)
  {
    this.properties = properties;
  }

  // FIXME this constructor is legacy from before we separated the parsing logic
  // and the object proper. It should be removed after conversion is complete.
  // Currently it just returns the default object.
  /**
   * This constructor is designed to take an XMLEventReader and process the token
   * stream to populate the content of the object. This object is not to be used
   * in new code and will be removed as soon as all exsting classes that reference
   * it have been rewritten.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for DOCU.
   * @see DOCUFactory
   */
  public AutomicObjectDocument(XMLEventReader tokenizer)
  {
    this();
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state section of the object
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for type
   *
   * @param type the type value to set
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Standard getter for type
   *
   * @return the type section of the object
   */
  public String getType()
  {
    return properties.getProperty("type");
  }

  /**
   * Standard setter for body
   *
   * @param body the body value to set
   */
  public void setBody(String body)
  {
    properties.setProperty("body", body);
  }

  /**
   * Standard getter for body
   *
   * @return the body section of the object
   */
  public String getBody()
  {
    return properties.getProperty("body");
  }
}