package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.Properties;

public class NamespacesForImplementation
{
  Properties properties;

  private NamespacesDefinition nameSpacesDefinition;

  public NamespacesForImplementation()
  {
    this.properties = new Properties();
    nameSpacesDefinition = new NamespacesDefinition();
  }

  public NamespacesForImplementation(Properties properties)
  {
    this.properties = properties;
    nameSpacesDefinition = new NamespacesDefinition();

  }

  public NamespacesDefinition getNamepacesDefinition()
  {
    return nameSpacesDefinition;
  }

  public void setNamepacesDefinition(NamespacesDefinition nameSpacesDefinition)
  {
    this.nameSpacesDefinition = nameSpacesDefinition;
  }

}
