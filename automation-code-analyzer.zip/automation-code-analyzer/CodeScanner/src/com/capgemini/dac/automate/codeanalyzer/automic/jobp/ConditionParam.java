/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class ConditionParam
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public ConditionParam()
  {
    this.properties = new Properties();
    this.setAltview(0);
    this.setName("");
    this.setType("V");
    this.setValue("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public ConditionParam(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Standard setter for altview
   *
   * @param altview the altview value to set
   */
  public void setAltview(Integer altview)
  {
    properties.setProperty("altview", altview.toString());
  }

  /**
   * Standard getter for altview
   *
   * @returns the altview value
   */
  public Integer getAltview()
  {
    return Integer.parseInt(properties.getProperty("altview"));
  }
  
  /**
   * Standard setter for name
   *
   * @param name the name value to set
   */
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }

  /**
   * Standard getter for name
   *
   * @returns the name value
   */
  public String getName()
  {
    return properties.getProperty("name");
  }
  
  /**
   * Standard setter for type
   *
   * @param type the type value to set
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Standard getter for type
   *
   * @returns the type value
   */
  public String getType()
  {
    return properties.getProperty("type");
  }
  
  /**
   * Standard setter for value
   *
   * @param value the value value to set
   */
  public void setValue(String value)
  {
    properties.setProperty("value", value);
  }

  /**
   * Standard getter for value
   *
   * @returns the value value
   */
  public String getValue()
  {
    return properties.getProperty("value");
  }
}