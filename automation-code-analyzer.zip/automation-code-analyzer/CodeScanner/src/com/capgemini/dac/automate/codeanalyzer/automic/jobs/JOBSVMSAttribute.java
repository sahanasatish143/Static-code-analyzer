/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSVMSAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSVMSAttribute object in the context of an editor or in a code translator.
   */
  public JOBSVMSAttribute()
  {
    this.properties = new Properties();
    this.setPriority(0);
    this.setJobName("");
    this.setQueueName("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSVMSAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSVMSAttribute.
   * @see JOBSVMSAttributeFactory
   */
  public JOBSVMSAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Priority.
   *
   * @param Priority the Priority value to set
   */
  public void setPriority(Integer priority)
  {
    properties.setProperty("Priority", priority.toString());
  }

  /**
   * Standard getter for Priority.
   *
   * @return the Priority
   * @returns the Priority value
   */
  public Integer getPriority()
  {
    return Integer.parseInt(properties.getProperty("Priority"));
  }

  /**
   * Standard setter for JobName.
   *
   * @param JobName the JobName value to set
   */
  public void setJobName(String jobName)
  {
    properties.setProperty("JobName", jobName);
  }

  /**
   * Standard getter for JobName.
   *
   * @return the JobName
   * @returns the JobName value
   */
  public String getJobName()
  {
    return properties.getProperty("JobName");
  }

  /**
   * Standard setter for QueueName.
   *
   * @param QueueName the QueueName value to set
   */
  public void setQueueName(String queueName)
  {
    properties.setProperty("QueueName", queueName);
  }

  /**
   * Standard getter for QueueName.
   *
   * @return the QueueName
   * @returns the QueueName value
   */
  public String getQueueName()
  {
    return properties.getProperty("QueueName");
  }
}
