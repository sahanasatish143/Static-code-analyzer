package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARAFilelistFactory
{
  public VARAFilelist getDefaultVARAFilelist();
  public VARAFilelist parseVARAFilelistFromSource();
}
