package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionAttributeFactory
{
  public ConnectionAttribute getDefaultConnectionAttribute();
  public ConnectionAttribute parseConnectionAttributeFromSource();
}
