package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class WINDOWS implements Iterable<VaraWindowsRows>
{
  Properties properties;

  /** The rows. */
  private ArrayList<VaraWindowsRows> rows;

  public WINDOWS(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<VaraWindowsRows>();
  }

  public WINDOWS()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<VaraWindowsRows>();
  }

  public void add(VaraWindowsRows members)
  {
    rows.add(members);
  }

  @Override
  public Iterator<VaraWindowsRows> iterator()
  {

    return rows.iterator();
  }

}
