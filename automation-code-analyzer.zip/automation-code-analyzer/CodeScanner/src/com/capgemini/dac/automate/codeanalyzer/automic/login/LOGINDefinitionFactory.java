/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.login;

// TODO: Auto-generated Javadoc
/**
 * A factory for creating LOGINDefinition objects.
 *
 * @author 
 * @version 1.0
 * @since 1.0
 */
public interface LOGINDefinitionFactory
{

  /**
   * Gets the default LOGIN definition.
   *
   * @return the default LOGIN definition
   */
  public LOGINDefinition getDefaultLOGINDefinition();

  /**
   * Parses the LOGIN definition from source.
   *
   * @return the LOGIN definition
   */
  public LOGINDefinition parseLOGINDefinitionFromSource();
}
