/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.call;

import java.util.Properties;

/**
 * This class represents an Automic CondROW under CALL object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CondROW
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CondROW under CALL object in the context of an editor or in a code
   * translator.
   */
  public CondROW()
  {
    this.properties = new Properties();
    this.setCaleKeyName("STATIC");
    this.setId(null);
    this.setUSR_Idnr("");
    this.setEmailAddress("");
    this.setCaleName("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CondROWFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CondROW.
   * @see CondROWFactory
   */
  public CondROW(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for CaleKeyName
   *
   * @param CaleKeyName the CaleKeyName value to set
   */
  public void setCaleKeyName(String caleKeyName)
  {
    properties.setProperty("CaleKeyName", caleKeyName);
  }

  /**
   * Standard getter for CaleKeyName
   *
   * @returns the CaleKeyName value
   */
  public String getCaleKeyName()
  {
    return properties.getProperty("CaleKeyName");
  }

  /**
   * Standard setter for CaleName
   *
   * @param CaleName the CaleName value to set
   */
  public void setCaleName(String caleName)
  {
    properties.setProperty("CaleName", caleName);
  }

  /**
   * Standard getter for CaleName
   *
   * @returns the CaleName value
   */
  public String getCaleName()
  {
    return properties.getProperty("CaleName");
  }

  /**
   * Standard setter for EmailAddress
   *
   * @param EmailAddress the EmailAddress value to set
   */
  public void setEmailAddress(String emailAddress)
  {
    properties.setProperty("EmailAddress", emailAddress);
  }

  /**
   * Standard getter for EmailAddress
   *
   * @returns the EmailAddress value
   */
  public String getEmailAddress()
  {
    return properties.getProperty("EmailAddress");
  }

  /**
   * Standard setter for USR_Idnr
   *
   * @param USR_Idnr the USR_Idnr value to set
   */
  public void setUSR_Idnr(String uSR_Idnr)
  {
    properties.setProperty("USR_Idnr", uSR_Idnr);
  }

  /**
   * Standard getter for USR_Idnr
   *
   * @returns the USR_Idnr value
   */
  public String getUSR_Idnr()
  {
    return properties.getProperty("USR_Idnr");
  }

  /**
   * Standard setter for Id
   *
   * @param Id the Id value to set
   */
  public void setId(Integer id)
  {
    properties.setProperty("Id", id.toString());
  }

  /**
   * Standard getter for Id
   *
   * @returns the Id value
   */
  public Integer getId()
  {
    return Integer.parseInt(properties.getProperty("Id"));
  }
}
