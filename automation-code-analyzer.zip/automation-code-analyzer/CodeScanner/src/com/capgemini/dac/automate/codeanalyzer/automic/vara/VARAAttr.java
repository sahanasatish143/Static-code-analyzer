package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VARAAttr
{
  /** The properties. */
  private Properties properties;

  public VARAAttr()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setType("");
    this.setLblSource("");
    this.setSource("");
    this.setVRName("");
    this.setNotFoundErr(0);
    this.setNotFoundDef(0);
    this.setShareN(0);
    this.setShareL(0);
    this.setShareR(0);
    this.setOutputFormatD("");
    this.setMinValueD("");
    this.setMaxValueD("");
    this.setCheckMinD(1);
    this.setCheckMaxD(1);
    this.setSortColumn(2);
    this.setSortDirection(0);
    this.setHostType("");
    this.setOutputFormatTS("");
    this.setMinValueTS("");
    this.setMaxValueTS("");
    this.setCheckMaxTS(1);
    this.setCheckMinTS(1);
    this.setUpperCase(0);
    this.setMaxValueC(1024);
    this.setCheckMaxC(1);
    this.setOutputFormatN(0);
    this.setMinValueN(1);
    this.setCheckMinN(1);
    this.setMaxValueN(90);
    this.setCheckMaxN(1);
    this.setOutputFormatTI("");
    this.setMinValueTI("");
    this.setCheckMinTI(1);
    this.setMaxValueTI("");
    this.setCheckMaxTI(1);

  }

  public VARAAttr(Properties properties)
  {

    this.properties = properties;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for StartType
   *
   * @param startType the StartType value to set
   */
  public void setType(String type)
  {
    properties.setProperty("Type", type);
  }

  /**
   * Standard getter for StartType
   *
   * @returns the StartType value
   */
  public String getType()
  {
    return properties.getProperty("Type");
  }

  public void setLblSource(String lblSource)
  {
    properties.setProperty("LblSource", lblSource);
  }

  /**
   * Standard getter for LblSource
   *
   * @returns the LblSource value
   */
  public String getLblSource()
  {
    return properties.getProperty("LblSource");
  }

  public void setSource(String Source)
  {
    properties.setProperty("source", Source);
  }

  /**
   * Standard getter for LblSource
   *
   * @returns the LblSource value
   */
  public String getSource()
  {
    return properties.getProperty("source");
  }

  public void setVRName(String Source)
  {
    properties.setProperty("VRName", Source);
  }

  /**
   * Standard getter for LblSource
   *
   * @returns the LblSource value
   */
  public String getVRName()
  {
    return properties.getProperty("VRName");
  }

  public void setNotFoundErr(Integer state)
  {
    properties.setProperty("NotFoundErr", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getNotFoundErr()
  {
    return Integer.parseInt(properties.getProperty("NotFoundErr"));
  }

  public void setNotFoundDef(Integer state)
  {
    properties.setProperty("NotFoundDef", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getNotFoundDef()
  {
    return Integer.parseInt(properties.getProperty("NotFoundDef"));
  }

  public void setShareN(Integer state)
  {
    properties.setProperty("ShareN", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getShareN()
  {
    return Integer.parseInt(properties.getProperty("ShareN"));
  }

  public void setShareL(Integer state)
  {
    properties.setProperty("ShareL", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getShareL()
  {
    return Integer.parseInt(properties.getProperty("ShareL"));
  }

  public void setShareR(Integer state)
  {
    properties.setProperty("ShareR", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getShareR()
  {
    return Integer.parseInt(properties.getProperty("ShareR"));
  }

  public void setOutputFormatD(String deactWhen)
  {
    properties.setProperty("OutputFormat_D", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getOutputFormatD()
  {
    return properties.getProperty("OutputFormat_D");
  }

  public void setMinValueD(String deactWhen)
  {
    properties.setProperty("MinValue_D", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getMinValueD()
  {
    return properties.getProperty("MinValue_D");
  }

  public void setMaxValueD(String deactWhen)
  {
    properties.setProperty("MaxValue_D", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getMaxValueD()
  {
    return properties.getProperty("MaxValue_D");
  }

  public void setHostType(String deactWhen)
  {
    properties.setProperty("HostType", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getHostType()
  {
    return properties.getProperty("HostType");
  }

  public void setOutputFormatTS(String deactWhen)
  {
    properties.setProperty("OutputFormat_TS", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getOutputFormatTS()
  {
    return properties.getProperty("OutputFormat_TS");
  }

  public void setMinValueTS(String deactWhen)
  {
    properties.setProperty("MinValue_TS", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getMinValueTS()
  {
    return properties.getProperty("MinValue_TS");
  }

  public void setMaxValueTS(String deactWhen)
  {
    properties.setProperty("MaxValue_TS", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getMaxValueTS()
  {
    return properties.getProperty("MaxValue_TS");
  }

  public void setOutputFormatTI(String deactWhen)
  {
    properties.setProperty("OutputFormat_TI", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getOutputFormatTI()
  {
    return properties.getProperty("OutputFormat_TI");
  }

  public void setMinValueTI(String deactWhen)
  {
    properties.setProperty("MinValue_TI", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getMinValueTI()
  {
    return properties.getProperty("MinValue_TI");
  }

  public void setMaxValueTI(String deactWhen)
  {
    properties.setProperty("MaxValue_TI", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getMaxValueTI()
  {
    return properties.getProperty("MaxValue_TI");
  }

  public void setCheckMinD(Integer deactDelay)
  {
    properties.setProperty("CheckMin_D", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMinD()
  {
    return Integer.parseInt(properties.getProperty("CheckMin_D"));
  }

  public void setCheckMaxD(Integer deactDelay)
  {
    properties.setProperty("CheckMax_D", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMaxD()
  {
    return Integer.parseInt(properties.getProperty("CheckMax_D"));
  }

  public void setSortColumn(Integer deactDelay)
  {
    properties.setProperty("sortColumn", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getSortColumn()
  {
    return Integer.parseInt(properties.getProperty("sortColumn"));
  }

  public void setSortDirection(Integer deactDelay)
  {
    properties.setProperty("SortDirection", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getSortDirection()
  {
    return Integer.parseInt(properties.getProperty("SortDirection"));
  }

  public void setCheckMaxTS(Integer deactDelay)
  {
    properties.setProperty("CheckMax_TS", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMaxTS()
  {
    return Integer.parseInt(properties.getProperty("CheckMax_TS"));
  }

  public void setCheckMinTS(Integer deactDelay)
  {
    properties.setProperty("CheckMin_TS", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMinTS()
  {
    return Integer.parseInt(properties.getProperty("CheckMin_TS"));
  }

  public void setUpperCase(Integer deactDelay)
  {
    properties.setProperty("uppercase", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getUpperCase()
  {
    return Integer.parseInt(properties.getProperty("uppercase"));
  }

  public void setMaxValueC(Integer deactDelay)
  {
    properties.setProperty("MaxValue_C", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getMaxValueC()
  {
    return Integer.parseInt(properties.getProperty("MaxValue_C"));
  }

  public void setCheckMaxC(Integer deactDelay)
  {
    properties.setProperty("CheckMax_C", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMaxC()
  {
    return Integer.parseInt(properties.getProperty("CheckMax_C"));
  }

  public void setOutputFormatN(Integer deactDelay)
  {
    properties.setProperty("OutputFormat_N", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getOutputFormatN()
  {
    return Integer.parseInt(properties.getProperty("OutputFormat_N"));
  }

  public void setMinValueN(Integer deactDelay)
  {
    properties.setProperty("MinValue_N", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getMinValueN()
  {
    return Integer.parseInt(properties.getProperty("MinValue_N"));
  }

  public void setCheckMinN(Integer deactDelay)
  {
    properties.setProperty("CheckMin_N", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMinN()
  {
    return Integer.parseInt(properties.getProperty("CheckMin_N"));
  }

  public void setMaxValueN(Integer deactDelay)
  {
    properties.setProperty("MaxValue_N", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getMaxValueN()
  {
    return Integer.parseInt(properties.getProperty("MaxValue_N"));
  }

  public void setCheckMaxN(Integer deactDelay)
  {
    properties.setProperty("CheckMax_N", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMaxN()
  {
    return Integer.parseInt(properties.getProperty("CheckMax_N"));
  }

  public void setCheckMinTI(Integer deactDelay)
  {
    properties.setProperty("CheckMin_TI", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMinTI()
  {
    return Integer.parseInt(properties.getProperty("CheckMin_TI"));
  }

  public void setCheckMaxTI(Integer deactDelay)
  {
    properties.setProperty("CheckMax_TI", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getCheckMaxTI()
  {
    return Integer.parseInt(properties.getProperty("CheckMax_TI"));
  }

}
