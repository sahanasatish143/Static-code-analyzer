/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

import java.util.Properties;

/**
 * The Class Operator.
 */
public class Operator
{

  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new operator.
   */
  public Operator()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new operator.
   *
   * @param properties the properties
   */
  public Operator(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the op.
   *
   * @param state the new op
   */
  public void setOp(String op)
  {
    properties.setProperty("Op", op);
  }

  /**
   * Gets the op.
   *
   * @return the op
   */
  public Integer getOp()
  {
    return Integer.parseInt(properties.getProperty("Op"));
  }

}
