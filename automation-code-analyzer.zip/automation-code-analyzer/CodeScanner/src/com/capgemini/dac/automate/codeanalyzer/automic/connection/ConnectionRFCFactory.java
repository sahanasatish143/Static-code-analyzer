package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionRFCFactory
{
  public ConnectionRFC getDefaultConnectionRFC();
  public ConnectionRFC parseConnectionRFCFromSource();
}
