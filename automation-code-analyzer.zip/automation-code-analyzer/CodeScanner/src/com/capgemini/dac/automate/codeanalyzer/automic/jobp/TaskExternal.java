/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * 
 * 
 * @author
 * @version 1.0
 * @since 1.8
 */
public class TaskExternal
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public TaskExternal()
  {
    this.properties = new Properties();
    this.setExtElseA(0);
    this.setExtElseAlarm(0);
    this.setExtElseS(0);
    this.setExtElseW(1);
    this.setExtExecute("");
    this.setExtSLTTypeL(1);
    this.setExtSLTTypeN(0);
    this.setExtSLTTypeS(0);
    this.setExtSLTTypeT(0);
    this.setExtSLTWithin(0);
    this.setExtTimeout(0);
    this.setExtTimeoutA(0);
    this.setExtTimeoutEA(0);
    this.setExtTimeoutES(0);
    this.setExtTimeoutEW(1);
    this.setExtTimeoutFlag(0);
    this.setExtWhen("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskExternal(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for ExtElseA
   *
   * @param extElseA the ExtElseA value to set
   */
  public void setExtElseA(Integer extElseA)
  {
    properties.setProperty("ExtElseA", extElseA.toString());
  }

  /**
   * Standard getter for ExtElseA
   *
   * @returns the ExtElseA value
   */
  public Integer getExtElseA()
  {
    return Integer.parseInt(properties.getProperty("ExtElseA"));
  }

  /**
   * Standard setter for ExtElseAlarm
   *
   * @param extElseAlarm the ExtElseAlarm value to set
   */
  public void setExtElseAlarm(Integer extElseAlarm)
  {
    properties.setProperty("ExtElseAlarm", extElseAlarm.toString());
  }

  /**
   * Standard getter for ExtElseAlarm
   *
   * @returns the ExtElseAlarm value
   */
  public Integer getExtElseAlarm()
  {
    return Integer.parseInt(properties.getProperty("ExtElseAlarm"));
  }

  /**
   * Standard setter for ExtElseS
   *
   * @param extElseS the id value to set
   */
  public void setExtElseS(Integer extElseS)
  {
    properties.setProperty("ExtElseS", extElseS.toString());
  }

  /**
   * Standard getter for ExtElseS
   *
   * @returns the ExtElseS value
   */
  public Integer getExtElseS()
  {
    return Integer.parseInt(properties.getProperty("ExtElseS"));
  }

  /**
   * Standard setter for ExtElseW
   *
   * @param extElseW the ExtElseW value to set
   */
  public void setExtElseW(Integer extElseW)
  {
    properties.setProperty("ExtElseW", extElseW.toString());
  }

  /**
   * Standard getter for ExtElseW
   *
   * @returns the ExtElseW value
   */
  public Integer getExtElseW()
  {
    return Integer.parseInt(properties.getProperty("ExtElseW"));
  }

  /**
   * Standard setter for ExtExecute
   *
   * @param ExtExecute the ExtExecute value to set
   */
  public void setExtExecute(String ExtExecute)
  {
    properties.setProperty("ExtExecute", ExtExecute);
  }

  /**
   * Standard getter for ExtExecute
   *
   * @returns the ExtExecute value
   */
  public String getExtExecute()
  {
    return properties.getProperty("ExtExecute");
  }

  /**
   * Standard setter for ExtSLTTypeL
   *
   * @param extSLTTypeL the ExtSLTTypeL value to set
   */
  public void setExtSLTTypeL(Integer extSLTTypeL)
  {
    properties.setProperty("ExtSLTTypeL", extSLTTypeL.toString());
  }

  /**
   * Standard getter for ExtSLTTypeL
   *
   * @returns the ExtSLTTypeL value
   */
  public Integer getExtSLTTypeL()
  {
    return Integer.parseInt(properties.getProperty("ExtSLTTypeL"));
  }

  /**
   * Standard setter for ExtSLTTypeN
   *
   * @param extSLTTypeN the ExtSLTTypeN value to set
   */
  public void setExtSLTTypeN(Integer extSLTTypeN)
  {
    properties.setProperty("ExtSLTTypeN", extSLTTypeN.toString());
  }

  /**
   * Standard getter for ExtSLTTypeN
   *
   * @returns the ExtSLTTypeN value
   */
  public Integer getExtSLTTypeN()
  {
    return Integer.parseInt(properties.getProperty("ExtSLTTypeN"));
  }

  /**
   * Standard setter for ExtSLTTypeS
   *
   * @param extSLTTypeS the ExtSLTTypeS value to set
   */
  public void setExtSLTTypeS(Integer extSLTTypeS)
  {
    properties.setProperty("ExtSLTTypeS", extSLTTypeS.toString());
  }

  /**
   * Standard getter for ExtSLTTypeS
   *
   * @returns the ExtSLTTypeS value
   */
  public Integer getExtSLTTypeS()
  {
    return Integer.parseInt(properties.getProperty("ExtSLTTypeS"));
  }

  /**
   * Standard setter for ExtSLTTypeT
   *
   * @param extSLTTypeT the ExtSLTTypeT value to set
   */
  public void setExtSLTTypeT(Integer extSLTTypeT)
  {
    properties.setProperty("ExtSLTTypeT", extSLTTypeT.toString());
  }

  /**
   * Standard getter for ExtSLTTypeT
   *
   * @returns the ExtSLTTypeT value
   */
  public Integer getExtSLTTypeT()
  {
    return Integer.parseInt(properties.getProperty("ExtSLTTypeT"));
  }

  /**
   * Standard setter for ExtSLTWithin
   *
   * @param extSLTWithin the ExtSLTWithin value to set
   */
  public void setExtSLTWithin(Integer extSLTWithin)
  {
    properties.setProperty("ExtSLTWithin", extSLTWithin.toString());
  }

  /**
   * Standard getter for ExtSLTWithin
   *
   * @returns the ExtSLTWithin value
   */
  public Integer getExtSLTWithin()
  {
    return Integer.parseInt(properties.getProperty("ExtSLTWithin"));
  }

  /**
   * Standard setter for ExtTimeout
   *
   * @param extTimeout the ExtTimeout value to set
   */
  public void setExtTimeout(Integer extTimeout)
  {
    properties.setProperty("ExtTimeout", extTimeout.toString());
  }

  /**
   * Standard getter for ExtTimeout
   *
   * @returns the ExtTimeout value
   */
  public Integer getExtTimeout()
  {
    return Integer.parseInt(properties.getProperty("ExtTimeout"));
  }

  /**
   * Standard setter for ExtTimeoutA
   *
   * @param ExtTimeoutA the ExtTimeoutA value to set
   */
  public void setExtTimeoutA(Integer ExtTimeoutA)
  {
    properties.setProperty("ExtTimeoutA", ExtTimeoutA.toString());
  }

  /**
   * Standard getter for ExtTimeoutA
   *
   * @returns the ExtTimeoutA value
   */
  public Integer getExtTimeoutA()
  {
    return Integer.parseInt(properties.getProperty("ExtTimeoutA"));
  }

  /**
   * Standard setter for ExtTimeoutEA
   *
   * @param extTimeoutEA the ExtTimeoutEA value to set
   */
  public void setExtTimeoutEA(Integer extTimeoutEA)
  {
    properties.setProperty("ExtTimeoutEA", extTimeoutEA.toString());
  }

  /**
   * Standard getter for ExtTimeoutEA
   *
   * @returns the ExtTimeoutEA value
   */
  public Integer getExtTimeoutEA()
  {
    return Integer.parseInt(properties.getProperty("ExtTimeoutEA"));
  }

  /**
   * Standard setter for ExtTimeoutES
   *
   * @param extTimeoutES the ExtTimeoutES value to set
   */
  public void setExtTimeoutES(Integer extTimeoutES)
  {
    properties.setProperty("ExtTimeoutES", extTimeoutES.toString());
  }

  /**
   * Standard getter for ExtTimeoutES
   *
   * @returns the ExtTimeoutES value
   */
  public Integer getExtTimeoutES()
  {
    return Integer.parseInt(properties.getProperty("ExtTimeoutES"));
  }

  /**
   * Standard setter for ExtTimeoutEW
   *
   * @param extTimeoutEW the ExtTimeoutEW value to set
   */
  public void setExtTimeoutEW(Integer extTimeoutEW)
  {
    properties.setProperty("ExtTimeoutEW", extTimeoutEW.toString());
  }

  /**
   * Standard getter for ExtTimeoutEW
   *
   * @returns the ExtTimeoutEW value
   */
  public Integer getExtTimeoutEW()
  {
    return Integer.parseInt(properties.getProperty("ExtTimeoutEW"));
  }

  /**
   * Standard setter for ExtTimeoutFlag
   *
   * @param extTimeoutFlag the ExtTimeoutFlag value to set
   */
  public void setExtTimeoutFlag(Integer extTimeoutFlag)
  {
    properties.setProperty("ExtTimeoutFlag", extTimeoutFlag.toString());
  }

  /**
   * Standard getter for ExtTimeoutFlag
   *
   * @returns the ExtTimeoutFlag value
   */
  public Integer getExtTimeoutFlag()
  {
    return Integer.parseInt(properties.getProperty("ExtTimeoutFlag"));
  }

  /**
   * Standard setter for ExtWhen
   *
   * @param extWhen the ExtWhen value to set
   */
  public void setExtWhen(String extWhen)
  {
    properties.setProperty("ExtWhen", extWhen);
  }

  /**
   * Standard getter for ExtWhen
   *
   * @returns the ExtWhen value
   */
  public String getExtWhen()
  {
    return properties.getProperty("ExtWhen");
  }
}