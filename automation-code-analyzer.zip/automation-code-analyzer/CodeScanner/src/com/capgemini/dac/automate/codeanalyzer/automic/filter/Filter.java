/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.filter;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

/**
 * The Class Filter.
 *
 *
 * this class is used to parse the filter object this has aproperty pojo
 * 
 * @author sahana s
 * @version 1.0
 * @since 1.0
 */

/*
 * This class extends all the executable objects under the automic
 */
public class Filter extends AutomicExecutableObject
{

  /** The filter attributes. */
  private FilterOutput filterAttributes;

  /**
   * Instantiates a new filter.
   */
  public Filter()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new filter.
   *
   * @param properties the properties
   */
  public Filter(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Sets the script attributes.
   *
   * @param filterAttributes the new script attributes
   */
  public void setFilterOutput(FilterOutput filterAttributes)
  {
    this.filterAttributes = filterAttributes;
  }

  /**
   * Gets the filter attributes.
   *
   * @return the filter attributes
   */
  public FilterOutput getFilterOutput()
  {
    return this.filterAttributes;
  }
}