package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARAFactory
{
public VARA getDefaultVARA();
public VARA parseVARAFromSource();
}
