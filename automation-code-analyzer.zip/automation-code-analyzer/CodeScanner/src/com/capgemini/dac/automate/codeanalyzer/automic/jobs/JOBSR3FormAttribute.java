/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSR3FormAttribute
{
  Properties properties;
  private JOBSR3FormAttributeSAP1 jobsR3FormAttributeSAP1;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSR3FormAttribute object in the context of an editor or in a code
   * translator.
   */
  public JOBSR3FormAttribute()
  {
    this.properties = new Properties();
    this.setState(1);

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSR3FormAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSR3FormAttribute.
   * @see JOBSR3FormAttributeFactory
   */
  public JOBSR3FormAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard getter for JOBSR3FormAttributeSAP1
   *
   * @return the JOBSR3FormAttributeSAP1 value
   */
  public JOBSR3FormAttributeSAP1 getJOBSR3FormAttributeSAP1()
  {
    return jobsR3FormAttributeSAP1;
  }

  /**
   * Standard setter for JOBSR3FormAttributeSAP1
   *
   * @param JOBSR3FormAttributeSAP1 the JOBSR3FormAttributeSAP1 value to set
   */
  public void setJOBSR3FormAttributeSAP1(JOBSR3FormAttributeSAP1 jobsR3FormAttributeSAP1)
  {
    this.jobsR3FormAttributeSAP1 = jobsR3FormAttributeSAP1;
  }
}
