package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class CitPanel implements Iterable<Component>
{
  Properties properties;
  /** The comp. */
  private ArrayList<Component> comp;
  /**
   * Instantiates a new connection cit.
   */
  public CitPanel()
  {
    this.properties = new Properties();
    this.comp = new ArrayList<Component>();

  }

  /**
   * Instantiates a new connection cit.
   *
   * @param properties the properties
   */
  public CitPanel(Properties properties)
  {
    this.properties = properties;
    this.comp = new ArrayList<Component>();
  }

  /**
   * Standard setter for type.
   *
   * @param type the type value to set
   */
  public void setType(Integer state)
  {
    properties.setProperty("type", state.toString());
  }

  /**
   * Standard getter for type.
   *
   * @return the type value
   */
  public Integer getType()
  {
    return Integer.parseInt(properties.getProperty("type"));
  }
  public void setCon(Integer state)
  {
    properties.setProperty("con", state.toString());
  }

  /**
   * Standard getter for type.
   *
   * @return the type value
   */
  public Integer getCon()
  {
    return Integer.parseInt(properties.getProperty("con"));
  }

  public void add(Component comps)
  {
    comp.add(comps);
  }
  @Override
  public Iterator<Component> iterator()
  {
    return comp.iterator();
  
  }
}
