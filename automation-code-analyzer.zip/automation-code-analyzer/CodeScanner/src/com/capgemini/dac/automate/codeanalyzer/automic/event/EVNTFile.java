/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

/**
 * This class represents an Automic EVNTFile object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNTFile extends EVNTDefinition
{

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVNTFile object in the context of an editor or in a code translator.
   */
  public EVNTFile()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVNTFileFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVNTFile.
   * @see EVNTFileFactory
   */
  public EVNTFile(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for HostDst
   *
   * @param HostDst the HostDst value to set
   */
  public void setHostDst(String hostDst)
  {
    properties.setProperty("HostDst", hostDst);
  }

  /**
   * Standard getter for HostDst
   *
   * @return the HostDst value
   */
  public String getHostDst()
  {
    return properties.getProperty("HostDst");
  }

  /**
   * Standard setter for Login
   *
   * @param Login the Login value to set
   */
  public void setLogin(String login)
  {
    properties.setProperty("Login", login);
  }

  /**
   * Standard getter for Login
   *
   * @return the Login value
   */
  public String getLogin()
  {
    return properties.getProperty("Login");
  }

  /**
   * Standard setter for CLOSEOUTPUT
   *
   * @param CLOSEOUTPUT the CLOSEOUTPUT value to set
   */
  public void setCLOSEOUTPUT(Integer closeOUTPUT)
  {
    properties.setProperty("CLOSEOUTPUT", closeOUTPUT.toString());
  }

  /**
   * Standard getter for CLOSEOUTPUT
   *
   * @return the CLOSEOUTPUT value
   */
  public Integer getCLOSEOUTPUT()
  {
    return Integer.parseInt(properties.getProperty("CLOSEOUTPUT"));
  }

  /**
   * Standard setter for StartUpEvnt
   *
   * @param StartUpEvnt the StartUpEvnt value to set
   */
  public void setStartUpEvnt(String startUpEvnt)
  {
    properties.setProperty("StartUpEvnt", startUpEvnt);
  }

  /**
   * Standard getter for StartUpEvnt
   *
   * @return the StartUpEvnt value
   */
  public String getStartUpEvnt()
  {
    return properties.getProperty("StartUpEvnt");
  }

  /**
   * Standard setter for Path
   *
   * @param Path the Path value to set
   */
  public void setPath(String path)
  {
    properties.setProperty("Path", path);
  }

  /**
   * Standard getter for Path
   *
   * @return the Path value
   */
  public String getPath()
  {
    return properties.getProperty("Path");
  }

  /**
   * Standard setter for InclSubDir
   *
   * @param InclSubDir the InclSubDir value to set
   */
  public void setInclSubDir(Integer inclSubDir)
  {
    properties.setProperty("InclSubDir", inclSubDir.toString());
  }

  /**
   * Standard getter for InclSubDir
   *
   * @return the InclSubDir value
   */
  public Integer getInclSubDir()
  {
    return Integer.parseInt(properties.getProperty("InclSubDir"));
  }

  /**
   * Standard setter for FileType
   *
   * @param FileType the FileType value to set
   */
  public void setFileType(String fileType)
  {
    properties.setProperty("FileType", fileType);
  }

  /**
   * Standard getter for FileType
   *
   * @return the FileType value
   */
  public String getFileTypePath()
  {
    return properties.getProperty("FileType");
  }

  /**
   * Standard setter for Operator
   *
   * @param Operator the Operator value to set
   */
  public void setOperator(String operator)
  {
    properties.setProperty("Operator", operator);
  }

  /**
   * Standard getter for Operator
   *
   * @return the Operator value
   */
  public String getOperator()
  {
    return properties.getProperty("Operator");
  }

  /**
   * Standard setter for Unit
   *
   * @param Unit the Unit value to set
   */
  public void setUnit(String unit)
  {
    properties.setProperty("Unit", unit);
  }

  /**
   * Standard getter for Unit
   *
   * @return the Unit value
   */
  public String getUnit()
  {
    return properties.getProperty("Unit");
  }

  /**
   * Standard setter for Value
   *
   * @param Value the Value value to set
   */
  public void setValue(Integer value)
  {
    properties.setProperty("Value", value.toString());
  }

  /**
   * Standard getter for Value
   *
   * @return the Value value
   */
  public Integer getValue()
  {
    return Integer.parseInt(properties.getProperty("Value"));
  }

  /**
   * Standard setter for ConsiderAll
   *
   * @param ConsiderAll the ConsiderAll value to set
   */
  public void setConsiderAll(Integer considerAll)
  {
    properties.setProperty("ConsiderAll", considerAll.toString());
  }

  /**
   * Standard getter for ConsiderAll
   *
   * @return the ConsiderAll value
   */
  public Integer getConsiderAll()
  {
    return Integer.parseInt(properties.getProperty("ConsiderAll"));
  }

  /**
   * Standard setter for CheckWithin
   *
   * @param CheckWithin the CheckWithin value to set
   */
  public void setCheckWithin(Integer checkWithin)
  {
    properties.setProperty("CheckWithin", checkWithin.toString());
  }

  /**
   * Standard getter for CheckWithin
   *
   * @return the CheckWithin value
   */
  public Integer getCheckWithin()
  {
    return Integer.parseInt(properties.getProperty("CheckWithin"));
  }

  /**
   * Standard setter for FileType2
   *
   * @param FileType2 the FileType2 value to set
   */
  public void setFileType2(String fileType2)
  {
    properties.setProperty("FileType2", fileType2);
  }

  /**
   * Standard getter for FileType2
   *
   * @return the FileType2 value
   */
  public String getFileType2()
  {
    return properties.getProperty("FileType2");
  }

  /**
   * Standard setter for HostType
   *
   * @param HostType the HostType value to set
   */
  public void setHostType(String hostType)
  {
    properties.setProperty("HostType", hostType);
  }

  /**
   * Standard getter for HostType
   *
   * @return the HostType value
   */
  public String getHostType()
  {
    return properties.getProperty("HostType");
  }

}
