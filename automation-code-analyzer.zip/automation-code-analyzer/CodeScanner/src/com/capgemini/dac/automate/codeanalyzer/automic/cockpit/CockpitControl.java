/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.cockpit;

import java.util.Properties;

/**
 * This class represents an Automic CockpitControl under CPIT object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CockpitControl
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CockpitControl interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CockpitControl.
   * @see CockpitControlFactory
   */
  public CockpitControl(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CockpitControl under CPIT object in the context of an editor or in a code
   * translator.
   */
  public CockpitControl()
  {
    this.properties = new Properties();
    this.setCaption("");
    this.setAppearance(1);
    this.setContainer(0);
    this.setFont("");
    this.setFontSize("");
    this.setLnr(1);
    this.setFontBold(0);
    this.setMax1(0);
    this.setMax2(0);
    this.setMax3(100);
    this.setFontItalic(0);
    this.setMin(0);
    this.setMinCol("");
    this.setStyle(1);
    this.setValueType(0);
    this.setHeight(130);
    this.setLeft(100);
    this.setTop(0);
    this.setWidth(80);
    this.setQName("");
    this.setQName2("");
    this.setQType("");
  }

  /**
   * Standard setter for MinCol
   *
   * @param MinCol the MinCol value to set
   */
  public void setMinCol(String minCol)
  {
    properties.setProperty("minCol", minCol);
  }

  /**
   * Standard getter for MinCol
   *
   * @return the MinCol value
   */
  public String getMinCol()
  {
    return properties.getProperty("minCol");
  }

  /**
   * Standard setter for FontSize
   *
   * @param FontSize the FontSize value to set
   */
  public void setFontSize(String fontSize)
  {
    properties.setProperty("fontSize", fontSize);
  }

  /**
   * Standard getter for FontSize
   *
   * @return the FontSize value
   */
  public String getFontSize()
  {
    return properties.getProperty("fontSize");
  }

  /**
   * Standard setter for Font
   *
   * @param Font the Font value to set
   */
  public void setFont(String font)
  {
    properties.setProperty("font", font);
  }

  /**
   * Standard getter for Font
   *
   * @return the Font value
   */
  public String getFont()
  {
    return properties.getProperty("font");
  }

  /**
   * Standard setter for Caption
   *
   * @param Caption the Caption value to set
   */
  public void setCaption(String caption)
  {
    properties.setProperty("caption", caption);
  }

  /**
   * Standard getter for Caption
   *
   * @return the Caption value
   */
  public String getCaption()
  {
    return properties.getProperty("caption");
  }

  /**
   * Standard setter for Appearance
   *
   * @param Appearance the Appearance value to set
   */
  public void setAppearance(Integer appearance)
  {
    properties.setProperty("appearance", appearance.toString());
  }

  /**
   * Standard getter for Appearance
   *
   * @return the Appearance value
   */
  public Integer getAppearance()
  {
    return Integer.parseInt(properties.getProperty("appearance"));
  }

  /**
   * Standard setter for Container
   *
   * @param Container the Container value to set
   */
  public void setContainer(Integer container)
  {
    properties.setProperty("container", container.toString());
  }

  /**
   * Standard getter for Container
   *
   * @return the Container value
   */
  public Integer getContainer()
  {
    return Integer.parseInt(properties.getProperty("container"));
  }

  /**
   * Standard setter for FontBold
   *
   * @param FontBold the FontBold value to set
   */
  public void setFontBold(Integer fontBold)
  {
    properties.setProperty("fontBold", fontBold.toString());
  }

  /**
   * Standard getter for FontBold
   *
   * @return the FontBold value
   */
  public Integer getFontBold()
  {
    return Integer.parseInt(properties.getProperty("fontBold"));
  }

  /**
   * Standard setter for Lnr
   *
   * @param Lnr the Lnr value to set
   */
  public void setLnr(Integer lnr)
  {
    properties.setProperty("lnr", lnr.toString());
  }

  /**
   * Standard getter for Lnr
   *
   * @return the Lnr value
   */
  public Integer getLnr()
  {
    return Integer.parseInt(properties.getProperty("lnr"));
  }

  /**
   * Standard setter for Max1
   *
   * @param Max1 the Max1 value to set
   */
  public void setMax1(Integer max1)
  {
    properties.setProperty("max1", max1.toString());
  }

  /**
   * Standard getter for Max1
   *
   * @return the Max1 value
   */
  public Integer getMax1()
  {
    return Integer.parseInt(properties.getProperty("max1"));
  }

  /**
   * Standard setter for Max2
   *
   * @param Max2 the Max2 value to set
   */
  public void setMax2(Integer max2)
  {
    properties.setProperty("max2", max2.toString());
  }

  /**
   * Standard getter for Max2
   *
   * @return the Max2 value
   */
  public Integer getMax2()
  {
    return Integer.parseInt(properties.getProperty("max2"));
  }

  /**
   * Standard setter for Max3
   *
   * @param Max3 the Max3 value to set
   */
  public void setMax3(Integer max3)
  {
    properties.setProperty("max3", max3.toString());
  }

  /**
   * Standard getter for Max3
   *
   * @return the Max3 value
   */
  public Integer getMax3()
  {
    return Integer.parseInt(properties.getProperty("max3"));
  }

  /**
   * Standard setter for FontItalic
   *
   * @param FontItalic the FontItalic value to set
   */
  public void setFontItalic(Integer fontItalic)
  {
    properties.setProperty("fontItalic", fontItalic.toString());
  }

  /**
   * Standard getter for FontItalic
   *
   * @return the FontItalic value
   */
  public Integer getFontItalic()
  {
    return Integer.parseInt(properties.getProperty("fontItalic"));
  }

  /**
   * Standard setter for Min
   *
   * @param Min the Min value to set
   */
  public void setMin(Integer min)
  {
    properties.setProperty("min", min.toString());
  }

  /**
   * Standard getter for Min
   *
   * @return the Min value
   */
  public Integer getMin()
  {
    return Integer.parseInt(properties.getProperty("min"));
  }

  /**
   * Standard setter for Style
   *
   * @param Style the Style value to set
   */
  public void setStyle(Integer style)
  {
    properties.setProperty("style", style.toString());
  }

  /**
   * Standard getter for Style
   *
   * @return the Style value
   */
  public Integer getStyle()
  {
    return Integer.parseInt(properties.getProperty("style"));
  }

  /**
   * Standard setter for ValueType
   *
   * @param ValueType the ValueType value to set
   */
  public void setValueType(Integer valueType)
  {
    properties.setProperty("valueType", valueType.toString());
  }

  /**
   * Standard getter for ValueType
   *
   * @return the ValueType value
   */
  public Integer getValueType()
  {
    return Integer.parseInt(properties.getProperty("valueType"));
  }

  /**
   * Standard setter for Height
   *
   * @param Height the Height value to set
   */
  public void setHeight(Integer height)
  {
    properties.setProperty("height", height.toString());
  }

  /**
   * Standard getter for Height
   *
   * @return the Height value
   */
  public Integer getHeight()
  {
    return Integer.parseInt(properties.getProperty("height"));
  }

  /**
   * Standard setter for QName
   *
   * @param QName the QName value to set
   */
  public void setQName(String qName)
  {
    properties.setProperty("QName", qName);
  }

  /**
   * Standard getter for QName
   *
   * @return the QName value
   */
  public String getQName()
  {
    return properties.getProperty("QName");
  }

  /**
   * Standard setter for QName2
   *
   * @param QName2 the QName2 value to set
   */
  public void setQName2(String qName2)
  {
    properties.setProperty("QName2", qName2);
  }

  /**
   * Standard getter for QName2
   *
   * @return the QName2 value
   */
  public String getQName2()
  {
    return properties.getProperty("QName2");
  }

  /**
   * Standard setter for QType
   *
   * @param QType the QType value to set
   */
  public void setQType(String qType)
  {
    properties.setProperty("QType", qType);
  }

  /**
   * Standard getter for QType
   *
   * @return the QType value
   */
  public String getQType()
  {
    return properties.getProperty("QType");
  }

  /**
   * Standard setter for Width
   *
   * @param Width the Width value to set
   */
  public void setWidth(Integer width)
  {
    properties.setProperty("Width", width.toString());
  }

  /**
   * Standard getter for Width
   *
   * @return the Width value
   */
  public Integer getWidth()
  {
    return Integer.parseInt(properties.getProperty("Width"));
  }

  /**
   * Standard setter for top
   *
   * @param top the top value to set
   */
  public void setTop(Integer top)
  {
    properties.setProperty("top", top.toString());
  }

  /**
   * Standard getter for top
   *
   * @return the top value
   */
  public Integer getTop()
  {
    return Integer.parseInt(properties.getProperty("top"));
  }

  /**
   * Standard setter for Left
   *
   * @param Left the Left value to set
   */
  public void setLeft(Integer left)
  {
    properties.setProperty("left", left.toString());
  }

  /**
   * Standard getter for Left
   *
   * @return the Left value
   */
  public Integer getLeft()
  {
    return Integer.parseInt(properties.getProperty("left"));
  }
}
