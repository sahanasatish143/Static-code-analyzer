/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSSIEBELAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSSIEBELAttribute object in the context of an editor or in a code
   * translator.
   */
  public JOBSSIEBELAttribute()
  {
    this.properties = new Properties();
    this.setCompression(0);
    this.setEncryption(0);
    this.setGatewaySrv("");
    this.setEnterprSrv("");
    this.setSiebelSrvs("");
    this.setLanguage("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSSIEBELAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSSIEBELAttribute.
   * @see JOBSSIEBELAttributeFactory
   */
  public JOBSSIEBELAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Encryption.
   *
   * @param Encryption the Encryption value to set
   */
  public void setEncryption(Integer encryption)
  {
    properties.setProperty("Encryption", encryption.toString());
  }

  /**
   * Standard getter for Encryption.
   *
   * @return the Encryption
   * @returns the Encryption value
   */
  public Integer getEncryption()
  {
    return Integer.parseInt(properties.getProperty("Encryption"));
  }

  /**
   * Standard setter for Compression.
   *
   * @param Compression the Compression value to set
   */
  public void setCompression(Integer compression)
  {
    properties.setProperty("Compression", compression.toString());
  }

  /**
   * Standard getter for Compression.
   *
   * @return the Compression
   * @returns the Compression value
   */
  public Integer getCompression()
  {
    return Integer.parseInt(properties.getProperty("Compression"));
  }

  /**
   * Standard setter for GatewaySrv.
   *
   * @param GatewaySrv the GatewaySrv value to set
   */
  public void setGatewaySrv(String gatewaySrv)
  {
    properties.setProperty("GatewaySrv", gatewaySrv);
  }

  /**
   * Standard getter for GatewaySrv.
   *
   * @return the GatewaySrv
   * @returns the GatewaySrv value
   */
  public String getGatewaySrv()
  {
    return properties.getProperty("GatewaySrv");
  }

  /**
   * Standard setter for EnterprSrv.
   *
   * @param EnterprSrv the EnterprSrv value to set
   */
  public void setEnterprSrv(String enterprSrv)
  {
    properties.setProperty("EnterprSrv", enterprSrv);
  }

  /**
   * Standard getter for EnterprSrv.
   *
   * @return the EnterprSrv
   * @returns the EnterprSrv value
   */
  public String getEnterprSrv()
  {
    return properties.getProperty("EnterprSrv");
  }

  /**
   * Standard setter for SiebelSrvs.
   *
   * @param SiebelSrvs the SiebelSrvs value to set
   */
  public void setSiebelSrvs(String siebelSrvs)
  {
    properties.setProperty("SiebelSrvs", siebelSrvs);
  }

  /**
   * Standard getter for SiebelSrvs.
   *
   * @return the SiebelSrvs
   * @returns the SiebelSrvs value
   */
  public String getSiebelSrvs()
  {
    return properties.getProperty("SiebelSrvs");
  }

  /**
   * Standard setter for Language.
   *
   * @param Language the Language value to set
   */
  public void setLanguage(String language)
  {
    properties.setProperty("Language", language);
  }

  /**
   * Standard getter for Language.
   *
   * @return the Language
   * @returns the Language value
   */
  public String getLanguage()
  {
    return properties.getProperty("Language");
  }
}
