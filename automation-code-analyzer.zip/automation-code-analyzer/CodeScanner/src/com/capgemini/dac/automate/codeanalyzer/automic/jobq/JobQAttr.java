package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

import java.util.Properties;

public class JobQAttr
{
  private Properties properties;

  /**
   * Constructor to build a default JobPAttr object.
   */
  public JobQAttr()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setQueue("CLIENT_QUEUE");
    this.setHostDst("");
    this.setHostAttrType("");
    this.setMaxParallel2(0);
    this.setExtRepDef(1);
    this.setExtRepAll(0);
    this.setExtRepNone(0);
    this.setIntAccount("");
    this.setStartJobs(0);
    this.setAutoTerm(0);
    this.setReplChildren0(1);
    this.setReplChildren1(0);
    this.setReplChildren2(0);
    this.setActAtRun(0);
    this.setUC4Priority(0);
    this.setConsumption(0);
    this.setTZ("");
    this.setRMaxOK("");
    this.setRExecute("");
    this.setOutput(1);
  }
  public JobQAttr(Properties properties)
  {
    this.properties = properties;
  }
  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for Queue.
   *
   * @param queue the Queue value to set
   */
  public void setQueue(String queue)
  {
    properties.setProperty("Queue", queue);
  }

  /**
   * Standard getter for Queue.
   *
   * @return the queue
   * @returns the Queue value
   */
  public String getQueue()
  {
    return properties.getProperty("Queue");
  }
  /**
   * Standard setter for MaxParallel2.
   *
   * @param maxParallel2 the MaxParallel2 value to set
   */
  public void setMaxParallel2(Integer maxParallel2)
  {
    properties.setProperty("MaxParallel", maxParallel2.toString());
  }

  /**
   * Standard getter for MaxParallel2.
   *
   * @return the max parallel 2
   * @returns the MaxParallel2 value
   */
  public Integer getMaxParallel2()
  {
    return Integer.parseInt(properties.getProperty("MaxParallel"));
  }

  /**
   * Standard setter for ExtRepDef.
   *
   * @param extRepDef the ExtRepDef value to set
   */
  public void setExtRepDef(Integer extRepDef)
  {
    properties.setProperty("ExtRepDef", extRepDef.toString());
  }

  /**
   * Standard getter for ExtRepDef.
   *
   * @return the ext rep def
   * @returns the ExtRepDef value
   */
  public Integer getExtRepDef()
  {
    return Integer.parseInt(properties.getProperty("ExtRepDef"));
  }

  /**
   * Standard setter for ExtRepAll.
   *
   * @param extRepAll the ExtRepAll value to set
   */
  public void setExtRepAll(Integer extRepAll)
  {
    properties.setProperty("ExtRepAll", extRepAll.toString());
  }

  /**
   * Standard getter for ExtRepAll.
   *
   * @return the ext rep all
   * @returns the ExtRepAll value
   */
  public Integer getExtRepAll()
  {
    return Integer.parseInt(properties.getProperty("ExtRepAll"));
  }

  /**
   * Standard setter for ExtRepNone.
   *
   * @param extRepNone the ExtRepNone value to set
   */
  public void setExtRepNone(Integer extRepNone)
  {
    properties.setProperty("ExtRepNone", extRepNone.toString());
  }

  /**
   * Standard getter for ExtRepNone.
   *
   * @return the ext rep none
   * @returns the ExtRepNone value
   */
  public Integer getExtRepNone()
  {
    return Integer.parseInt(properties.getProperty("ExtRepNone"));
  }
  /**
   * Standard setter for IntAccount.
   *
   * @param intAccount the IntAccount value to set
   */
  public void setIntAccount(String intAccount)
  {
    properties.setProperty("IntAccount", intAccount);
  }

  /**
   * Standard getter for IntAccount.
   *
   * @return the int account
   * @returns the IntAccount value
   */
  public String getIntAccount()
  {
    return properties.getProperty("IntAccount");
  }
  /**
   * Standard setter for ActAtRun.
   *
   * @param actAtRun the ActAtRun value to set
   */
  public void setActAtRun(Integer actAtRun)
  {
    properties.setProperty("ActAtRun", actAtRun.toString());
  }

  /**
   * Standard getter for ActAtRun.
   *
   * @return the integer
   * @returns the ActAtRun value
   */
  public Integer ActAtRun()
  {
    return Integer.parseInt(properties.getProperty("ActAtRun"));
  }

  /**
   * Standard setter for UC4Priority.
   *
   * @param uC4Priority the UC4Priority value to set
   */
  public void setUC4Priority(Integer uC4Priority)
  {
    properties.setProperty("UC4Priority", uC4Priority.toString());
  }

  /**
   * Standard getter for UC4Priority.
   *
   * @return the UC 4 priority
   * @returns the UC4Priority value
   */
  public Integer getUC4Priority()
  {
    return Integer.parseInt(properties.getProperty("UC4Priority"));
  }

  /**
   * Standard setter for Consumption.
   *
   * @param consumption the new consumption
   */
  public void setConsumption(Integer consumption)
  {
    properties.setProperty("Consumption", consumption.toString());
  }

  /**
   * Standard getter for Consumption.
   *
   * @return the consumption
   * @returns the Consumption value
   */
  public Integer getConsumption()
  {
    return Integer.parseInt(properties.getProperty("Consumption"));
  }
  /**
   * Standard setter for TZ.
   *
   * @param tZ the TZ value to set
   */
  public void setTZ(String tZ)
  {
    properties.setProperty("TZ", tZ);
  }

  /**
   * Standard getter for TZ.
   *
   * @return the tz
   * @returns the TZ value
   */
  public String getTZ()
  {
    return properties.getProperty("TZ");
  }
  /**
   * Standard setter for RExecute
   *
   * @param rExecute the RExecute value to set
   */
  public void setRExecute(String rExecute)
  {
    properties.setProperty("RExecute", rExecute);
  }

  /**
   * Standard getter for RExecute
   *
   * @returns the RExecute value
   */
  public String getRExecute()
  {
    return properties.getProperty("RExecute");
  }
  /**
   * Standard setter for RWhen
   *
   * @param rWhen the RWhen value to set
   */
  public void setRMaxOK(String rWhen)
  {
    properties.setProperty("RMaxOK", rWhen);
  }

  /**
   * Standard getter for RWhen
   *
   * @returns the RWhen value
   */
  public String getRMaxOK()
  {
    return properties.getProperty("RMaxOK");
  }
  
  /**
   * Standard setter for RWhen
   *
   * @param rWhen the RWhen value to set
   */
  public void setOutput(Integer rWhen)
  {
    properties.setProperty("Output", rWhen.toString());
  }

  /**
   * Standard getter for RWhen
   *
   * @returns the RWhen value
   */
  public Integer getOutput()
  {
    return Integer.parseInt(properties.getProperty("Output"));
  }
  /**
   * Standard setter for RWhen
   *
   * @param rWhen the RWhen value to set
   */
  public void setHostDst(String rWhen)
  {
    properties.setProperty("HostDst", rWhen);
  }

  /**
   * Standard getter for RWhen
   *
   * @returns the RWhen value
   */
  public String getHostDst()
  {
    return properties.getProperty("HostDst");
  }
  public void setHostAttrType(String rWhen)
  {
    properties.setProperty("HostAttrType", rWhen);
  }

  /**
   * Standard getter for RWhen
   *
   * @returns the RWhen value
   */
  public String getHostAttrType()
  {
    return properties.getProperty("HostAttrType");
  }
  public void setStartJobs(Integer mpElse1)
  {
    properties.setProperty("StartJobs", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @returns the MpElse1 value
   */
  public Integer getStartJobs()
  {
    return Integer.parseInt(properties.getProperty("StartJobs"));
  }
  public void setAutoTerm(Integer mpElse1)
  {
    properties.setProperty("AutoTerm", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @returns the MpElse1 value
   */
  public Integer getAutoTerm()
  {
    return Integer.parseInt(properties.getProperty("AutoTerm"));
  }
  
  public void setReplChildren0(Integer mpElse1)
  {
    properties.setProperty("ReplChildren0", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @returns the MpElse1 value
   */
  public Integer getReplChildren0()
  {
    return Integer.parseInt(properties.getProperty("ReplChildren0"));
  }
  
  public void setReplChildren1(Integer mpElse1)
  {
    properties.setProperty("ReplChildren1", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @returns the MpElse1 value
   */
  public Integer getReplChildren1()
  {
    return Integer.parseInt(properties.getProperty("ReplChildren1"));
  }
  
  public void setReplChildren2(Integer mpElse1)
  {
    properties.setProperty("ReplChildren2", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @returns the MpElse1 value
   */
  public Integer getReplChildren2()
  {
    return Integer.parseInt(properties.getProperty("ReplChildren2"));
  }

}
