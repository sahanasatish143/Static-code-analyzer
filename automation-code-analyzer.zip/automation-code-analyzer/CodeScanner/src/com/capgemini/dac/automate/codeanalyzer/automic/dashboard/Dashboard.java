/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.dashboard;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

/**
 * This class represents an Automic DASH object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class Dashboard extends AutomicExecutableObject
{

  private DASHDefinition dashDefinition;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * DASH object in the context of an editor or in a code translator.
   */
  public Dashboard()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the DashboardFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for Dashboard.
   * @see DashboardFactory
   */
  public Dashboard(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for DASHDefinition
   *
   * @return the DASHDefinition value
   */
  public DASHDefinition getDASHDefinition()
  {
    return dashDefinition;
  }

  /**
   * Standard setter for DASHDefinition
   *
   * @param DASHDefinition the DASHDefinition value to set
   */
  public void setDASHDefinition(DASHDefinition dashDefinition)
  {
    this.dashDefinition = dashDefinition;
  }
}