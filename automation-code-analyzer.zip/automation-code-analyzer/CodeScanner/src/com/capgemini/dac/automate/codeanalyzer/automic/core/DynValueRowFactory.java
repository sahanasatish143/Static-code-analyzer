package com.capgemini.dac.automate.codeanalyzer.automic.core;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public interface DynValueRowFactory
{
  public DynValueRow getDefaultDYNValueRow();
  public DynValueRow parseDYNValueRowFromSource();
}