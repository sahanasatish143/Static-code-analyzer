/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jsch;

import java.util.Iterator;
import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.DynValues;

/**
 * Represents a single task block of an Automic JSCH object JSCHStructure.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.8
 */
public class JSCHTask
{
  Properties properties;
  private JSCHTaskTimePeriod timePeriod;
  private JSCHTaskAfter after;
  private JSCHTaskRunTime runtime;
  private JSCHTaskResult result;
  private DynValues dynvalues;
  private JSCHTaskCalendars calendars;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JSCHTask object in the context of an editor or in a code translator.
   */
  public JSCHTask()
  {
    this.properties = new Properties();
    this.timePeriod = null;
    this.calendars = null;
    this.after = null;
    this.runtime = null;
    this.result = null;
    this.dynvalues = null;
    this.setLnr(1);
    this.setOtype("");
    this.setObject("");
    this.setText2("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JSCHTaskFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JSCHTask.
   * @see JSCHTaskFactory
   */
  public JSCHTask(Properties properties)
  {
    this.properties = properties;
    this.calendars = null;
    this.after = null;
    this.timePeriod = null;
    this.runtime = null;
    this.result = null;
    this.dynvalues = null;

  }

  /**
   * Standard setter for Lnr
   *
   * @param lnr the Lnr value to set
   */
  public void setLnr(Integer lnr)
  {
    properties.setProperty("Lnr", lnr.toString());
  }

  /**
   * Standard getter for Lnr
   *
   * @returns the Lnr value
   */
  public Integer getLnr()
  {
    return Integer.parseInt(properties.getProperty("Lnr"));
  }

  /**
   * Standard setter for Otype
   *
   * @param otype the Otype value to set
   */
  public void setOtype(String otype)
  {
    properties.setProperty("Otype", otype);
  }

  /**
   * Standard getter for Otype
   *
   * @returns the Otype value
   */
  public String getOtype()
  {
    return properties.getProperty("Otype");
  }

  /**
   * Standard setter for Object
   *
   * @param object the Object value to set
   */
  public void setObject(String object)
  {
    properties.setProperty("Object", object);
  }

  /**
   * Standard getter for Object
   *
   * @returns the Object value
   */
  public String getObject()
  {
    return properties.getProperty("Object");
  }

  /**
   * Standard setter for Text2
   *
   * @param text2 the state value to set
   */
  public void setText2(String text2)
  {
    properties.setProperty("Text2", text2);
  }

  /**
   * Standard getter for Text2
   *
   * @returns the Text2 value
   */
  public String getText2()
  {
    return properties.getProperty("Text2");
  }

  /**
   * Adds a Calendar to the list.
   *
   * @param the the Calendar to add to the collection
   */

  public void addCalendar(JSCHTaskCalendar calendar)
  {
    calendars.addCalendar(calendar);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the Calendar in the collection
   */
  public Iterator<JSCHTaskCalendar> getCalendarsIterator()
  {
    return this.calendars.getCalendarsIterator();
  }

  /**
   * Standard getter for TimePeriod.
   *
   * @return the TimePeriod
   */
  public JSCHTaskTimePeriod getTimePeriod()
  {
    return timePeriod;
  }

  /**
   * Standard setter for TimePeriod
   *
   * @param TimePeriod the TimePeriod to set
   */
  public void setTimePeriod(JSCHTaskTimePeriod timePeriod)
  {
    this.timePeriod = timePeriod;
  }

  /**
   * Standard getter for after.
   *
   * @return the after
   */
  public JSCHTaskAfter getAfter()
  {
    return after;
  }

  /**
   * Standard setter for after
   *
   * @param after the after to set
   */
  public void setAfter(JSCHTaskAfter after)
  {
    this.after = after;
  }

  /**
   * Standard getter for runtime.
   *
   * @return the runtime
   */
  public JSCHTaskRunTime getRuntime()
  {
    return runtime;
  }

  /**
   * Standard setter for runtime
   *
   * @param runtime the runtime to set
   */
  public void setRuntime(JSCHTaskRunTime runtime)
  {
    this.runtime = runtime;
  }

  /**
   * Standard getter for result.
   *
   * @return the result
   */
  public JSCHTaskResult getResult()
  {
    return result;
  }

  /**
   * Standard setter for result
   *
   * @param result the result to set
   */
  public void setResult(JSCHTaskResult result)
  {
    this.result = result;
  }

  /**
   * Standard getter for dynvalues.
   *
   * @return the dynvalues
   */
  public DynValues getDynvalues()
  {
    return dynvalues;
  }

  /**
   * Standard setter for dynvalues
   *
   * @param dynvalues the dynvalues to set
   */
  public void setDynvalues(DynValues dynvalues)
  {
    this.dynvalues = dynvalues;
  }

  /**
   * Standard getter for calendars.
   *
   * @return the calendars
   */
  public JSCHTaskCalendars getCalendars()
  {
    return calendars;
  }

  /**
   * Standard setter for calendars
   *
   * @param calendars the calendars to set
   */
  public void setCalendars(JSCHTaskCalendars calendars)
  {
    this.calendars = calendars;
  }
}