package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARAExecFactory
{
  public VARAExec getDefaultVARAExec();
  public VARAExec parseVARAExecFromSource();
}
