/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.calendar;

import java.util.Properties;

/**
 * This class represents an Automic KeywordGroup under CALE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class KeywordGroup
{
  Properties properties;
  private GroupA groupA;
  private GroupN groupN;
  private GroupO groupO;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the KeywordGroupFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for KeywordGroup.
   * @see KeywordGroupFactory
   */
  public KeywordGroup(Properties properties)
  {
    this.properties = properties;
    this.groupA = null;
    this.groupN = null;
    this.groupO = null;

  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * KeywordGroup under CALE object in the context of an editor or in a code
   * translator.
   */
  public KeywordGroup()
  {
    this.properties = new Properties();
    this.groupA = null;

    this.groupN = null;
    this.groupO = null;

  }

  /**
   * Standard getter for GroupA.
   *
   * @return the GroupA
   */
  public GroupA getGroupA()
  {
    return groupA;
  }

  /**
   * Standard setter for GroupA
   *
   * @param GroupA the GroupA to set
   */
  public void setGroupA(GroupA groupA)
  {
    this.groupA = groupA;
  }

  /**
   * Standard getter for GroupN.
   *
   * @return the GroupN
   */

  public GroupN getGroupN()
  {
    return groupN;
  }

  /**
   * Standard setter for GroupN
   *
   * @param GroupA the GroupN to set
   */

  public void setGroupN(GroupN groupN)
  {
    this.groupN = groupN;
  }

  /**
   * Standard getter for GroupO.
   *
   * @return the GroupO
   */

  public GroupO getGroupO()
  {
    return groupO;
  }

  /**
   * Standard setter for GroupO
   *
   * @param GroupA the GroupO to set
   */

  public void setGroupO(GroupO groupO)
  {
    this.groupO = groupO;
  }

}
