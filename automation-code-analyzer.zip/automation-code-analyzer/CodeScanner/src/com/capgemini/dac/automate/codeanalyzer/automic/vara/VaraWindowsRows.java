/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class VaraWindowsRows.
 */
public class VaraWindowsRows
{
  
  /** The properties. */
  Properties properties;
  
  /**
   * Instantiates a new vara windows rows.
   */
  public VaraWindowsRows()
  {
    this.properties = new Properties();
    this.setWINDOWS_Columns("");
    this.setLnr(1);
    this.setIdnr(5555545);
    this.setWINDOWSCommand("");
    this.setWINDOWSOVTLnr(1);
    this.setWindowsOs("");
    this.setWindowsVersion("");
  }
  
  /**
   * Instantiates a new vara windows rows.
   *
   * @param properties the properties
   */
  public VaraWindowsRows(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Sets the WINDOW S columns.
   *
   * @param archiveKey1 the new WINDOW S columns
   */
  public void setWINDOWS_Columns(String archiveKey1)
  {
    properties.setProperty("WINDOWS_Columns", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the WINDOW S columns
   * @returns the When ArchiveKey1
   */
  public String getWINDOWS_Columns()
  {
    return properties.getProperty("WINDOWS_Columns");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param archiveKey2 the new WINDOWS command
   */
  public void setWINDOWSCommand(String archiveKey2)
  {
    properties.setProperty("WINDOWS_Command", archiveKey2);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the name
   * @returns the When ArchiveKey1
   */
  public String getName()
  {
    return properties.getProperty("WINDOWS_Command");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param hw the new lnr
   */
  public void setLnr(Integer hw)
  {
    properties.setProperty("WINDOWS_Lnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the lnr
   * @returns the When ArchiveKey1
   */
  public String getLnr()
  {
    return properties.getProperty("WINDOWS_Lnr");
  }
  
  /**
   * Sets the idnr.
   *
   * @param hw the new idnr
   */
  public void setIdnr(Integer hw)
  {
    properties.setProperty("WINDOWS_OH_Idnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the idnr
   * @returns the When ArchiveKey1
   */
  public String getIdnr()
  {
    return properties.getProperty("WINDOWS_OH_Idnr");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param icon the new windows os
   */
  public void setWindowsOs(String icon)
  {
    properties.setProperty("WINDOWS_OS", icon);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the windows os
   * @returns the When ArchiveKey1
   */
  public String getWindowsOs()
  {
    return properties.getProperty("WINDOWS_OS");
  }
  
  /**
   * Sets the WINDOWSOVT lnr.
   *
   * @param hw the new WINDOWSOVT lnr
   */
  public void setWINDOWSOVTLnr(Integer hw)
  {
    properties.setProperty("WINDOWS_OVT_Lnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the WINDOWSOVT lnr
   * @returns the When ArchiveKey1
   */
  public String getWINDOWSOVTLnr()
  {
    return properties.getProperty("WINDOWS_OVT_Lnr");
  }
  
  /**
   * Sets the windows version.
   *
   * @param icon the new windows version
   */
  public void setWindowsVersion(String icon)
  {
    properties.setProperty("WINDOWS_Version", icon);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the windows version
   * @returns the When ArchiveKey1
   */
  public String getWindowsVersion()
  {
    return properties.getProperty("WINDOWS_Version");
  }
}
