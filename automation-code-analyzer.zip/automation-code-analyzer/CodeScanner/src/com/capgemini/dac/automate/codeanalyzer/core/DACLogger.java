/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.core;

/**
 * This class is the central logging class meant to be used across all other
 * objects in the project. It is a singleton class and is meant to be accessed
 * through the getLogger static method.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class DACLogger
{
  // members
  private static DACLogger single_instance = null;

  // constructors
  /**
   * Default constructor specified as private so that it can not be called
   * directly.
   */
  private DACLogger()
  {
  }

  /**
   * A factory method that returns the DACLogger singleton.
   * 
   * @return the DACLogger singleton
   */
  public static DACLogger getLogger()
  {
    if (single_instance == null)
      single_instance = new DACLogger();
    return single_instance;
  }

  // methods
  /**
   * Prints a message to the log as is. This method does no formating on the
   * message.
   * 
   * @param message a String holding the message to be printed to the log
   */
  public void logGeneralMessage(java.lang.String message)
  {
    System.out.println(message);
  }

  /**
   * Prints a formatted message to the log with details of the attribute that was
   * encountered.
   * 
   * @param attribute a String holding the name of the unknown attribute
   * @param tag a String the name of the tag where the attribute was found
   * @param object a String holding the name of the object that was being parsed
   */
  public void logAttributeError(java.lang.String attribute, java.lang.String tag, java.lang.String object)
  {
    logGeneralMessage("An unknown attribute " + attribute + " was found while parsing the tag " + tag
        + " in the object " + object + ".");
  }

  /**
   * Prints a formatted message to the log with details of the tag that was
   * encountered.
   * 
   * @param tag a String holding the name of the unknown tag
   * @param object a String holding the name of the object that was being parsed
   */
  public void logTagError(java.lang.String tag, String object)
  {
    logGeneralMessage("An unknown tag " + tag + " was found while parsing the object " + object + ".");
  }

  /**
   * Prints a formatted message to the log with details of the exception.
   * 
   * @param exception the exception object that was encountered
   * @param object a String holding the name of the object that was being parsed
   */
  public void logGeneralException(Exception exception, String message)
  {
    logGeneralMessage(message + "/n See stack trace for details");
    exception.printStackTrace();
  }

  /**
   * Prints a formatted message to the log with details of the exception.
   * 
   * @param exception the exception object that was encountered
   * @param object a String holding the name of the object that was being parsed
   */
  public void logXMLException(Exception exception, String object)
  {
    logGeneralMessage(
        "An Exceptiopn was encountered while parsing the object " + object + ". See stack trace for details");
    exception.printStackTrace();
  }
}