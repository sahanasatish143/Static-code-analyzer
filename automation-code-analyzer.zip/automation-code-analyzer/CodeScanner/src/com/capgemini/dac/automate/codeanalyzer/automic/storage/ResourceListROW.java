/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.storage;

import java.util.Properties;

/**
 * This class represents an Automic ResourceListROW under STORE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class ResourceListROW
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * ResourceListROW under STORE object in the context of an editor or in a code
   * translator.
   */
  public ResourceListROW()
  {
    this.properties = new Properties();
    this.setChecksum("");
    this.setId("");
    this.setFileType("");
    this.setFilename("");
    this.setHw("");
    this.setName("");
    this.setPlatform("");
    this.setResname("");
    this.setSw("");
    this.setType(null);
    this.setVersion(null);
    this.setSize(null);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the ResourceListROWFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for ResourceListROW.
   * @see ResourceListROWFactory
   */
  public ResourceListROW(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for version
   *
   * @param version the version value to set
   */
  public void setVersion(Integer version)
  {
    properties.setProperty("version", version.toString());
  }

  /**
   * Standard getter for version
   *
   * @returns the version value
   */
  public Integer getVersion()
  {
    return Integer.parseInt(properties.getProperty("version"));
  }

  /**
   * Standard setter for Type
   *
   * @param Type the Type value to set
   */
  public void setType(Integer type)
  {
    properties.setProperty("type", type.toString());
  }

  /**
   * Standard getter for Type
   *
   * @returns the Type value
   */
  public Integer getType()
  {
    return Integer.parseInt(properties.getProperty("type"));
  }

  /**
   * Standard setter for size
   *
   * @param size the size value to set
   */
  public void setSize(Integer size)
  {
    properties.setProperty("size", size.toString());
  }

  /**
   * Standard getter for size
   *
   * @returns the size value
   */
  public Integer getSize()
  {
    return Integer.parseInt(properties.getProperty("size"));
  }

  /**
   * Standard setter for sw
   *
   * @param sw the sw value to set
   */
  public void setSw(String sw)
  {
    properties.setProperty("sw", sw);
  }

  /**
   * Standard getter for sw
   *
   * @returns the sw value
   */
  public String getSw()
  {
    return properties.getProperty("sw");
  }

  /**
   * Standard setter for Resname
   *
   * @param Resname the Resname value to set
   */
  public void setResname(String resname)
  {
    properties.setProperty("resname", resname);
  }

  /**
   * Standard getter for Resname
   *
   * @returns the Resname value
   */
  public String getResname()
  {
    return properties.getProperty("resname");
  }

  /**
   * Standard setter for Id
   *
   * @param Id the Id value to set
   */
  public void setId(String id)
  {
    properties.setProperty("id", id);
  }

  /**
   * Standard getter for Id
   *
   * @returns the Id value
   */
  public String getId()
  {
    return properties.getProperty("id");
  }

  /**
   * Standard setter for Platform
   *
   * @param Platform the Platform value to set
   */
  public void setPlatform(String platform)
  {
    properties.setProperty("platform", platform);
  }

  /**
   * Standard getter for Platform
   *
   * @returns the Platform value
   */
  public String getPlatform()
  {
    return properties.getProperty("platform");
  }

  /**
   * Standard setter for Name
   *
   * @param Name the Name value to set
   */
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }

  /**
   * Standard getter for Name
   *
   * @returns the Name value
   */
  public String getName()
  {
    return properties.getProperty("name");
  }

  /**
   * Standard setter for Hw
   *
   * @param Hw the Hw value to set
   */
  public void setHw(String hw)
  {
    properties.setProperty("hw", hw);
  }

  /**
   * Standard getter for Hw
   *
   * @returns the Hw value
   */
  public String getHw()
  {
    return properties.getProperty("hw");
  }

  /**
   * Standard setter for Checksum
   *
   * @param Checksum the Checksum value to set
   */
  public void setChecksum(String checksum)
  {
    properties.setProperty("checksum", checksum);
  }

  /**
   * Standard getter for Checksum
   *
   * @returns the Checksum value
   */
  public String getChecksum()
  {
    return properties.getProperty("checksum");
  }

  /**
   * Standard setter for Filename
   *
   * @param Filename the Filename value to set
   */
  public void setFilename(String filename)
  {
    properties.setProperty("filename", filename);
  }

  /**
   * Standard getter for Filename
   *
   * @returns the Filename value
   */
  public String getFilename()
  {
    return properties.getProperty("filename");
  }

  /**
   * Standard setter for FileType
   *
   * @param FileType the FileType value to set
   */
  public void setFileType(String fileType)
  {
    properties.setProperty("fileType", fileType);
  }

  /**
   * Standard getter for FileType
   *
   * @returns the FileType value
   */
  public String getFileType()
  {
    return properties.getProperty("fileType");
  }
}
