package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class NamespacesDefinition implements Iterable<String>
{
  Properties properties;
  ArrayList<String> nameSpacesDefinition;

  public NamespacesDefinition(Properties properties)
  {
    this.properties = properties;
    nameSpacesDefinition = new ArrayList<String>();

  }

  public NamespacesDefinition()
  {
    this.properties = new Properties();
    nameSpacesDefinition = new ArrayList<String>();
  }

  @Override
  public Iterator<String> iterator()
  {
    return nameSpacesDefinition.iterator();
  }

  public void add(String rows)
  {
    nameSpacesDefinition.add(rows);

  }

}
