/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSCIT
{
  Properties properties;
  private JOBSCITCont citcont;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSCIT object in the context of an editor or in a code translator.
   */
  public JOBSCIT()
  {
    this.properties = new Properties();
    this.setState(2);
    this.setDirty(1);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSCITFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSCIT.
   * @see JOBSCITFactory
   */
  public JOBSCIT(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for JOBSCITCont
   *
   * @return the JOBSCITCont value
   */
  public JOBSCITCont getJOBSCITCont()
  {
    return citcont;
  }

  /**
   * Standard setter for JOBSCITCont
   *
   * @param JOBSCITCont the JOBSCITCont value to set
   */
  public void setJOBSCITCont(JOBSCITCont citcont)
  {
    this.citcont = citcont;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for Dirty.
   *
   * @param Dirty the Dirty value to set
   */
  public void setDirty(Integer dirty)
  {
    properties.setProperty("Dirty", dirty.toString());
  }

  /**
   * Standard getter for Dirty.
   *
   * @return the Dirty
   * @returns the Dirty value
   */
  public Integer getDirty()
  {
    return Integer.parseInt(properties.getProperty("Dirty"));
  }

}
