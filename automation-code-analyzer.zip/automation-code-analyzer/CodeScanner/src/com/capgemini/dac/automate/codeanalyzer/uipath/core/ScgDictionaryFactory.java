package com.capgemini.dac.automate.codeanalyzer.uipath.core;

public interface ScgDictionaryFactory
{
  public ScgDictionary getDefaultScgDictionary();

  public ScgDictionary parseScgDictionaryFromSource();
}
