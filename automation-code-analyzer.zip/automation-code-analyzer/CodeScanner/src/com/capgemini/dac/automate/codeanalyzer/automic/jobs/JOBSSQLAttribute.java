/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSSQLAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSSQLAttribute object in the context of an editor or in a code translator.
   */
  public JOBSSQLAttribute()
  {
    this.properties = new Properties();
    this.setSQLConnection("");
    this.setConnection("");
    this.setServerPort("");
    this.setDatabaseName("");
    this.setDataSource("");
    this.setAttributes("");
    this.setColumnSeparator("");
    this.setSeparatorSubstitute("");
    this.setShowHeadline(1);
    this.setShowNULL(1);
    this.setMaxLines(0);
    this.setMaxColumnWidth(50);
    this.setRemoveCRLF(1);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSSQLAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSSQLAttribute.
   * @see JOBSSQLAttributeFactory
   */
  public JOBSSQLAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for RemoveCRLF.
   *
   * @param RemoveCRLF the RemoveCRLF value to set
   */
  public void setRemoveCRLF(Integer removeCRLF)
  {
    properties.setProperty("RemoveCRLF", removeCRLF.toString());
  }

  /**
   * Standard getter for RemoveCRLF.
   *
   * @return the RemoveCRLF
   * @returns the RemoveCRLF value
   */
  public Integer getRemoveCRLF()
  {
    return Integer.parseInt(properties.getProperty("RemoveCRLF"));
  }

  /**
   * Standard setter for MaxColumnWidth.
   *
   * @param MaxColumnWidth the MaxColumnWidth value to set
   */
  public void setMaxColumnWidth(Integer maxColumnWidth)
  {
    properties.setProperty("MaxColumnWidth", maxColumnWidth.toString());
  }

  /**
   * Standard getter for MaxColumnWidth.
   *
   * @return the MaxColumnWidth
   * @returns the MaxColumnWidth value
   */
  public Integer getMaxColumnWidth()
  {
    return Integer.parseInt(properties.getProperty("MaxColumnWidth"));
  }

  /**
   * Standard setter for MaxLines.
   *
   * @param MaxLines the MaxLines value to set
   */
  public void setMaxLines(Integer maxLines)
  {
    properties.setProperty("MaxLines", maxLines.toString());
  }

  /**
   * Standard getter for MaxLines.
   *
   * @return the MaxLines
   * @returns the MaxLines value
   */
  public Integer getMaxLines()
  {
    return Integer.parseInt(properties.getProperty("MaxLines"));
  }

  /**
   * Standard setter for ShowNULL.
   *
   * @param ShowNULL the ShowNULL value to set
   */
  public void setShowNULL(Integer showNULL)
  {
    properties.setProperty("ShowNULL", showNULL.toString());
  }

  /**
   * Standard getter for ShowNULL.
   *
   * @return the ShowNULL
   * @returns the ShowNULL value
   */
  public Integer getShowNULL()
  {
    return Integer.parseInt(properties.getProperty("ShowNULL"));
  }

  /**
   * Standard setter for ShowHeadline.
   *
   * @param ShowHeadline the ShowHeadline value to set
   */
  public void setShowHeadline(Integer showHeadline)
  {
    properties.setProperty("ShowHeadline", showHeadline.toString());
  }

  /**
   * Standard getter for ShowHeadline.
   *
   * @return the ShowHeadline
   * @returns the ShowHeadline value
   */
  public Integer getShowHeadline()
  {
    return Integer.parseInt(properties.getProperty("ShowHeadline"));
  }

  /**
   * Standard setter for SeparatorSubstitute.
   *
   * @param SeparatorSubstitute the SeparatorSubstitute value to set
   */
  public void setSeparatorSubstitute(String separatorSubstitute)
  {
    properties.setProperty("SeparatorSubstitute", separatorSubstitute);
  }

  /**
   * Standard getter for SeparatorSubstitute.
   *
   * @return the SeparatorSubstitute
   * @returns the SeparatorSubstitute value
   */
  public String getSeparatorSubstitute()
  {
    return properties.getProperty("SeparatorSubstitute");
  }

  /**
   * Standard setter for ColumnSeparator.
   *
   * @param ColumnSeparator the ColumnSeparator value to set
   */
  public void setColumnSeparator(String columnSeparator)
  {
    properties.setProperty("ColumnSeparator", columnSeparator);
  }

  /**
   * Standard getter for ColumnSeparator.
   *
   * @return the ColumnSeparator
   * @returns the ColumnSeparator value
   */
  public String getColumnSeparator()
  {
    return properties.getProperty("ColumnSeparator");
  }

  /**
   * Standard setter for Attributes.
   *
   * @param Attributes the Attributes value to set
   */
  public void setAttributes(String attributes)
  {
    properties.setProperty("Attributes", attributes);
  }

  /**
   * Standard getter for Attributes.
   *
   * @return the Attributes
   * @returns the Attributes value
   */
  public String getAttributes()
  {
    return properties.getProperty("Attributes");
  }

  /**
   * Standard setter for DataSource.
   *
   * @param DataSource the DataSource value to set
   */
  public void setDataSource(String dataSource)
  {
    properties.setProperty("DataSource", dataSource);
  }

  /**
   * Standard getter for DataSource.
   *
   * @return the DataSource
   * @returns the DataSource value
   */
  public String getDataSource()
  {
    return properties.getProperty("DataSource");
  }

  /**
   * Standard setter for DatabaseName.
   *
   * @param DatabaseName the DatabaseName value to set
   */
  public void setDatabaseName(String databaseName)
  {
    properties.setProperty("DatabaseName", databaseName);
  }

  /**
   * Standard getter for DatabaseName.
   *
   * @return the DatabaseName
   * @returns the DatabaseName value
   */
  public String getDatabaseName()
  {
    return properties.getProperty("DatabaseName");
  }

  /**
   * Standard setter for ServerPort.
   *
   * @param ServerPort the ServerPort value to set
   */
  public void setServerPort(String serverPort)
  {
    properties.setProperty("ServerPort", serverPort);
  }

  /**
   * Standard getter for ServerPort.
   *
   * @return the ServerPort
   * @returns the ServerPort value
   */
  public String getServerPort()
  {
    return properties.getProperty("ServerPort");
  }

  /**
   * Standard setter for Connection.
   *
   * @param Connection the Connection value to set
   */
  public void setConnection(String connection)
  {
    properties.setProperty("Connection", connection);
  }

  /**
   * Standard getter for Connection.
   *
   * @return the Connection
   * @returns the Connection value
   */
  public String getConnection()
  {
    return properties.getProperty("Connection");
  }

  /**
   * Standard setter for SQLConnection.
   *
   * @param SQLConnection the SQLConnection value to set
   */
  public void setSQLConnection(String sqlConnection)
  {
    properties.setProperty("SQLConnection", sqlConnection);
  }

  /**
   * Standard getter for SQLConnection.
   *
   * @return the SQLConnection
   * @returns the SQLConnection value
   */
  public String getSQLConnection()
  {
    return properties.getProperty("SQLConnection");
  }
}
