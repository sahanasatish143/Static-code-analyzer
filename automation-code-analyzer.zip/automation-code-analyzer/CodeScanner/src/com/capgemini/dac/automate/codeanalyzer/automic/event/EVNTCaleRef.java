/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

/**
 * This class represents an Automic EVNTCaleRef object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNTCaleRef
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVNTCaleRef object in the context of an editor or in a code translator.
   */
  public EVNTCaleRef()
  {
    this.properties = new Properties();
    this.setCond("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVNTCaleRefFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVNTCaleRef.
   * @see EVNTCaleRefFactory
   */
  public EVNTCaleRef(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }
  
  /**
   * Standard setter for Cond tag
   *
   * @param Cond the Cond value to set
   */
  public void setCond(String cond)
  {
    properties.setProperty("Cond", cond);
  }

  /**
   * Standard getter for Cond tag
   *
   * @return the Cond value
   */
  public String getCond()
  {
    return properties.getProperty("Cond");
  }
}
