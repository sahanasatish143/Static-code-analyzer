package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARAMultiFactory
{
  public VARAMulti getDefaultVARAMulti();
  public VARAMulti parseVARAMultiFromSource();
}
