package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VaraTabFactory
{
  public VaraTab getDefaultVaraTab();
  public VaraTab parseVaraTabFromSource();
}
