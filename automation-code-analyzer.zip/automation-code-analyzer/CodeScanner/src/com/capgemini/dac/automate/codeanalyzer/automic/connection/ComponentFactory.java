package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ComponentFactory
{
  public Component getDefaultComponent();
  public Component parseComponentFromSource();
}
