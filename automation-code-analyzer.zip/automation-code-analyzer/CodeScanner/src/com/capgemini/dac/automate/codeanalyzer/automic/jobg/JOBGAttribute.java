/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobg;

import java.util.Properties;

/**
 * This class represents an Automic JOBGAttribute under JOBG object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBGAttribute
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBGAttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBGAttribute.
   * @see JOBGAttributeFactory
   */
  public JOBGAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBGAttribute under JOBG object in the context of an editor or in a code
   * translator.
   */
  public JOBGAttribute()
  {
    this.properties = new Properties();
    this.setMaxParallel(1);
    this.setExtRepDef(1);
    this.setQueue("CLIENT_QUEUE");
    this.setExtRepAll(0);
    this.setChildQueue("");
    this.setExtRepNone(0);
    this.setActAtRun(0);
    this.setDeactWhen("");
    this.setStartModeAuto(0);
    this.setTZ("");
    this.setAutoDeact1ErrorFree(0);
    this.setAutoDeactErrorFree(0);
    this.setAutoDeactAlways(1);
    this.setDeactDelay(0);
    this.setAutoDeactNo(0);
  }

  /**
   * Standard setter for Queue tag
   *
   * @param Queue the Queue value to set
   */
  public void setQueue(String queue)
  {
    properties.setProperty("queue", queue);
  }

  /**
   * Standard getter for Queue tag
   *
   * @return the Queue value
   */
  public String getQueue()
  {
    return properties.getProperty("queue");
  }

  /**
   * Standard setter for DeactWhen tag
   *
   * @param DeactWhen the DeactWhen value to set
   */
  public void setDeactWhen(String deactWhen)
  {
    properties.setProperty("deactWhen", deactWhen);
  }

  /**
   * Standard getter for DeactWhen tag
   *
   * @return the DeactWhen value
   */
  public String getDeactWhen()
  {
    return properties.getProperty("deactWhen");
  }

  /**
   * Standard setter for ChildQueue tag
   *
   * @param ChildQueue the ChildQueue value to set
   */
  public void setChildQueue(String childQueue)
  {
    properties.setProperty("childQueue", childQueue);
  }

  /**
   * Standard getter for ChildQueue tag
   *
   * @return the ChildQueue value
   */
  public String getChildQueue()
  {
    return properties.getProperty("childQueue");
  }

  /**
   * Standard setter for TZ tag
   *
   * @param TZ the TZ value to set
   */
  public void setTZ(String tZ)
  {
    properties.setProperty("tZ", tZ);
  }

  /**
   * Standard getter for TZ tag
   *
   * @return the TZ value
   */
  public String getTZ()
  {
    return properties.getProperty("tZ");
  }

  /**
   * Standard setter for AutoDeactNo
   *
   * @param AutoDeactNo the AutoDeactNo value to set
   */
  public void setAutoDeactNo(Integer autoDeactNo)
  {
    properties.setProperty("autoDeactNo", autoDeactNo.toString());
  }

  /**
   * Standard getter for AutoDeactNo
   *
   * @return the AutoDeactNo value
   */
  public Integer getAutoDeactNo()
  {
    return Integer.parseInt(properties.getProperty("autoDeactNo"));
  }

  /**
   * Standard setter for AutoDeactAlways
   *
   * @param AutoDeactAlways the AutoDeactAlways value to set
   */
  public void setAutoDeactAlways(Integer autoDeactAlways)
  {
    properties.setProperty("autoDeactAlways", autoDeactAlways.toString());
  }

  /**
   * Standard getter for AutoDeactAlways
   *
   * @return the AutoDeactAlways value
   */
  public Integer getAutoDeactAlways()
  {
    return Integer.parseInt(properties.getProperty("autoDeactAlways"));
  }

  /**
   * Standard setter for MaxParallel
   *
   * @param MaxParallel the MaxParallel value to set
   */
  public void setMaxParallel(Integer maxParallel)
  {
    properties.setProperty("maxParallel", maxParallel.toString());
  }

  /**
   * Standard getter for MaxParallel
   *
   * @return the MaxParallel value
   */
  public Integer getMaxParallel()
  {
    return Integer.parseInt(properties.getProperty("maxParallel"));
  }

  /**
   * Standard setter for ExtRepDef
   *
   * @param ExtRepDef the ExtRepDef value to set
   */
  public void setExtRepDef(Integer extRepDef)
  {
    properties.setProperty("extRepDef", extRepDef.toString());
  }

  /**
   * Standard getter for ExtRepDef
   *
   * @return the ExtRepDef value
   */
  public Integer getExtRepDef()
  {
    return Integer.parseInt(properties.getProperty("extRepDef"));
  }

  /**
   * Standard setter for ExtRepAll
   *
   * @param ExtRepAll the ExtRepAll value to set
   */
  public void setExtRepAll(Integer extRepAll)
  {
    properties.setProperty("extRepAll", extRepAll.toString());
  }

  /**
   * Standard getter for ExtRepAll
   *
   * @return the ExtRepAll value
   */
  public Integer getExtRepAll()
  {
    return Integer.parseInt(properties.getProperty("extRepAll"));
  }

  /**
   * Standard setter for ExtRepNone
   *
   * @param ExtRepNone the ExtRepNone value to set
   */
  public void setExtRepNone(Integer extRepNone)
  {
    properties.setProperty("extRepNone", extRepNone.toString());
  }

  /**
   * Standard getter for ExtRepNone
   *
   * @return the ExtRepNone value
   */
  public Integer getExtRepNone()
  {
    return Integer.parseInt(properties.getProperty("extRepNone"));
  }

  /**
   * Standard setter for ActAtRun
   *
   * @param ActAtRun the ActAtRun value to set
   */
  public void setActAtRun(Integer actAtRun)
  {
    properties.setProperty("actAtRun", actAtRun.toString());
  }

  /**
   * Standard getter for ActAtRun
   *
   * @return the ActAtRun value
   */
  public Integer getActAtRun()
  {
    return Integer.parseInt(properties.getProperty("actAtRun"));
  }

  /**
   * Standard setter for StartModeAuto
   *
   * @param StartModeAuto the StartModeAuto value to set
   */
  public void setStartModeAuto(Integer startModeAuto)
  {
    properties.setProperty("startModeAuto", startModeAuto.toString());
  }

  /**
   * Standard getter for StartModeAuto
   *
   * @return the StartModeAuto value
   */
  public Integer getStartModeAuto()
  {
    return Integer.parseInt(properties.getProperty("startModeAuto"));
  }

  /**
   * Standard setter for AutoDeact1ErrorFree
   *
   * @param AutoDeact1ErrorFree the AutoDeact1ErrorFree value to set
   */
  public void setAutoDeact1ErrorFree(Integer autoDeact1ErrorFree)
  {
    properties.setProperty("autoDeact1ErrorFree", autoDeact1ErrorFree.toString());
  }

  /**
   * Standard getter for AutoDeact1ErrorFree
   *
   * @return the AutoDeact1ErrorFree value
   */
  public Integer getAutoDeact1ErrorFree()
  {
    return Integer.parseInt(properties.getProperty("autoDeact1ErrorFree"));
  }

  /**
   * Standard setter for AutoDeactErrorFree
   *
   * @param AutoDeactErrorFree the AutoDeactErrorFree value to set
   */
  public void setAutoDeactErrorFree(Integer autoDeactErrorFree)
  {
    properties.setProperty("autoDeactErrorFree", autoDeactErrorFree.toString());
  }

  /**
   * Standard getter for AutoDeactErrorFree
   *
   * @return the AutoDeactErrorFree value
   */
  public Integer getAutoDeactErrorFree()
  {
    return Integer.parseInt(properties.getProperty("autoDeactErrorFree"));
  }

  /**
   * Standard setter for DeactDelay
   *
   * @param DeactDelay the DeactDelay value to set
   */
  public void setDeactDelay(Integer deactDelay)
  {
    properties.setProperty("deactDelay", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @return the DeactDelay value
   */
  public Integer getDeactDelay()
  {
    return Integer.parseInt(properties.getProperty("deactDelay"));
  }
}
