/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.user;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.usergrp.USRG;

/**
 * This class represents an Automic USER object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class USER extends USRG
{
  /** The user definition. */
  private USERDefinition userDefinition;
  /** The usrgu. */
  private USRGU usrgu;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * USER object in the context of an editor or in a code translator.
   */
  public USER()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the USERFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for USER.
   * @see USERFactory
   */
  public USER(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for USERDefinition.
   *
   * @return the USERDefinition value
   */
  public USERDefinition getUSERDefinition()
  {
    return userDefinition;
  }

  /**
   * Standard setter for USERDefinition.
   *
   * @param userDefinition the new USER definition
   */
  public void setUSERDefinition(USERDefinition userDefinition)
  {
    this.userDefinition = userDefinition;
  }

  /**
   * Standard getter for USRGU.
   *
   * @return the USRGU value
   */
  public USRGU getUSRGU()
  {
    return usrgu;
  }

  /**
   * Standard setter for USRGU.
   *
   * @param usrgu the new usrgu
   */
  public void setUSRGU(USRGU usrgu)
  {
    this.usrgu = usrgu;
  }
}