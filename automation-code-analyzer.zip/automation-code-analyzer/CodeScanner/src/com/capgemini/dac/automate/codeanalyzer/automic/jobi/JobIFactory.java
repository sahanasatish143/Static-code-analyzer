/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobi;

/**
 * A factory for creating JobI objects.
 *
 * @author 
 * @version 1.0
 * @since 1.0
 */
public interface JobIFactory
{
  
  /**
   * Gets the default job I.
   *
   * @return the default job I
   */
  public JobI getDefaultJobI();
  
  /**
   * Parses the job I from source.
   *
   * @return the job I
   */
  public JobI parseJobIFromSource();
}
