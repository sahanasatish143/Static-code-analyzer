package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface CitDefinitionFactory
{
  public CitDefinition getDefaultCitDefinition();
  public CitDefinition parseCitDefinitionFromSource();
}
