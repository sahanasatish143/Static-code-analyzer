/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class VARAMulti.
 */
public class VARAMulti
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA backend.
   */
  public VARAMulti()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new VARA backend.
   *
   * @param properties the properties
   */
  public VARAMulti(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the host dst.
   *
   * @param hostAttrType the new host dst
   */
  public void setVara1(String hostAttrType)
  {
    properties.setProperty("Vara1", hostAttrType);
  }

  /**
   * Gets the host dst.
   *
   * @return the host dst
   */
  public String getVara1()
  {
    return properties.getProperty("Vara1");
  }

  /**
   * Sets the apply task H.
   *
   * @param applyTaskH the new apply task H
   */
  public void setVara2(String applyTaskH)
  {
    properties.setProperty("Vara2", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getVara2()
  {
    return properties.getProperty("Vara2");
  }

  /**
   * Sets the resultformat.
   *
   * @param preferTaskHost the new resultformat
   */
  public void setresultformat(String preferTaskHost)
  {
    properties.setProperty("resultformat", preferTaskHost);
  }

  /**
   * Standard getter for state.
   *
   * @return the resultformat
   * @returns the state value
   */
  public String getresultformat()
  {
    return properties.getProperty("resultformat");
  }

  /**
   * Sets the union.
   *
   * @param preferTaskHost the new union
   */
  public void setunion(Integer preferTaskHost)
  {
    properties.setProperty("union", preferTaskHost.toString());
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public Integer getunion()
  {
    return Integer.parseInt(properties.getProperty("union"));
  }

  /**
   * Sets the intersection.
   *
   * @param preferTaskHost the new intersection
   */
  public void setintersection(Integer preferTaskHost)
  {
    properties.setProperty("intersection", preferTaskHost.toString());
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public Integer getintersection()
  {
    return Integer.parseInt(properties.getProperty("intersection"));
  }

  /**
   * Sets the minus.
   *
   * @param preferTaskHost the new minus
   */
  public void setminus(Integer preferTaskHost)
  {
    properties.setProperty("minus", preferTaskHost.toString());
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public Integer getminus()
  {
    return Integer.parseInt(properties.getProperty("minus"));
  }

 
}
