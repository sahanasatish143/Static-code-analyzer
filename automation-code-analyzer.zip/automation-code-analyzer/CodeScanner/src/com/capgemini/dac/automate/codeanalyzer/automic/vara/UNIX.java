package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class UNIX implements Iterable<VaraUnixRows>
{
  Properties properties;

  /** The rows. */
  private ArrayList<VaraUnixRows> rows;

  public UNIX(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<VaraUnixRows>();
  }

  public UNIX()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<VaraUnixRows>();
  }

  public void add(VaraUnixRows members)
  {
    rows.add(members);
  }

  @Override
  public Iterator<VaraUnixRows> iterator()
  {

    return rows.iterator();
  }

}
