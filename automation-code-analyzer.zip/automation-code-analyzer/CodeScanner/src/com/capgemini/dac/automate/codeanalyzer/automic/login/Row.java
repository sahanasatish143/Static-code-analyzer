/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.login;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class Row.
 */
public class Row
{
  
  /** The properties. */
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   * Archive1="sdasd" Archive2="231232" HW="1111" Icon="FILT"
   *  Icontype="" Name="DEMO"
   *  Role="*" SW="dasdasd"
   *   SWVers="sdas" Type="F" Version="dsdfsd111"
   */
  public Row()
  {
    this.properties = new Properties();
    this.setHost("");
    this.setLogin("");
    this.setMod(1);
    this.setPass("");
    this.setType("");
  }
  
  /**
   * Instantiates a new row.
   *
   * @param properties the properties
   */
  public Row(Properties properties)
  {
    this.properties = properties;
  }

 
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param Host the new host
   */
  public void setHost(String Host)
  {
    properties.setProperty("Host", Host);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the host
   * @returns the When ArchiveKey1
   */
  public String getHost()
  {
    return properties.getProperty("Host");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param Login the new login
   */
  public void setLogin(String Login)
  {
    properties.setProperty("Login", Login);
  }

  /**
   * Standard getter for Login.
   *
   * @return the login
   * @returns the When Login
   */
  public String getLogin()
  {
    return properties.getProperty("Login");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param hw the new mod
   */
  public void setMod(Integer hw)
  {
    properties.setProperty("Mod", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the mod
   * @returns the When ArchiveKey1
   */
  public String getMod()
  {
    return properties.getProperty("Mod");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param icon the new pass
   */
  public void setPass(String icon)
  {
    properties.setProperty("Pass", icon);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the pass
   * @returns the When ArchiveKey1
   */
  public String getPass()
  {
    return properties.getProperty("Pass");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param type the new type
   */
  public void setType(String type)
  {
    properties.setProperty("Type", type);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the type
   * @returns the When ArchiveKey1
   */
  public String getType()
  {
    return properties.getProperty("Type");
  }
}
