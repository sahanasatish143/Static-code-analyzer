package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionHTTPFactory
{
  public ConnectionHTTP getDefaultConnectionHTTP();
  public ConnectionHTTP parseConnectionHTTPFromSource();
}
