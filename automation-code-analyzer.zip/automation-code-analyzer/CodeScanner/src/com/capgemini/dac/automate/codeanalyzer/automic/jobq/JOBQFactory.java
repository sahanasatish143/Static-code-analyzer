package com.capgemini.dac.automate.codeanalyzer.automic.jobq;


public interface JOBQFactory
{
public JOBQ getDefaultJOBQ();
  
  
  public JOBQ parseJOBQFromSource();
}
