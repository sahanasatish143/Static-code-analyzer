package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.Properties;

public class ReferencesForImplementation
{

  Properties properties;
  // private ScoCollection scoAssemblyReferenceCollection;
  // private ScgList scgAssemblyReferenceList;
  private ReferencesDefinition referencesDefinition;

  public ReferencesForImplementation()
  {
    this.properties = new Properties();
    referencesDefinition = new ReferencesDefinition();
  }

  public ReferencesForImplementation(Properties properties)
  {
    this.properties = properties;
    referencesDefinition = new ReferencesDefinition();
  }

  public ReferencesDefinition getReferencesDefinition()
  {
    return referencesDefinition;
  }

  public void setReferencesDefinition(ReferencesDefinition referencesDefinition)
  {
    this.referencesDefinition = referencesDefinition;
  }

  /*
   * public ScgList getScgList() { return scgAssemblyReferenceList; }
   * 
   * public void setScgList(ScgList scgList) { this.scgAssemblyReferenceList =
   * scgList; }
   * 
   * public ScoCollection getScoCollection() { return
   * scoAssemblyReferenceCollection; }
   * 
   * public void setScoCollection(ScoCollection scoCollection) {
   * this.scoAssemblyReferenceCollection = scoCollection; }
   */
}
