/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * Represents a JobPAttr block of an Automic JobP object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class JobPAttr
{
   protected Properties properties;

  /**
   * Constructor to build a default JobPAttr object.
   */
  public JobPAttr()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setQueue("CLIENT_QUEUE");
    this.setChildQueue("");
    this.setStartType("");
    this.setExtRepDef(1);
    this.setExtRepAll(0);
    this.setExtRepNone(0);
    this.setIntAccount("");
    this.setAutoDeactNo(0);
    this.setAutoDeact1ErrorFree(0);
    this.setAutoDeactErrorFree(1);
    this.setDeactWhen("");
    this.setAutoDeactAlways(0);
    this.setDeactDelay(0);
    this.setActAtRun(1);
    this.setUC4Priority(0);
    this.setPassPriority(0);
    this.setMaxParallel2(0);
    this.setReuseHG(1);
    this.setMpElse1(1);
    this.setMpElse2(0);
    this.setTZ("");
    this.setRWhen("");
    this.setRExecute("");
    this.setJPA_SubType("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the JobPAttrFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public JobPAttr(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for Queue
   *
   * @param queue the Queue value to set
   */
  public void setQueue(String queue)
  {
    properties.setProperty("Queue", queue);
  }

  /**
   * Standard getter for Queue
   *
   * @returns the Queue value
   */
  public String getQueue()
  {
    return properties.getProperty("Queue");
  }

  /**
   * Standard setter for ChildQueue
   *
   * @param childQueue the ChildQueue value to set
   */
  public void setChildQueue(String childQueue)
  {
    properties.setProperty("ChildQueue", childQueue);
  }

  /**
   * Standard getter for ChildQueue
   *
   * @returns the ChildQueue value
   */
  public String getChildQueue()
  {
    return properties.getProperty("ChildQueue");
  }

  /**
   * Standard setter for StartType
   *
   * @param startType the StartType value to set
   */
  public void setStartType(String startType)
  {
    properties.setProperty("StartType", startType);
  }

  /**
   * Standard getter for StartType
   *
   * @returns the StartType value
   */
  public String getStartType()
  {
    return properties.getProperty("StartType");
  }

  /**
   * Standard setter for ExtRepDef
   *
   * @param extRepDef the ExtRepDef value to set
   */
  public void setExtRepDef(Integer extRepDef)
  {
    properties.setProperty("ExtRepDef", extRepDef.toString());
  }

  /**
   * Standard getter for ExtRepDef
   *
   * @returns the ExtRepDef value
   */
  public Integer getExtRepDef()
  {
    return Integer.parseInt(properties.getProperty("ExtRepDef"));
  }

  /**
   * Standard setter for ExtRepAll
   *
   * @param extRepAll the ExtRepAll value to set
   */
  public void setExtRepAll(Integer extRepAll)
  {
    properties.setProperty("ExtRepAll", extRepAll.toString());
  }

  /**
   * Standard getter for ExtRepAll
   *
   * @returns the ExtRepAll value
   */
  public Integer getExtRepAll()
  {
    return Integer.parseInt(properties.getProperty("ExtRepAll"));
  }

  /**
   * Standard setter for ExtRepNone
   *
   * @param extRepNone the ExtRepNone value to set
   */
  public void setExtRepNone(Integer extRepNone)
  {
    properties.setProperty("ExtRepNone", extRepNone.toString());
  }

  /**
   * Standard getter for ExtRepNone
   *
   * @returns the ExtRepNone value
   */
  public Integer getExtRepNone()
  {
    return Integer.parseInt(properties.getProperty("ExtRepNone"));
  }

  /**
   * Standard setter for IntAccount
   *
   * @param intAccount the IntAccount value to set
   */
  public void setIntAccount(String intAccount)
  {
    properties.setProperty("IntAccount", intAccount);
  }

  /**
   * Standard getter for IntAccount
   *
   * @returns the IntAccount value
   */
  public String getIntAccount()
  {
    return properties.getProperty("IntAccount");
  }

  /**
   * Standard setter for AutoDeactNo
   *
   * @param AutoDeactNo the autoDeactNo value to set
   */
  public void setAutoDeactNo(Integer autoDeactNo)
  {
    properties.setProperty("AutoDeactNo", autoDeactNo.toString());
  }

  /**
   * Standard getter for AutoDeactNo
   *
   * @returns the AutoDeactNo value
   */
  public Integer getAutoDeactNo()
  {
    return Integer.parseInt(properties.getProperty("AutoDeactNo"));
  }

  /**
   * Standard setter for AutoDeact1ErrorFree
   *
   * @param autoDeact1ErrorFree the AutoDeact1ErrorFree value to set
   */
  public void setAutoDeact1ErrorFree(Integer autoDeact1ErrorFree)
  {
    properties.setProperty("AutoDeact1ErrorFree", autoDeact1ErrorFree.toString());
  }

  /**
   * Standard getter for AutoDeact1ErrorFree
   *
   * @returns the AutoDeact1ErrorFree value
   */
  public Integer getAutoDeact1ErrorFree()
  {
    return Integer.parseInt(properties.getProperty("AutoDeact1ErrorFree"));
  }

  /**
   * Standard setter for AutoDeactErrorFree
   *
   * @param autoDeactErrorFree the AutoDeactErrorFree value to set
   */
  public void setAutoDeactErrorFree(Integer autoDeactErrorFree)
  {
    properties.setProperty("AutoDeactErrorFree", autoDeactErrorFree.toString());
  }

  /**
   * Standard getter for AutoDeactErrorFree
   *
   * @returns the AutoDeactErrorFree value
   */
  public Integer getAutoDeactErrorFree()
  {
    return Integer.parseInt(properties.getProperty("AutoDeactErrorFree"));
  }

  /**
   * Standard setter for DeactWhen
   *
   * @param deactWhen the DeactWhen value to set
   */
  public void setDeactWhen(String deactWhen)
  {
    properties.setProperty("DeactWhen", deactWhen);
  }

  /**
   * Standard getter for DeactWhen
   *
   * @returns the DeactWhen value
   */
  public String getDeactWhen()
  {
    return properties.getProperty("DeactWhen");
  }

  /**
   * Standard setter for AutoDeactAlways
   *
   * @param autoDeactAlways the AutoDeactAlways value to set
   */
  public void setAutoDeactAlways(Integer autoDeactAlways)
  {
    properties.setProperty("AutoDeactAlways", autoDeactAlways.toString());
  }

  /**
   * Standard getter for AutoDeactAlways
   *
   * @returns the AutoDeactAlways value
   */
  public Integer getAutoDeactAlways()
  {
    return Integer.parseInt(properties.getProperty("AutoDeactAlways"));
  }

  /**
   * Standard setter for DeactDelay
   *
   * @param deactDelay the DeactDelay value to set
   */
  public void setDeactDelay(Integer deactDelay)
  {
    properties.setProperty("DeactDelay", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @returns the DeactDelay value
   */
  public Integer getDeactDelay()
  {
    return Integer.parseInt(properties.getProperty("DeactDelay"));
  }

  /**
   * Standard setter for ActAtRun
   *
   * @param actAtRun the ActAtRun value to set
   */
  public void setActAtRun(Integer actAtRun)
  {
    properties.setProperty("ActAtRun", actAtRun.toString());
  }

  /**
   * Standard getter for ActAtRun
   *
   * @returns the ActAtRun value
   */
  public Integer ActAtRun()
  {
    return Integer.parseInt(properties.getProperty("ActAtRun"));
  }

  /**
   * Standard setter for UC4Priority
   *
   * @param uC4Priority the UC4Priority value to set
   */
  public void setUC4Priority(Integer uC4Priority)
  {
    properties.setProperty("UC4Priority", uC4Priority.toString());
  }

  /**
   * Standard getter for UC4Priority
   *
   * @returns the UC4Priority value
   */
  public Integer getUC4Priority()
  {
    return Integer.parseInt(properties.getProperty("UC4Priority"));
  }

  /**
   * Standard setter for PassPriority
   *
   * @param passPriority the PassPriority value to set
   */
  public void setPassPriority(Integer passPriority)
  {
    properties.setProperty("PassPriority", passPriority.toString());
  }

  /**
   * Standard getter for PassPriority
   *
   * @returns the PassPriority value
   */
  public Integer getPassPriority()
  {
    return Integer.parseInt(properties.getProperty("PassPriority"));
  }

  /**
   * Standard setter for MaxParallel2
   *
   * @param maxParallel2 the MaxParallel2 value to set
   */
  public void setMaxParallel2(Integer maxParallel2)
  {
    properties.setProperty("MaxParallel2", maxParallel2.toString());
  }

  /**
   * Standard getter for MaxParallel2
   *
   * @returns the MaxParallel2 value
   */
  public Integer getMaxParallel2()
  {
    return Integer.parseInt(properties.getProperty("MaxParallel2"));
  }

  /**
   * Standard setter for ReuseHG
   *
   * @param reuseHG the ReuseHG value to set
   */
  public void setReuseHG(Integer reuseHG)
  {
    properties.setProperty("ReuseHG", reuseHG.toString());
  }

  /**
   * Standard getter for ReuseHG
   *
   * @returns the ReuseHG value
   */
  public Integer getReuseHG()
  {
    return Integer.parseInt(properties.getProperty("ReuseHG"));
  }

  /**
   * Standard setter for MpElse1
   *
   * @param mpElse1 the MpElse1 value to set
   */
  public void setMpElse1(Integer mpElse1)
  {
    properties.setProperty("MpElse1", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @returns the MpElse1 value
   */
  public Integer getMpElse1()
  {
    return Integer.parseInt(properties.getProperty("MpElse1"));
  }

  /**
   * Standard setter for MpElse2
   *
   * @param mpElse2 the MpElse2 value to set
   */
  public void setMpElse2(Integer mpElse2)
  {
    properties.setProperty("MpElse2", mpElse2.toString());
  }

  /**
   * Standard getter for MpElse2
   *
   * @returns the MpElse2 value
   */
  public Integer getMpElse2()
  {
    return Integer.parseInt(properties.getProperty("MpElse2"));
  }

  /**
   * Standard setter for TZ
   *
   * @param tZ the TZ value to set
   */
  public void setTZ(String tZ)
  {
    properties.setProperty("TZ", tZ);
  }

  /**
   * Standard getter for TZ
   *
   * @returns the TZ value
   */
  public String getTZ()
  {
    return properties.getProperty("TZ");
  }

  /**
   * Standard setter for RWhen
   *
   * @param rWhen the RWhen value to set
   */
  public void setRWhen(String rWhen)
  {
    properties.setProperty("RWhen", rWhen);
  }

  /**
   * Standard getter for RWhen
   *
   * @returns the RWhen value
   */
  public String getRWhen()
  {
    return properties.getProperty("RWhen");
  }

  /**
   * Standard setter for RExecute
   *
   * @param rExecute the RExecute value to set
   */
  public void setRExecute(String rExecute)
  {
    properties.setProperty("RExecute", rExecute);
  }

  /**
   * Standard getter for RExecute
   *
   * @returns the RExecute value
   */
  public String getRExecute()
  {
    return properties.getProperty("RExecute");
  }

  /**
   * Standard setter for JPA_SubType
   *
   * @param jPA_SubType the JPA_SubType value to set
   */
  public void setJPA_SubType(String jPA_SubType)
  {
    properties.setProperty("JPA_SubType", jPA_SubType);
  }

  /**
   * Standard getter for JPA_SubType
   *
   * @returns the JPA_SubType value
   */
  public String getJPA_SubType()
  {
    return properties.getProperty("JPA_SubType");
  }
}