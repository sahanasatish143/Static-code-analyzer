/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.xsl;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;



/**
 * The Class XSL.
 *
 * @author 
 * @version 1.0
 * @since 1.0
 */
public class XSL extends AutomicExecutableObject
{

  /** The xsl definition. */
  private XSLDefinition xslDefinition;

  /**
   * Instantiates a new xsl.
   */
  public XSL()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new xsl.
   *
   * @param properties the properties
   */
  public XSL(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for XSLDefinition.
   *
   * @return the XSLDefinition value
   */
  public XSLDefinition getXSLDefinition()
  {
    return xslDefinition;
  }

  /**
   * Standard setter for XSLDefinition.
   *
   * @param xslDefinition the new XSL definition
   */
  public void setXSLDefinition(XSLDefinition xslDefinition)
  {
    this.xslDefinition = xslDefinition;
  }
}