package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARABackendFactory
{
  public VARABackend getDefaultVARABackend();
  public VARABackend parseVARABackendFromSource();
}
