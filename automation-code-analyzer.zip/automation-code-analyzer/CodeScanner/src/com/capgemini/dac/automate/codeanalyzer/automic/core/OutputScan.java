/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class OutputScan.
 */
public class OutputScan
{

  /** The properties. */
  private Properties properties;

  /**
   * Gets the properties.
   *
   * @return the properties
   */
  public OutputScan()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setInherit("");
    this.setFilterobjects("");
    this.setHostFsc("");
    this.setLoginFsc("");
  }

  /**
   * Instantiates a new output scan.
   *
   * @param properties the properties
   */
  public OutputScan(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Sets the properties.
   *
   * @param properties the new properties
   */
  public void setProperties(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Sets the state.
   *
   * @param state the new state
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for Inherit.
   *
   * @param inherit the new inherit
   * @paramInherit
   */
  public void setInherit(String inherit)
  {
    properties.setProperty("Inherit", inherit);
  }

  /**
   * Standard getter for Inherit.
   *
   * @return the Inheritvalue
   */
  public String getInherit()
  {
    return properties.getProperty("Inherit");
  }

  /**
   * Standard setter for filterobjects.
   *
   * @param filterobjects the new filterobjects
   */
  public void setFilterobjects(String filterobjects)
  {
    properties.setProperty("filterobjects", filterobjects);
  }

  /**
   * Standard getter for filterobjects.
   *
   * @return the filterobjects value
   */
  public String getOperatorAND()
  {
    return properties.getProperty("filterobjects");
  }

  /**
   * Standard setter for HostFsc.
   *
   * @param hostFsc the new host fsc
   */
  public void setHostFsc(String hostFsc)
  {
    properties.setProperty("HostFsc", hostFsc);
  }

  /**
   * Standard getter for HostFsc.
   *
   * @return the HostFsc value
   */
  public String getHostFsc()
  {
    return properties.getProperty("HostFsc");
  }

  /**
   * Standard setter for LoginFsc.
   *
   * @param loginFsc the new login fsc
   */
  public void setLoginFsc(String loginFsc)
  {
    properties.setProperty("LoginFsc", loginFsc);
  }

  /**
   * Standard getter for LoginFsc.
   *
   * @return the LoginFsc value
   */
  public String getLoginFsc()
  {
    return properties.getProperty("LoginFsc");
  }
}
