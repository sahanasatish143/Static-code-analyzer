package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

public interface JobQFilterDefinitionFactory
{
 public JobQFilterDefinition getDefaultJobQFilterDefinition();
 public JobQFilterDefinition parseJobQFilterDefinitionFromSource();
 
}
