/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.usergrp;

import java.util.Properties;

/**
 * This class represents an Automic PRIVILEGES under USRG object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class PRIVILEGES
{
  Properties properties;
  private PrivList privList;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the PRIVILEGESFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for PRIVILEGES.
   * @see PRIVILEGESFactory
   */
  public PRIVILEGES(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * PRIVILEGES under USRG object in the context of an editor or in a code
   * translator.
   */
  public PRIVILEGES()
  {
    this.properties = new Properties();
    this.setState(1);
  }

  /**
   * Standard getter for PrivList
   *
   * @return the PrivList value
   */
  public PrivList getPrivList()
  {
    return privList;
  }

  /**
   * Standard setter for PrivList
   *
   * @param PrivList the PrivList value to set
   */
  public void setPrivList(PrivList privList)
  {
    this.privList = privList;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

}
