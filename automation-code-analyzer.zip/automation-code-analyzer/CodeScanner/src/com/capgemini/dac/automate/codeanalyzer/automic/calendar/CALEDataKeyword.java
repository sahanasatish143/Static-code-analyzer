/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.calendar;

import java.util.Properties;

/**
 * This class represents an Automic CALEDataKeyword under CALE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CALEDataKeyword
{
  Properties properties;
  private KeywordGroup group;
  private KeywordDynamic dynamic;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CALEDataKeywordFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CALEDataKeyword.
   * @see CALEDataKeywordFactory
   */
  public CALEDataKeyword(Properties properties)
  {
    this.properties = properties;
    this.group = null;
    this.dynamic = null;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CALEDataKeyword under CALE object in the context of an editor or in a code
   * translator.
   */
  public CALEDataKeyword()
  {
    this.properties = new Properties();
    this.group = null;
    this.dynamic = null;
    this.setCType("");
    this.setErrMsgInsert("");
    this.setErrMsgNr(0);
    this.setMsgNr(0);
    this.setSType("");
    this.setValidFrom("");
    this.setValidTo("");
    this.setName("");
    this.setState(1);
  }

  /**
   * Standard setter for CType
   *
   * @param CType the CType value to set
   */
  public void setCType(String cType)
  {
    properties.setProperty("cType", cType);
  }

  /**
   * Standard getter for CType
   *
   * @return the CType value
   */
  public String getCType()
  {
    return properties.getProperty("cType");
  }

  /**
   * Standard setter for ErrMsgInsert
   *
   * @param ErrMsgInsert the ErrMsgInsert value to set
   */
  public void setErrMsgInsert(String errMsgInsert)
  {
    properties.setProperty("errMsgInsert", errMsgInsert);
  }

  /**
   * Standard getter for ErrMsgInsert
   *
   * @return the ErrMsgInsert value
   */
  public String getErrMsgInsert()
  {
    return properties.getProperty("errMsgInsert");
  }

  /**
   * Standard setter for SType
   *
   * @param SType the SType value to set
   */
  public void setSType(String sType)
  {
    properties.setProperty("sType", sType);
  }

  /**
   * Standard getter for SType
   *
   * @return the SType value
   */
  public String getSType()
  {
    return properties.getProperty("sType");
  }

  /**
   * Standard setter for ValidFrom
   *
   * @param ValidFrom the ValidFrom value to set
   */
  public void setValidFrom(String validFrom)
  {
    properties.setProperty("validFrom", validFrom);
  }

  /**
   * Standard getter for ValidFrom
   *
   * @return the ValidFrom value
   */
  public String getValidFrom()
  {
    return properties.getProperty("validFrom");
  }

  /**
   * Standard setter for ValidTo
   *
   * @param ValidTo the ValidTo value to set
   */
  public void setValidTo(String validTo)
  {
    properties.setProperty("validTo", validTo);
  }

  /**
   * Standard getter for ValidTo
   *
   * @return the ValidTo value
   */
  public String getValidTo()
  {
    return properties.getProperty("validTo");
  }

  /**
   * Standard setter for name
   *
   * @param name the name value to set
   */
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }

  /**
   * Standard getter for ValidTo
   *
   * @return the ValidTo value
   */
  public String getName()
  {
    return properties.getProperty("name");
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for MsgNr
   *
   * @param MsgNr the MsgNr value to set
   */
  public void setMsgNr(Integer msgNr)
  {
    properties.setProperty("msgNr", msgNr.toString());
  }

  /**
   * Standard getter for MsgNr
   *
   * @return the MsgNr value
   */
  public Integer getMsgNr()
  {
    return Integer.parseInt(properties.getProperty("msgNr"));
  }

  /**
   * Standard setter for ErrMsgNr
   *
   * @param ErrMsgNr the ErrMsgNr value to set
   */
  public void setErrMsgNr(Integer errMsgNr)
  {
    properties.setProperty("errMsgNr", errMsgNr.toString());
  }

  /**
   * Standard getter for ErrMsgNr
   *
   * @return the ErrMsgNr value
   */
  public Integer getErrMsgNr()
  {
    return Integer.parseInt(properties.getProperty("errMsgNr"));
  }

  /**
   * Standard getter for Group.
   *
   * @return the Group
   */
  public KeywordGroup getGroup()
  {
    return group;
  }

  /**
   * Standard setter for Group
   *
   * @param Group the Group to set
   */
  public void setGroup(KeywordGroup group)
  {
    this.group = group;
  }

  /**
   * Standard getter for Dynamic.
   *
   * @return the Dynamic
   */
  public KeywordDynamic getDynamic()
  {
    return dynamic;
  }

  /**
   * Standard setter for Dynamic
   *
   * @param Dynamic the Dynamic to set
   */
  public void setDynamic(KeywordDynamic dynamic)
  {
    this.dynamic = dynamic;
  }

  /**
   * Adds a dynamic to the list.
   *
   * @param the the dynamic to add to the collection
   */
  public void add(KeywordDynamic dynamic)
  {
    dynamic.add(dynamic);
  }

 

}
