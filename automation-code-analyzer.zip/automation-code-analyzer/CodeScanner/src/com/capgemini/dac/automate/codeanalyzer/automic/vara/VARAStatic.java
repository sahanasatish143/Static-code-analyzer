package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;





public class VARAStatic implements Iterable<VaraStaticRow>
{
  Properties properties;
 
  private ArrayList<VaraStaticRow> rows;
  public VARAStatic(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<VaraStaticRow>(); 
  }
  public VARAStatic()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<VaraStaticRow>(); 
  }

  public void add(VaraStaticRow row)
  {
    rows.add(row);
  }

  @Override
  public Iterator<VaraStaticRow> iterator()
  {
   return rows.iterator();
  }
}