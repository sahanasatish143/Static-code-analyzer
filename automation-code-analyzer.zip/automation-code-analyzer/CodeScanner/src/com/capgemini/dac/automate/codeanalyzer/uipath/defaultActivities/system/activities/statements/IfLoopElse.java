/*
* Copyright (c) 2019-20, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathObject;

/**
 * This class represents an UiPath If Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class IfLoopElse
{
  Properties properties;
  private List<UiPathObject> activity;

  /**
   * Default constructor. This is intended to be called for creation of a blank If
   * Activity in the context of an editor or in a code translator.
   */
  public IfLoopElse()
  {
    this.properties = new Properties();
    activity = new ArrayList<UiPathObject>();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the IfLoopElseFactory interface. All children objects ,inherited from
   * UiPathObject, will be null and are expected to be injected through setters by
   * the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   *                   properties for IfLoopElse.
   * @see IfLoopElseFactory
   */
  public IfLoopElse(Properties properties)
  {
    this.properties = new Properties();
    activity = new ArrayList<UiPathObject>();
  }

  public void add(UiPathObject object)
  {

    activity.add(object);
  }
}
