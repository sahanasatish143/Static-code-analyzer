/*
* Copyright (c) 2019-20, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathObject;

/**
 * This class represents an UiPath Delay Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class Delay extends UiPathObject
{

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * Delay Activity in the context of an editor or in a code translator.
   */
  public Delay()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the DelayFactory interface. All children objects ,inherited from
   * UiPathObject, will be null and are expected to be injected through setters by
   * the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for Delay.
   * @see DelayFactory
   */

  public Delay(Properties properties)
  {
    this.setProperties(properties);
  }

}