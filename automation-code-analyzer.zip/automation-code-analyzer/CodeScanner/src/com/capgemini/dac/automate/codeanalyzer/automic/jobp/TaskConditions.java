/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class TaskConditions implements Iterable<TaskCondition>
{
  Properties properties;
  private ArrayList<TaskCondition> conditions;
  
  /**
   * Constructor to build a default Runtime object.
   */
  public TaskConditions()
  {
    this.properties = new Properties();
    this.conditions = new ArrayList<TaskCondition>();
    this.setId("CONDITIONS");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskConditions(Properties properties)
  {
    this.properties = properties;
    this.conditions = new ArrayList<TaskCondition>();
  }
  
  /**
   * Standard setter for id
   *
   * @param id the id value to set
   */
  public void setId(String id)
  {
    properties.setProperty("id", id);
  }

  /**
   * Standard getter for id
   *
   * @returns the id value
   */
  public String getId()
  {
    return properties.getProperty("id");
  }

  /**
   * Adds a SyncRefRecord to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void add(TaskCondition condition)
  {
    conditions.add(condition);
  }

  
  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the SyncRefRecords in the collection
   */
  public Iterator<TaskCondition> iterator()
  {
    return this.conditions.iterator();
  }

}
