package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

public interface OperatorFactory
{

public Operator getDefaultOperator();
  
  
  public Operator parseOperatorFromSource();
}
