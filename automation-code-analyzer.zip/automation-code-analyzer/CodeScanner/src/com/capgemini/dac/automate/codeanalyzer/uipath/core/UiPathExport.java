/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class UiPathExport implements Iterable<UiPathObject>
{
  Properties properties;
  private List<UiPathObject> activityName;
  WorkflowViewStateService workFlowViewState;
  NamespacesForImplementation nameSpaces;
  ReferencesForImplementation references;
  Properties nameSpaceURIs ;

  /**
   * Default constructor. Meant to be called by a sub-class, not directly.
   */
  public UiPathExport()
  {
    properties = new Properties();
    activityName = new ArrayList<UiPathObject>();
    workFlowViewState = new WorkflowViewStateService();
    nameSpaces = new NamespacesForImplementation();
    references = new ReferencesForImplementation();
    nameSpaceURIs = new Properties();
  }

  public UiPathExport(Properties properties)
  {
    this.properties = properties;
    activityName = new ArrayList<UiPathObject>();
    workFlowViewState = new WorkflowViewStateService();
    nameSpaces = new NamespacesForImplementation();
    references = new ReferencesForImplementation();
    nameSpaceURIs = new Properties();
  }

  public void setWorkflowViewStateService(WorkflowViewStateService workFlowViewState)
  {
    this.workFlowViewState = workFlowViewState;
  }

  public WorkflowViewStateService getWorkflowViewStateService()
  {
    return workFlowViewState;
  }

  public void setReferencesForImplementation(ReferencesForImplementation references)
  {
    this.references = references;
  }

  public ReferencesForImplementation getReferencesForImplementation()
  {
    return references;
  }

  public void setNamespacesForImplementation(NamespacesForImplementation nameSpaces)
  {
    this.nameSpaces = nameSpaces;
  }

  public NamespacesForImplementation getNamespacesForImplementation()
  {
    return nameSpaces;
  }

  public void setObjects(List<UiPathObject> activityName)
  {
    this.activityName = activityName;
  }

  public void add(UiPathObject element)
  {
    activityName.add(element);
  }

  @Override
  public Iterator<UiPathObject> iterator()
  {
    return activityName.iterator();
  }

  public void setNameSpaceURIs(Properties nameSpaceURIs)
  {
    this.nameSpaceURIs = nameSpaceURIs;
    
  }

}