package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface WINDOWSFactory
{
  public WINDOWS getDefaultWINDOWS();
  public WINDOWS parseWINDOWSFromSource();
}
