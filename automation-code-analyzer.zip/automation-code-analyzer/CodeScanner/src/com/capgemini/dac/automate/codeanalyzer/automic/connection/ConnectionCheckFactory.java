package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionCheckFactory
{
  public ConnectionCheck getDefaultConnectionCheck();
  public ConnectionCheck parseConnectionCheckFromSource();
}
