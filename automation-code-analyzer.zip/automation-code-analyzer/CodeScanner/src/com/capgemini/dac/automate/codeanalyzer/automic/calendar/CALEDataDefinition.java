/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.calendar;

import java.util.Properties;

/**
 * This class represents an Automic CALEDataDefinition under CALE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CALEDataDefinition
{
  Properties properties;
  private CALEDataKeywords caleDataKeywords;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CALEDataDefinitionFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CALEDataDefinition.
   * @see CALEDataDefinitionFactory
   */
  public CALEDataDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CALEData object in the context of an editor or in a code translator.
   */
  public CALEDataDefinition()
  {
    this.properties = new Properties();
    this.setDisplayTo("");
    this.setDisplayFrom("");
    this.setPeriods(1);

  }

  /**
   * Standard getter for CALEDataKeywords
   *
   * @return the CALEDataKeywords value
   */
  public CALEDataKeywords getCALEDataKeywords()
  {
    return caleDataKeywords;
  }

  /**
   * Standard setter for CALEDataKeywords
   *
   * @param CALEDataKeywords the CALEDataKeywords value to set
   */
  public void setCALEDataKeywords(CALEDataKeywords caleDataKeywords)
  {
    this.caleDataKeywords = caleDataKeywords;
  }

  /**
   * Standard setter for periods
   *
   * @param periods the periods value to set
   */
  public void setPeriods(Integer periods)
  {
    properties.setProperty("periods", periods.toString());
  }

  /**
   * Standard getter for periods
   *
   * @return the periods value
   */
  public Integer getPeriods()
  {
    return Integer.parseInt(properties.getProperty("periods"));
  }

  /**
   * Standard setter for DisplayFrom
   *
   * @param DisplayFrom the DisplayFrom value to set
   */
  public void setDisplayFrom(String displayFrom)
  {
    properties.setProperty("displayFrom", displayFrom);
  }

  /**
   * Standard getter for DisplayFrom
   *
   * @return the DisplayFrom value
   */
  public String getDisplayFrom()
  {
    return properties.getProperty("displayFrom");
  }

  /**
   * Standard setter for DisplayTo
   *
   * @param DisplayTo the DisplayTo value to set
   */
  public void setDisplayTo(String displayTo)
  {
    properties.setProperty("displayTo", displayTo);
  }

  /**
   * Standard getter for DisplayTo
   *
   * @return the DisplayTo value
   */
  public String getDisplayTo()
  {
    return properties.getProperty("displayTo");
  }
}
