/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.analyzer;

import java.util.ArrayList;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicObject;
import com.capgemini.dac.automate.codeanalyzer.core.DACLogger;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.0
 */
public class RuleSetEvaluationReport
{
  ArrayList<RuleEvaluationRecord> results;
  
  public RuleSetEvaluationReport()
  {
    results = new ArrayList<RuleEvaluationRecord>();
  }
  
  public void add(RuleEvaluationRecord result)
  {
    results.add(result);
  }
  
  public void logReport()
  {
    for(RuleEvaluationRecord result: results)
    {
      AutomicObject ao = (AutomicObject)result.getObject();
      DACLogger.getLogger().logGeneralMessage("Name                         : " + ao.getName());
      DACLogger.getLogger().logGeneralMessage("    Title                    : " + ao.getHeader().getTitle());
      DACLogger.getLogger().logGeneralMessage("    Evaluation Record number : " + result.getRecordNumber().toString());
      DACLogger.getLogger().logGeneralMessage("    Evaluation against rule  : " + result.getRule().getID() + " : " + result.getRule().getTitle());
      DACLogger.getLogger().logGeneralMessage("    Evaluation Result        : " + result.getResult().getMessage());
      DACLogger.getLogger().logGeneralMessage("    Evaluated Vaule          : " + result.getResult().getActualValue() + "\n");
    }
  }
}