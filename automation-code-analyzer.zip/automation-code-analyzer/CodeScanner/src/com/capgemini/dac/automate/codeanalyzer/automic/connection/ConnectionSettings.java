package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

public class ConnectionSettings
{
  /** The properties. */
  Properties properties;
 
  /**
   * Instantiates a new connection attribute.
   */
  public ConnectionSettings()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new connection attribute.
   *
   * @param properties the properties
   */
  public ConnectionSettings(Properties properties)
  {
    this.properties = properties;
  }
  public void setTabConnString(TabConnString citcont)
  {
    properties.getProperty("tab.conn.string");
  }
  public void setTabConnProperties(TabConnProperties citcont)
  {
    properties.getProperty("tab.conn.properties");
  }
}
