/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.call;

import java.util.Properties;

/**
 * This class represents an Automic CALLAttributes under CALL object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CALLAttribute
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CALLAttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CALLAttribute.
   * @see CALLAttributeFactory
   */
  public CALLAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CALLAttribute under CALL object in the context of an editor or in a code
   * translator.
   */
  public CALLAttribute()
  {
    this.properties = new Properties();

  }

  /**
   * Standard setter for Object tag
   *
   * @param Object the Object value to set
   */
  public void setObject(String object)
  {
    properties.setProperty("Object", object);
  }

  /**
   * Standard Object for Object tag
   *
   * @return the Object value
   */
  public String getObject()
  {
    return properties.getProperty("Object");
  }

  /**
   * Standard Type for Type tag
   *
   * @return the Type value
   */
  public String getType()
  {
    return properties.getProperty("type");
  }

  /**
   * Standard setter for Type tag
   *
   * @param Type the Type value to set
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Standard setter for AutoDeact tag
   *
   * @param AutoDeact the AutoDeact value to set
   */
  public void setAutoDeact(Integer autoDeact)
  {
    properties.setProperty("AutoDeact", autoDeact.toString());
  }

  /**
   * Standard AutoDeact for AutoDeact tag
   *
   * @return the AutoDeact value
   */
  public Integer getAutoDeact()
  {
    return Integer.parseInt(properties.getProperty("AutoDeact"));
  }

  /**
   * Standard setter for EscTime tag
   *
   * @param EscTime the EscTime value to set
   */
  public void setEscTime(Integer escTime)
  {
    properties.setProperty("EscTime", escTime.toString());
  }

  /**
   * Standard External1 for EscTime tag
   *
   * @return the EscTime value
   */
  public Integer getEscTime()
  {
    return Integer.parseInt(properties.getProperty("EscTime"));
  }

  /**
   * Standard setter for Priority tag
   *
   * @param Priority the Priority value to set
   */
  public void setPriority(String priority)
  {
    properties.setProperty("Priority", priority);
  }

  /**
   * Standard External1 for Priority tag
   *
   * @return the Priority value
   */
  public String getPriority()
  {
    return properties.getProperty("Priority");
  }

  /**
   * Standard setter for External1 tag
   *
   * @param External1 the External1 value to set
   */
  public void setExternal1(Integer external1)
  {
    properties.setProperty("external1", external1.toString());
  }

  /**
   * Standard External1 for External1 tag
   *
   * @return the External1 value
   */
  public Integer getExternal1()
  {
    return Integer.parseInt(properties.getProperty("external1"));
  }

  /**
   * Standard setter for External2 tag
   *
   * @param External2 the External2 value to set
   */
  public void setExternal2(Integer external2)
  {
    properties.setProperty("external2", external2.toString());
  }

  /**
   * Standard External2 for External2 tag
   *
   * @return the External2 value
   */
  public Integer getExternal2()
  {
    return Integer.parseInt(properties.getProperty("external2"));
  }

  /**
   * Standard setter for Queue tag
   *
   * @param Queue the Queue value to set
   */
  public void setQueue(String queue)
  {
    properties.setProperty("queue", queue);
  }

  /**
   * Standard getter for Queue tag
   *
   * @return the Queue value
   */
  public String getQueue()
  {
    return properties.getProperty("queue");
  }

  /**
   * Standard setter for StartType tag
   *
   * @param StartType the StartType value to set
   */
  public void setStartType(String startType)
  {
    properties.setProperty("StartType", startType);
  }

  /**
   * Standard StartType for StartType tag
   *
   * @return the StartType value
   */
  public String getStartType()
  {
    return properties.getProperty("StartType");
  }

  /**
   * Standard setter for IntAccount tag
   *
   * @param IntAccount the IntAccount value to set
   */
  public void setIntAccount(String intAccount)
  {
    properties.setProperty("IntAccount", intAccount);
  }

  /**
   * Standard IntAccount for IntAccount tag
   *
   * @return the IntAccount value
   */
  public String getIntAccount()
  {
    return properties.getProperty("IntAccount");
  }

  /**
   * Standard setter for DeactWhen tag
   *
   * @param DeactWhen the DeactWhen value to set
   */
  public void setDeactWhen(String deactWhen)
  {
    properties.setProperty("deactWhen", deactWhen);
  }

  /**
   * Standard getter for DeactWhen tag
   *
   * @return the DeactWhen value
   */
  public String getDeactWhen()
  {
    return properties.getProperty("deactWhen");
  }

  /**
   * Standard setter for TZ tag
   *
   * @param TZ the TZ value to set
   */
  public void setTZ(String tZ)
  {
    properties.setProperty("tZ", tZ);
  }

  /**
   * Standard getter for TZ tag
   *
   * @return the TZ value
   */
  public String getTZ()
  {
    return properties.getProperty("tZ");
  }

  /**
   * Standard setter for AutoDeactNo
   *
   * @param AutoDeactNo the AutoDeactNo value to set
   */
  public void setAutoDeactNo(Integer autoDeactNo)
  {
    properties.setProperty("autoDeactNo", autoDeactNo.toString());
  }

  /**
   * Standard getter for AutoDeactNo
   *
   * @return the AutoDeactNo value
   */
  public Integer getAutoDeactNo()
  {
    return Integer.parseInt(properties.getProperty("autoDeactNo"));
  }

  /**
   * Standard setter for AutoDeactAlways
   *
   * @param AutoDeactAlways the AutoDeactAlways value to set
   */
  public void setAutoDeactAlways(Integer autoDeactAlways)
  {
    properties.setProperty("autoDeactAlways", autoDeactAlways.toString());
  }

  /**
   * Standard getter for AutoDeactAlways
   *
   * @return the AutoDeactAlways value
   */
  public Integer getAutoDeactAlways()
  {
    return Integer.parseInt(properties.getProperty("autoDeactAlways"));
  }

  /**
   * Standard setter for MaxParallel2
   *
   * @param MaxParallel2 the MaxParallel2 value to set
   */
  public void setMaxParallel2(Integer maxParallel2)
  {
    properties.setProperty("maxParallel2", maxParallel2.toString());
  }

  /**
   * Standard getter for MaxParallel2
   *
   * @return the MaxParallel2 value
   */
  public Integer getMaxParallel2()
  {
    return Integer.parseInt(properties.getProperty("maxParallel2"));
  }

  /**
   * Standard setter for ExtRepDef
   *
   * @param ExtRepDef the ExtRepDef value to set
   */
  public void setExtRepDef(Integer extRepDef)
  {
    properties.setProperty("extRepDef", extRepDef.toString());
  }

  /**
   * Standard getter for ExtRepDef
   *
   * @return the ExtRepDef value
   */
  public Integer getExtRepDef()
  {
    return Integer.parseInt(properties.getProperty("extRepDef"));
  }

  /**
   * Standard setter for ExtRepAll
   *
   * @param ExtRepAll the ExtRepAll value to set
   */
  public void setExtRepAll(Integer extRepAll)
  {
    properties.setProperty("extRepAll", extRepAll.toString());
  }

  /**
   * Standard getter for ExtRepAll
   *
   * @return the ExtRepAll value
   */
  public Integer getExtRepAll()
  {
    return Integer.parseInt(properties.getProperty("extRepAll"));
  }

  /**
   * Standard setter for ExtRepNone
   *
   * @param ExtRepNone the ExtRepNone value to set
   */
  public void setExtRepNone(Integer extRepNone)
  {
    properties.setProperty("extRepNone", extRepNone.toString());
  }

  /**
   * Standard getter for ExtRepNone
   *
   * @return the ExtRepNone value
   */
  public Integer getExtRepNone()
  {
    return Integer.parseInt(properties.getProperty("extRepNone"));
  }

  /**
   * Standard setter for ActAtRun
   *
   * @param ActAtRun the ActAtRun value to set
   */
  public void setActAtRun(Integer actAtRun)
  {
    properties.setProperty("actAtRun", actAtRun.toString());
  }

  /**
   * Standard getter for ActAtRun
   *
   * @return the ActAtRun value
   */
  public Integer getActAtRun()
  {
    return Integer.parseInt(properties.getProperty("actAtRun"));
  }

  /**
   * Standard setter for AutoDeact1ErrorFree
   *
   * @param AutoDeact1ErrorFree the AutoDeact1ErrorFree value to set
   */
  public void setAutoDeact1ErrorFree(Integer autoDeact1ErrorFree)
  {
    properties.setProperty("autoDeact1ErrorFree", autoDeact1ErrorFree.toString());
  }

  /**
   * Standard getter for AutoDeact1ErrorFree
   *
   * @return the AutoDeact1ErrorFree value
   */
  public Integer getAutoDeact1ErrorFree()
  {
    return Integer.parseInt(properties.getProperty("autoDeact1ErrorFree"));
  }

  /**
   * Standard setter for AutoDeactErrorFree
   *
   * @param AutoDeactErrorFree the AutoDeactErrorFree value to set
   */
  public void setAutoDeactErrorFree(Integer autoDeactErrorFree)
  {
    properties.setProperty("autoDeactErrorFree", autoDeactErrorFree.toString());
  }

  /**
   * Standard getter for AutoDeactErrorFree
   *
   * @return the AutoDeactErrorFree value
   */
  public Integer getAutoDeactErrorFree()
  {
    return Integer.parseInt(properties.getProperty("autoDeactErrorFree"));
  }

  /**
   * Standard setter for DeactDelay
   *
   * @param DeactDelay the DeactDelay value to set
   */
  public void setDeactDelay(Integer deactDelay)
  {
    properties.setProperty("deactDelay", deactDelay.toString());
  }

  /**
   * Standard getter for DeactDelay
   *
   * @return the DeactDelay value
   */
  public Integer getDeactDelay()
  {
    return Integer.parseInt(properties.getProperty("deactDelay"));
  }

  /**
   * Standard setter for MpElse1
   *
   * @param MpElse1 the MpElse1 value to set
   */
  public void setMpElse1(Integer mpElse1)
  {
    properties.setProperty("mpElse1", mpElse1.toString());
  }

  /**
   * Standard getter for MpElse1
   *
   * @return the MpElse1 value
   */
  public Integer getMpElse1()
  {
    return Integer.parseInt(properties.getProperty("mpElse1"));
  }

  /**
   * Standard setter for MpElse2
   *
   * @param MpElse2 the MpElse2 value to set
   */
  public void setMpElse2(Integer mpElse2)
  {
    properties.setProperty("mpElse2", mpElse2.toString());
  }

  /**
   * Standard getter for MpElse2
   *
   * @return the MpElse2 value
   */
  public Integer getMpElse2()
  {
    return Integer.parseInt(properties.getProperty("mpElse2"));
  }

  /**
   * Standard setter for UC4Priority
   *
   * @param UC4Priority the UC4Priority value to set
   */
  public void setUC4Priority(Integer uC4Priority)
  {
    properties.setProperty("UC4Priority", uC4Priority.toString());
  }

  /**
   * Standard getter for UC4Priority
   *
   * @return the UC4Priority value
   */
  public Integer getUC4Priority()
  {
    return Integer.parseInt(properties.getProperty("UC4Priority"));
  }
}
