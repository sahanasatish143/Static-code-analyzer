/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * This is the base class of all Automic objects. It holds the common members of
 * all Automic objects.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.0
 */
public abstract class AutomicObject
{
  protected Properties properties;
  private AutomicObjectHeader header;
  private AutomicObjectDocument docu;
  // FIXME the following five parameters are here until we fix all the direct name
  // references in the child objects and convert them to using the getters and
  // setter correctly
  protected String name;
  protected String title;
  protected String archiveKey1;
  protected String archiveKey2;
  protected String OH_SubType;

  /**
   * Default constructor. Meant to be called by a sub-class, not directly.
   */
  protected AutomicObject()
  {
    this.setProperties(new Properties());
    this.setHeader(new Header());
    this.setDocumentation(new AutomicObjectDocument());
    this.setName("NEW_DOCUMENT");
  }

  /**
   * This constructor is meant to be called by a sub-class, not directly from a
   * factory class. All children objects ,inherited from AutomicObject, will be
   * null and are expected to be injected through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for object.
   */
  protected AutomicObject(Properties properties)
  {
    this.setProperties(properties);
  }

  /**
   * Standard setter for name.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for the AutomicObject.
   */
  protected void setProperties(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for name.
   * 
   * @return A string holding the name of the object.
   */
  public String getName()
  {
    return properties.getProperty("name");
  }

  /**
   * Standard setter for name.
   * 
   * @param name A string holding the name of the object.
   */
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }

  /**
   * Standard getter for header.
   *
   * @return the header
   */
  public AutomicObjectHeader getHeader()
  {
    return header;
  }

  /**
   * Standard setter for header
   *
   * @param header the header to set
   */
  public void setHeader(AutomicObjectHeader header)
  {
    this.header = header;
  }

  /**
   * Standard setter for docu
   *
   * @param document the docu to set
   */
  public void setDocumentation(AutomicObjectDocument document)
  {
    this.docu = document;
  }

  /**
   * Standard getter for docu.
   *
   * @return the docu
   */
  public AutomicObjectDocument getDocumentation()
  {
    return this.docu;
  }
}