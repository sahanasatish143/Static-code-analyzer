/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;

public class JOBP extends AutomicExecutableObject
{
  private JobPAttr jobpattr;
  private JobStructure jobstructure;
  private Deployment deployment;
  private AutomicScript mainScript;

  public JOBP()
  {
    super();
    this.setAllowExternal(0);
  }

  public JOBP(Properties properties)
  {
    super(properties);
  }

  public void setDeployment(Deployment deployment)
  {
    this.deployment = deployment;
  }
  
  public Deployment getDeployment()
  {
    return this.deployment;
  }

  public void setJobPAttr(JobPAttr attributes)
  {
    this.jobpattr = attributes;
  }

  public JobPAttr getJobPAttr()
  {
    return this.jobpattr;
  }

  public void setJobStructure(JobStructure structure)
  {
    this.jobstructure = structure;
  }
  
  public JobStructure getJobStructure()
  {
    return this.jobstructure;
  }

  public void setScript(AutomicScript script)
  {
    this.mainScript = script;
  }

  public AutomicScript getScript()
  {
    return this.mainScript;
  }

  public void setAllowExternal(Integer allowExternal)
  {
    properties.setProperty("AllowExternal", allowExternal.toString());
  }
  
  public Integer getAllowExternal()
  {
    return Integer.parseInt(properties.getProperty("AllowExternal"));
  }
}