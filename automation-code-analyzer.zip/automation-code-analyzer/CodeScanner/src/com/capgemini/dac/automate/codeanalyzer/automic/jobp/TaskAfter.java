/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * Represents a single after block of an Automic JobP object job structure task.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class TaskAfter
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public TaskAfter()
  {
    this.properties = new Properties();
    this.setActFlag(1);
    this.setAtimOn(0);
    this.setErlstStDays(0);
    this.setErlstStTime("00:00");
    this.setErlstStTimeTZ("");
    this.setHoldFlg(0);
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskAfter(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for ActFlag
   *
   * @param actFlag the ActFlag value to set
   */
  public void setActFlag(Integer actFlag)
  {
    properties.setProperty("ActFlag", actFlag.toString());
  }

  /**
   * Standard getter for ActFlag
   *
   * @returns the ActFlag value
   */
  public Integer getActFlag()
  {
    return Integer.parseInt(properties.getProperty("ActFlag"));
  }

  /**
   * Standard setter for AtimOn
   *
   * @param atimOn the AtimOn value to set
   */
  public void setAtimOn(Integer atimOn)
  {
    properties.setProperty("AtimOn", atimOn.toString());
  }

  /**
   * Standard getter for AtimOn
   *
   * @returns the AtimOn value
   */
  public Integer getAtimOn()
  {
    return Integer.parseInt(properties.getProperty("AtimOn"));
  }

  /**
   * Standard setter for ErlstStDays
   *
   * @param erlstStDays the ErlstStDays value to set
   */
  public void setErlstStDays(Integer erlstStDays)
  {
    properties.setProperty("ErlstStDays", erlstStDays.toString());
  }

  /**
   * Standard getter for ErlstStDays
   *
   * @returns the ErlstStDays value
   */
  public Integer getErlstStDays()
  {
    return Integer.parseInt(properties.getProperty("ErlstStDays"));
  }

  /**
   * Standard setter for ErlstStTime
   *
   * @param erlstStTime the ErlstStTime value to set
   */
  public void setErlstStTime(String erlstStTime)
  {
    properties.setProperty("ErlstStTime", erlstStTime);
  }

  /**
   * Standard getter for ErlstStTime
   *
   * @returns the ErlstStTime value
   */
  public String getErlstStTime()
  {
    return properties.getProperty("ErlstStTime");
  }

  /**
   * Standard setter for ErlstStTimeTZ
   *
   * @param erlstStTimeTZ the ErlstStTimeTZ value to set
   */
  public void setErlstStTimeTZ(String erlstStTimeTZ)
  {
    properties.setProperty("ErlstStTimeTZ", erlstStTimeTZ);
  }

  /**
   * Standard getter for ErlstStTimeTZ
   *
   * @returns the ErlstStTimeTZ value
   */
  public String getErlstStTimeTZ()
  {
    return properties.getProperty("ErlstStTimeTZ");
  }

  /**
   * Standard setter for HoldFlg
   *
   * @param holdFlg the HoldFlg value to set
   */
  public void setHoldFlg(Integer holdFlg)
  {
    properties.setProperty("HoldFlg", holdFlg.toString());
  }

  /**
   * Standard getter for HoldFlg
   *
   * @returns the HoldFlg value
   */
  public Integer getHoldFlg()
  {
    return Integer.parseInt(properties.getProperty("HoldFlg"));
  }
}