package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class BindParams implements Iterable<VaraParametersRows>
{
  Properties properties;

  /** The rows. */
  private ArrayList<VaraParametersRows> rows;

  public BindParams(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<VaraParametersRows>();
  }

  public BindParams()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<VaraParametersRows>();
  }

  public void add(VaraParametersRows members)
  {
    rows.add(members);
  }

  @Override
  public Iterator<VaraParametersRows> iterator()
  {
    
    return rows.iterator();
  }

}
