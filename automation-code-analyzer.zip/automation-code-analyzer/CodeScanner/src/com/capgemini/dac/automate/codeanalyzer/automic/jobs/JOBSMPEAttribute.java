/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSMPEAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSMPEAttribute object in the context of an editor or in a code translator.
   */
  public JOBSMPEAttribute()
  {
    this.properties = new Properties();
    this.setQueue("");
    this.setJobName("");
    this.setInputPriority(0);
    this.setHIPRI(0);
    this.setOther("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSMPEAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSMPEAttribute.
   * @see JOBSMPEAttributeFactory
   */
  public JOBSMPEAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for HIPRI.
   *
   * @param HIPRI the HIPRI value to set
   */
  public void setHIPRI(Integer hIPRI)
  {
    properties.setProperty("HIPRI", hIPRI.toString());
  }

  /**
   * Standard getter for HIPRI.
   *
   * @return the HIPRI
   * @returns the HIPRI value
   */
  public Integer getHIPRI()
  {
    return Integer.parseInt(properties.getProperty("HIPRI"));
  }

  /**
   * Standard setter for InputPriority.
   *
   * @param InputPriority the HIPInputPriorityRI value to set
   */
  public void setInputPriority(Integer inputPriority)
  {
    properties.setProperty("InputPriority", inputPriority.toString());
  }

  /**
   * Standard getter for InputPriority.
   *
   * @return the InputPriority
   * @returns the InputPriority value
   */
  public Integer getInputPriority()
  {
    return Integer.parseInt(properties.getProperty("InputPriority"));
  }

  /**
   * Standard setter for JobName.
   *
   * @param JobName the JobName value to set
   */
  public void setJobName(String jobName)
  {
    properties.setProperty("JobName", jobName);
  }

  /**
   * Standard getter for JobName.
   *
   * @return the JobName
   * @returns the JobName value
   */
  public String getJobName()
  {
    return properties.getProperty("JobName");
  }

  /**
   * Standard setter for Queue.
   *
   * @param Queue the Queue value to set
   */
  public void setQueue(String queue)
  {
    properties.setProperty("Queue", queue);
  }

  /**
   * Standard getter for Queue.
   *
   * @return the Queue
   * @returns the Queue value
   */
  public String getQueue()
  {
    return properties.getProperty("Queue");
  }

  /**
   * Standard setter for Other.
   *
   * @param Other the Other value to set
   */
  public void setOther(String other)
  {
    properties.setProperty("Other", other);
  }

  /**
   * Standard getter for Other.
   *
   * @return the Other
   * @returns the Other value
   */
  public String getOther()
  {
    return properties.getProperty("Other");
  }
}
