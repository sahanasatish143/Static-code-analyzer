package com.capgemini.dac.automate.codeanalyzer.automic.folder;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicObject;

public class FolderObjectReference implements FolderItem
{
  Properties properties;
  private AutomicObject reference;

  public FolderObjectReference()
  {
    this.properties = new Properties();
    this.setId(0);
    this.setLink(0);
    this.setName("");
    this.setType("");
    this.setReference(null);
  }
  
  public FolderObjectReference(Properties properties)
  {
    this.properties = properties;  
  }
  
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }
  
  public String getName()
  {
    return properties.getProperty("name");
  }

  public void setType(String type)
  {
    properties.setProperty("type", type);
  }
  
  public String getType()
  {
    return properties.getProperty("type");
  }
  
  public void setId(Integer id)
  {
    properties.setProperty("id", id.toString());
  }
  
  public Integer getId()
  {
    return Integer.parseInt(properties.getProperty("id"));
  }
  
  public void setLink(Integer link)
  {
    properties.setProperty("link", link.toString());
  }
  
  public Integer getLink()
  {
    return Integer.parseInt(properties.getProperty("link"));
  }
  
  public void setReference(AutomicObject reference)
  {
    this.reference = reference;
  }
  
  public AutomicObject getRefenece()
  {
    return this.reference;
  }
}