package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionSQLFactory
{
  public ConnectionSQL getDefaultConnectionSQL();
  public ConnectionSQL parseConnectionSQLFromSource();
}
