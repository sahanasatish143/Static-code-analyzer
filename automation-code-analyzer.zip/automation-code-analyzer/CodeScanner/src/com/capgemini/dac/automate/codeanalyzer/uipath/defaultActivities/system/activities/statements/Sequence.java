/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathObject;
import com.capgemini.dac.automate.codeanalyzer.uipath.core.WorkflowViewStateService;

/**
 * This class represents an UiPath Sequence Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class Sequence extends UiPathObject
{
  private SequenceActivityVariable sequenceVariable;;
  private WorkflowViewStateService workFlowViewState;
  private List<UiPathObject> activities;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * Sequence Activity in the context of an editor or in a code translator.
   */
  public Sequence()
  {
    this.properties = new Properties();
    workFlowViewState = new WorkflowViewStateService();
    sequenceVariable = new SequenceActivityVariable();
    activities = new ArrayList<UiPathObject>();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the SequenceFactory interface. All children objects ,inherited from
   * UiPathObject, will be null and are expected to be injected through setters by
   * the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for Sequence.
   * @see SequenceFactory
   */

  public Sequence(Properties properties)
  {
    this.setProperties(properties);
    workFlowViewState = new WorkflowViewStateService();
    sequenceVariable = new SequenceActivityVariable();
    activities = new ArrayList<UiPathObject>();
  }

  /**
   * Standard setter for WorkflowViewStateService
   *
   * @param sequence the WorkflowViewStateService value to set
   */
  public void setWorkflowViewStateService(WorkflowViewStateService sequence)
  {
    this.workFlowViewState = sequence;
  }

  /**
   * Standard getter for WorkflowViewStateService
   *
   * @return the WorkflowViewStateService value
   */
  public WorkflowViewStateService getWorkflowViewStateService()
  {
    return this.workFlowViewState;
  }

  /**
   * Standard setter for SequenceActivityVariable
   *
   * @param sequence the SequenceActivityVariable value to set
   */
  public void setSequenceVariable(SequenceActivityVariable sequence)
  {
    this.sequenceVariable = sequence;
  }

  /**
   * Standard getter for SequenceActivityVariable
   *
   * @return the SequenceActivityVariable value
   */
  public SequenceActivityVariable getSequenceVariable()
  {
    return this.sequenceVariable;
  }

  public void add(UiPathObject object)
  {
    activities.add(object);

  }

}