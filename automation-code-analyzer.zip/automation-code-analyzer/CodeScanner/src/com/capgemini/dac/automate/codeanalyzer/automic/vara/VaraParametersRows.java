/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

/**
 * The Class VaraParametersRows.
 */
public class VaraParametersRows
{

  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new vara parameters rows.
   */
  public VaraParametersRows()
  {
    this.properties = new Properties();

    this.setLnr(1);
    this.setIdnr(2227);
    this.setId(2227);
    this.setVName("");
    this.setName("");
    this.setValue("");
  }

  /**
   * Instantiates a new vara parameters rows.
   *
   * @param properties the properties
   */
  public VaraParametersRows(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory
   * interface.
   *
   * @param archiveKey2 the new v name
   */
  public void setVName(String archiveKey2)
  {
    properties.setProperty("VName", archiveKey2);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the v name
   * @returns the When ArchiveKey1
   */
  public String getVName()
  {
    return properties.getProperty("VName");
  }

  public void setName(String archiveKey2)
  {
    properties.setProperty("Name", archiveKey2);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the v name
   * @returns the When ArchiveKey1
   */
  public String getName()
  {
    return properties.getProperty("Name");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory
   * interface.
   *
   * @param hw the new lnr
   */
  public void setLnr(Integer hw)
  {
    properties.setProperty("Lnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the lnr
   * @returns the When ArchiveKey1
   */
  public String getLnr()
  {
    return properties.getProperty("Lnr");
  }

  /**
   * Sets the idnr.
   *
   * @param hw the new idnr
   */
  public void setIdnr(Integer hw)
  {
    properties.setProperty("Idnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the idnr
   * @returns the When ArchiveKey1
   */
  public String getIdnr()
  {
    return properties.getProperty("Idnr");
  }

  public void setId(Integer hw)
  {
    properties.setProperty("Id", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the idnr
   * @returns the When ArchiveKey1
   */
  public String getId()
  {
    return properties.getProperty("Id");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory
   * interface.
   *
   * @param icon the new value
   */
  public void setValue(String icon)
  {
    properties.setProperty("Value", icon);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the value
   * @returns the When ArchiveKey1
   */
  public String getValue()
  {
    return properties.getProperty("Value");
  }

}
