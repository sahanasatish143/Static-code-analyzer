package com.capgemini.dac.automate.codeanalyzer.uipath.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class ReferencesDefinition implements Iterable<String>
{
  Properties properties;
  ArrayList<String> referencesDefinition;

  public ReferencesDefinition(Properties properties)
  {
    this.properties = properties;
    referencesDefinition = new ArrayList<String>();

  }

  public ReferencesDefinition()
  {
    this.properties = new Properties();
    referencesDefinition = new ArrayList<String>();
  }

  @Override
  public Iterator<String> iterator()
  {
    return referencesDefinition.iterator();
  }

  public void add(String rows)
  {
    referencesDefinition.add(rows);

  }
}
