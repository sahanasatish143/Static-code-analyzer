package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class JobQFilterDefinition implements Iterable<Operator>
{
  Properties properties;
  private ArrayList<Operator> operator;

  public JobQFilterDefinition()
  {
    this.properties = new Properties();
    this.setMaxLen(25);
    this.setMaxValue(0);
    this.setMinValue(0);
    this.setName("");
    this.setOR("");
    this.setType("");
    this.operator = new ArrayList<Operator>();

  }

  public JobQFilterDefinition(Properties properties)
  {
    this.properties = properties;
    this.operator = new ArrayList<Operator>();

  }

  public void setMaxLen(Integer maxLen)
  {
    properties.setProperty("MaxLen", maxLen.toString());
  }

  public Integer getMaxLen()
  {
    return Integer.parseInt(properties.getProperty("MaxLen"));
  }

  public void setMaxValue(Integer mode)
  {
    properties.setProperty("MaxValue", mode.toString());
  }

  public Integer getMaxValue()
  {
    return Integer.parseInt(properties.getProperty("MaxValue"));
  }

  public void setMinValue(Integer mode)
  {
    properties.setProperty("MinValue", mode.toString());
  }

  public Integer getMinValue()
  {
    return Integer.parseInt(properties.getProperty("MinValue"));
  }

  public void setName(String mode)
  {
    properties.setProperty("Name", mode);
  }

  public String getName()
  {
    return properties.getProperty("Name");
  }

  public void setOR(String mode)
  {
    properties.setProperty("OR", mode);
  }

  public String getOR()
  {
    return properties.getProperty("OR");
  }

  public void setType(String mode)
  {
    properties.setProperty("Type", mode);
  }

  public String getType()
  {
    return properties.getProperty("Type");
  }

  public void add(Operator operators)
  {
    operator.add(operators);
  }

  @Override
  public Iterator<Operator> iterator()
  {
    return operator.iterator();
  }

}
