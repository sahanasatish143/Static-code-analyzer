package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface CitcontFactory
{
 public Citcont getDefaultCitcont();
 public Citcont parseCitcontFromSource();
}
