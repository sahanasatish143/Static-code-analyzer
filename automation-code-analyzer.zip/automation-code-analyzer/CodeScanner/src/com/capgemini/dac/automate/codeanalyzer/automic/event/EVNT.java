/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;

/**
 * This class represents an Automic EVENT object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNT extends AutomicExecutableObject
{
  private EVNTCaleRef eventCaleRef;
  private EVNTAttribute eventAttribute;
  private EVNTDefinition eventDefinition;
  private EVNTFile eventFile;
  private EVNTCons eventCons;
  private EVNTIA eventIA;
  private EVNTDB eventDB;
  private AutomicScript evntScript;
  private AutomicScript evntPreScript;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVENT object in the context of an editor or in a code translator.
   */
  public EVNT()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVENTFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVENT.
   * @see EVENTFactory
   */
  public EVNT(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for EVNTCaleRef
   *
   * @return the EVNTCaleRef value
   */
  public EVNTCaleRef getEVNTCaleRef()
  {
    return eventCaleRef;
  }

  /**
   * Standard setter for EVNTCaleRef
   *
   * @param EVNTCaleRef the EVNTCaleRef value to set
   */
  public void setEVNTCaleRef(EVNTCaleRef eventCaleRef)
  {
    this.eventCaleRef = eventCaleRef;
  }

  /**
   * Standard getter for EVNTDB
   *
   * @return the EVNTDB value
   */
  public EVNTDB getEVNTDB()
  {
    return eventDB;
  }

  /**
   * Standard setter for EVNTDB
   *
   * @param EVNTDB the EVNTDB value to set
   */
  public void setEVNTDB(EVNTDB eventDB)
  {
    this.eventDB = eventDB;
  }

  /**
   * Standard getter for EVNTDefinition
   *
   * @return the EVNTDefinition value
   */
  public EVNTDefinition getEVNTDefinition()
  {
    return eventDefinition;
  }

  /**
   * Standard setter for EVNTDefinition
   *
   * @param EVNTDefinition the EVNTDefinition value to set
   */
  public void setEVNTDefinition(EVNTDefinition eventDefinition)
  {
    this.eventDefinition = eventDefinition;
  }

  /**
   * Standard getter for EVNTIA
   *
   * @return the EVNTIA value
   */
  public EVNTIA getEVNTIA()
  {
    return eventIA;
  }

  /**
   * Standard setter for EVNTIA
   *
   * @param EVNTIA the EVNTIA value to set
   */
  public void setEVNTIA(EVNTIA eventIA)
  {
    this.eventIA = eventIA;
  }

  /**
   * Standard getter for EVNTCons
   *
   * @return the EVNTCons value
   */
  public EVNTCons getEVNTCons()
  {
    return eventCons;
  }

  /**
   * Standard setter for EVNTCons
   *
   * @param EVNTCons the EVNTCons value to set
   */
  public void setEVNTCons(EVNTCons eventCons)
  {
    this.eventCons = eventCons;
  }

  /**
   * Standard getter for EVNTFile
   *
   * @return the EVNTFile value
   */
  public EVNTFile getEVNTFile()
  {
    return eventFile;
  }

  /**
   * Standard setter for EVNTFile
   *
   * @param EVNTFile the EVNTFile value to set
   */
  public void setEVNTFile(EVNTFile eventFile)
  {
    this.eventFile = eventFile;
  }

  /**
   * Standard getter for EVNTAttribute
   *
   * @return the EVNTAttribute value
   */
  public EVNTAttribute getEVNTAttribute()
  {
    return eventAttribute;
  }

  /**
   * Standard setter for EVNTAttribute
   *
   * @param EVNTAttribute the EVNTAttribute value to set
   */
  public void setEVNTAttribute(EVNTAttribute eventAttribute)
  {
    this.eventAttribute = eventAttribute;
  }

  /**
   * Standard setter for AutomicScript
   *
   * @param AutomicScript the AutomicScript value to set
   */
  public void setScript(AutomicScript script)
  {
    this.evntScript = script;
    this.evntPreScript = script;
  }

  /**
   * Standard getter for AutomicScript
   *
   * @return the AutomicScript value
   */
  public AutomicScript getScript()
  {
    return this.evntScript;
  }

  /**
   * Standard setter for AutomicScript
   *
   * @param AutomicScript the AutomicScript value to set
   */
  public void setPreScript(AutomicScript script)
  {

    this.evntPreScript = script;
  }

  /**
   * Standard getter for AutomicScript
   *
   * @return the AutomicScript value
   */
  public AutomicScript getPreScript()
  {
    return this.evntPreScript;
  }
}
