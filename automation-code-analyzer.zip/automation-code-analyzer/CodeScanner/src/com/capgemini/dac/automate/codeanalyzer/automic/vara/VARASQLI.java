/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class VARASQLI.
 */
public class VARASQLI
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA backend.
   */
  public VARASQLI()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new VARA backend.
   *
   * @param properties the properties
   */
  public VARASQLI(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the host dst.
   *
   * @param hostAttrType the new host dst
   */
  public void setcommandsql(String hostAttrType)
  {
    properties.setProperty("command.sql", hostAttrType);
  }

  /**
   * Gets the host dst.
   *
   * @return the host dst
   */
  public String getcommandsql()
  {
    return properties.getProperty("command.sql");
  }

  /**
   * Sets the commandora.
   *
   * @param applyTaskH the new commandora
   */
  public void setcommandora(String applyTaskH)
  {
    properties.setProperty("command.ora", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getcommandora()
  {
    return properties.getProperty("command.ora");
  }

  /**
   * Sets the resultformat.
   *
   * @param applyTaskH the new commanddb 2
   */

  public void setcommanddb2(String applyTaskH)
  {
    properties.setProperty("command.db2", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getcommanddb2()
  {
    return properties.getProperty("command.db2");
  }

  /**
   * Sets the resultformat.
   *
   * @param applyTaskH the new resultformat
   */
  public void setresultformat(String applyTaskH)
  {
    properties.setProperty("resultformat", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getresultformat()
  {
    return properties.getProperty("resultformat");
  }

  /**
   * Sets the commandpostgres.
   *
   * @param applyTaskH the new commandpostgres
   */
  public void setcommandpostgres(String applyTaskH)
  {
    properties.setProperty("command.postgres", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getcommandpostgres()
  {
    return properties.getProperty("command.postgres");
  }

  /**
   * Sets the infobar.
   *
   * @param applyTaskH the new infobar
   */
  public void setinfobar(String applyTaskH)
  {
    properties.setProperty("infobar", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getinfobar()
  {
    return properties.getProperty("infobar");
  }
  public void setBindParams(BindParams parseMembersFromSource)
  {
    properties.getProperty("BindParams");
  }
}
