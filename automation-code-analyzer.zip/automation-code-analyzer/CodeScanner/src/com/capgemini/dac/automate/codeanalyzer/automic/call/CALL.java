/*
* Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.call;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;

/**
 * This class represents an Automic CALL object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CALL extends AutomicExecutableObject
{
  private CALLDefinition callDefinition;
  private CALLAttribute callAttribute;
  private NOTIFICATION notification;
  private AutomicScript mainScript;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CALL object in the context of an editor or in a code translator.
   */
  public CALL()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CALLFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CALL.
   * @see CALLFactory
   */
  public CALL(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for CALLDefinition
   *
   * @return the CALLDefinition value
   */
  public CALLDefinition getCALLDefinition()
  {
    return callDefinition;
  }

  /**
   * Standard setter for CALLDefinition
   *
   * @param CALLDefinition the CALLDefinition value to set
   */
  public void setCALLDefinition(CALLDefinition callDefinition)
  {
    this.callDefinition = callDefinition;
  }

  /**
   * Standard getter for CALLAttribute
   *
   * @return the CALLAttribute value
   */
  public CALLAttribute getCALLAttribute()
  {
    return callAttribute;
  }

  /**
   * Standard setter for CALLAttribute
   *
   * @param CALLAttribute the CALLAttribute value to set
   */
  public void setCALLAttribute(CALLAttribute callAttribute)
  {
    this.callAttribute = callAttribute;
  }

  /**
   * Standard getter for NOTIFICATION
   *
   * @return the NOTIFICATION value
   */
  public NOTIFICATION getNOTIFICATION()
  {
    return notification;
  }

  /**
   * Standard setter for NOTIFICATION
   *
   * @param NOTIFICATION the NOTIFICATION value to set
   */
  public void setNOTIFICATION(NOTIFICATION notification)
  {
    this.notification = notification;
  }

  /**
   * Standard getter for mainScript
   *
   * @return the mainScript value
   */
  public void setScript(AutomicScript call)
  {
    this.mainScript = call;
  }

  /**
   * Standard setter for mainScript
   *
   * @param mainScript the mainScript value to set
   */
  public AutomicScript getScript()
  {
    return this.mainScript;
  }

}