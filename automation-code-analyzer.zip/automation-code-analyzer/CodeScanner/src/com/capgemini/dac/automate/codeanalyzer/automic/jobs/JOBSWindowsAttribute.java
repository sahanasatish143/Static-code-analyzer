/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSWindowsAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSWindowsAttribute object in the context of an editor or in a code
   * translator.
   */
  public JOBSWindowsAttribute()
  {
    this.properties = new Properties();
    this.setIsGenerated(0);
    this.setBAT(1);
    this.setCOM(0);
    this.setWinBatch(0);
    this.setStandard(1);
    this.setMinimized(0);
    this.setMaximized(0);
    this.setJObjDefault(1);
    this.setJObjYes(0);
    this.setJObjYes(0);
    this.setLogOn(0);
    this.setShowJob(0);
    this.setWorkingDirectory("");
    this.setCommand("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSWindowsAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSWindowsAttribute.
   * @see JOBSWindowsAttributeFactory
   */
  public JOBSWindowsAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for IsGenerated.
   *
   * @param IsGenerated the IsGenerated value to set
   */
  public void setIsGenerated(Integer isGenerated)
  {
    properties.setProperty("IsGenerated", isGenerated.toString());
  }

  /**
   * Standard getter for IsGenerated.
   *
   * @return the IsGenerated
   * @returns the IsGenerated value
   */
  public Integer getIsGenerated()
  {
    return Integer.parseInt(properties.getProperty("IsGenerated"));
  }

  /**
   * Standard setter for BAT.
   *
   * @param BAT the BAT value to set
   */
  public void setBAT(Integer bAT)
  {
    properties.setProperty("BAT", bAT.toString());
  }

  /**
   * Standard getter for BAT.
   *
   * @return the BAT
   * @returns the BAT value
   */
  public Integer getBAT()
  {
    return Integer.parseInt(properties.getProperty("BAT"));
  }

  /**
   * Standard setter for COM.
   *
   * @param COM the COM value to set
   */
  public void setCOM(Integer com)
  {
    properties.setProperty("COM", com.toString());
  }

  /**
   * Standard getter for COM.
   *
   * @return the COM
   * @returns the COM value
   */
  public Integer getCOM()
  {
    return Integer.parseInt(properties.getProperty("COM"));
  }

  /**
   * Standard setter for WinBatch.
   *
   * @param WinBatch the WinBatch value to set
   */
  public void setWinBatch(Integer winBatch)
  {
    properties.setProperty("WinBatch", winBatch.toString());
  }

  /**
   * Standard getter for WinBatch.
   *
   * @return the WinBatch
   * @returns the WinBatch value
   */
  public Integer getWinBatch()
  {
    return Integer.parseInt(properties.getProperty("WinBatch"));
  }

  /**
   * Standard setter for Standard.
   *
   * @param Standard the Standard value to set
   */
  public void setStandard(Integer standard)
  {
    properties.setProperty("Standard", standard.toString());
  }

  /**
   * Standard getter for Standard.
   *
   * @return the Standard
   * @returns the Standard value
   */
  public Integer getStandard()
  {
    return Integer.parseInt(properties.getProperty("Standard"));
  }

  /**
   * Standard setter for Minimized.
   *
   * @param Minimized the Minimized value to set
   */
  public void setMinimized(Integer minimized)
  {
    properties.setProperty("Minimized", minimized.toString());
  }

  /**
   * Standard getter for Minimized.
   *
   * @return the Minimized
   * @returns the Minimized value
   */
  public Integer getMinimized()
  {
    return Integer.parseInt(properties.getProperty("Minimized"));
  }

  /**
   * Standard setter for Maximized.
   *
   * @param Maximized the Maximized value to set
   */
  public void setMaximized(Integer maximized)
  {
    properties.setProperty("Maximized", maximized.toString());
  }

  /**
   * Standard getter for Maximized.
   *
   * @return the Maximized
   * @returns the Maximized value
   */
  public Integer getMaximized()
  {
    return Integer.parseInt(properties.getProperty("Maximized"));
  }

  /**
   * Standard setter for JObjDefault.
   *
   * @param JObjDefault the JObjDefault value to set
   */
  public void setJObjDefault(Integer jObjDefault)
  {
    properties.setProperty("JObjDefault", jObjDefault.toString());
  }

  /**
   * Standard getter for JObjDefault.
   *
   * @return the JObjDefault
   * @returns the JObjDefault value
   */
  public Integer getJObjDefault()
  {
    return Integer.parseInt(properties.getProperty("JObjDefault"));
  }

  /**
   * Standard setter for JObjYes.
   *
   * @param JObjYes the JObjYes value to set
   */
  public void setJObjYes(Integer jObjYes)
  {
    properties.setProperty("JObjYes", jObjYes.toString());
  }

  /**
   * Standard getter for JObjYes.
   *
   * @return the JObjYes
   * @returns the JObjYes value
   */
  public Integer getJObjYes()
  {
    return Integer.parseInt(properties.getProperty("JObjYes"));
  }

  /**
   * Standard setter for JObjNo.
   *
   * @param JObjNo the JObjNo value to set
   */
  public void setJObjNo(Integer jObjNo)
  {
    properties.setProperty("JObjNo", jObjNo.toString());
  }

  /**
   * Standard getter for JObjNo.
   *
   * @return the JObjNo
   * @returns the JObjNo value
   */
  public Integer getJObjNo()
  {
    return Integer.parseInt(properties.getProperty("JObjNo"));
  }

  /**
   * Standard setter for LogOn.
   *
   * @param LogOn the LogOn value to set
   */
  public void setLogOn(Integer logOn)
  {
    properties.setProperty("LogOn", logOn.toString());
  }

  /**
   * Standard getter for LogOn.
   *
   * @return the LogOn
   * @returns the LogOn value
   */
  public Integer getLogOn()
  {
    return Integer.parseInt(properties.getProperty("LogOn"));
  }

  /**
   * Standard setter for ShowJob.
   *
   * @param ShowJob the ShowJob value to set
   */
  public void setShowJob(Integer showJob)
  {
    properties.setProperty("ShowJob", showJob.toString());
  }

  /**
   * Standard getter for ShowJob.
   *
   * @return the ShowJob
   * @returns the ShowJob value
   */
  public Integer getShowJob()
  {
    return Integer.parseInt(properties.getProperty("ShowJob"));
  }

  /**
   * Standard setter for WorkingDirectory.
   *
   * @param WorkingDirectory the WorkingDirectory value to set
   */
  public void setWorkingDirectory(String workingDirectory)
  {
    properties.setProperty("WorkingDirectory", workingDirectory);
  }

  /**
   * Standard getter for WorkingDirectory.
   *
   * @return the WorkingDirectory
   * @returns the WorkingDirectory value
   */
  public String getWorkingDirectory()
  {
    return properties.getProperty("WorkingDirectory");
  }

  /**
   * Standard setter for Command.
   *
   * @param Command the Command value to set
   */
  public void setCommand(String command)
  {
    properties.setProperty("Command", command);
  }

  /**
   * Standard getter for Command.
   *
   * @return the Command
   * @returns the Command value
   */
  public String getCommand()
  {
    return properties.getProperty("Command");
  }
}
