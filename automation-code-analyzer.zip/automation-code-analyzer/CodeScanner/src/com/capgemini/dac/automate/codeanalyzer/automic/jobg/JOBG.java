/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobg;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;

/**
 * This class represents an Automic JOBG object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBG extends AutomicExecutableObject
{

  private JOBGAttribute jobgAttributes;
  private AutomicScript mainJOBGScript;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBG object in the context of an editor or in a code translator.
   */
  public JOBG()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBGFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBG.
   * @see JOBGFactory
   */
  public JOBG(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for mainScript
   *
   * @return the mainScript value
   */
  public void setScript(AutomicScript jobg)
  {
    this.mainJOBGScript = jobg;
  }

  /**
   * Standard setter for mainScript
   *
   * @param mainScript the mainScript value to set
   */
  public AutomicScript getScript()
  {
    return this.mainJOBGScript;
  }

  /**
   * Standard getter for JOBGAttribute
   *
   * @return the JOBGAttribute value
   */
  public void setJOBGAttributes(JOBGAttribute jobgAttributes)
  {
    this.jobgAttributes = jobgAttributes;
  }

  /**
   * Standard setter for JOBGAttribute
   *
   * @param JOBGAttribute the JOBGAttribute value to set
   */
  public JOBGAttribute getJOBGAttributes()
  {
    return this.jobgAttributes;
  }

}
