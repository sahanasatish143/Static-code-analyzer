/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * Represents a automic script block declaration in an Automic executable
 * object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class AutomicScript
{
  private Properties properties;

  /**
   * Constructor to build a default AutomicScript object.
   */
  public AutomicScript()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setMode(1);
    this.setReplacementmode(1);
    this.setBody("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the
   * AutomicScriptFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public AutomicScript(Properties properties)
  {
    this.properties = new Properties();
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard getter for mode.
   *
   * @return the mode
   */
  public Integer getMode()
  {
    return Integer.parseInt(properties.getProperty("mode"));
  }

  /**
   * Standard setter for mode
   *
   * @param mode the mode to set
   */
  public void setMode(Integer mode)
  {
    properties.setProperty("mode", mode.toString());
  }

  /**
   * Standard getter for replacementmode.
   *
   * @return the replacementmode
   */
  public Integer getReplacementmode()
  {
    return Integer.parseInt(properties.getProperty("replacementmode"));
  }

  /**
   * Standard setter for replacementmode
   *
   * @param replacementmode the replacementmode to set
   */
  public void setReplacementmode(Integer replacementmode)
  {
    properties.setProperty("replacementmode", replacementmode.toString());
  }

  /**
   * Standard getter for body.
   *
   * @return the body
   */
  public String getBody()
  {
    return properties.getProperty("body");
  }

  /**
   * Standard setter for body
   *
   * @param body the body to set
   */
  public void setBody(String body)
  {
    properties.setProperty("body", body);
  }
}