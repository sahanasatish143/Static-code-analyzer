package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface TabsFactory
{
  public Tabs getDefaultTabs();
  public Tabs parseTabsFromSource();
}
