package com.capgemini.dac.automate.codeanalyzer.uipath.core;

public interface WorkflowViewStateServiceFactory
{
  public WorkflowViewStateService getDefaultWorkflowViewStateService();

  public WorkflowViewStateService parseWorkflowViewStateServiceFromSource();
}
