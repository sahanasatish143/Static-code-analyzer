package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

public interface JobQFilterFactory
{
public JobQFilter getDefaultJobQFilter();
  
  
  public JobQFilter parseJobQFilterFromSource();
}
