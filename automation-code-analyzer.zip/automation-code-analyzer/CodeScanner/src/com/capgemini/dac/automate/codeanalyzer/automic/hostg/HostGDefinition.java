/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.hostg;

import java.util.Properties;

/**
 * The Class HostGDefinition. this classs hasparses the tags specific to HOSTG
 * object also under which we have memebrs as nested tag
 * 
 * @author sahana s
 * @version 1.0
 * @since 1.0
 */
public class HostGDefinition 
{
  /** The properties. */
  Properties properties;
 
  /**
   * Constructor to build a default hostg object.
   */
  public HostGDefinition()
  {
    this.properties = new Properties();


  }

  /**
   * Instantiates a new HostG attribute. Constructor meant to be used by a factory
   * adhering to the HostDefinitionFactory interface.
   * 
   * @param properties the properties
   */
  public HostGDefinition(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for HostAttrType
   *
   * @param HostGs the new HostAttrType
   */
  public void setHostAttrType(String hostAttrType)
  {
    properties.setProperty("HostAttrType", hostAttrType);
  }

  /**
   * Standard getter for HostGs.
   *
   * @return the HostGs value
   */
  public String getHostAttrType()
  {
    return properties.getProperty("HostAttrType");
  }

  /**
   * Standard setter for CITName.
   *
   * @param CITName the new CITName
   */
  public void setCITName(String citName)
  {
    properties.setProperty("CITName", citName);
  }

  /**
   * Standard getter for CITName.
   *
   * @return the CITName value
   */
  public String getCITName()
  {
    return properties.getProperty("CITName");
  }

  /**
   * Standard setter for ModeA.
   *
   * @param ModeA the new ModeA
   */
  public void setModeA(Integer modeA)
  {
    properties.setProperty("ModeA", modeA.toString());
  }

  /**
   * Standard getter for ModeA.
   *
   * @return the ModeA value
   */
  public String getModeA()
  {
    return properties.getProperty("ModeA");
  }

  /**
   * Standard setter for ModeF.
   *
   * @param operatorOR the new ModeF
   */
  public void setModeF(Integer modeF)
  {
    properties.setProperty("ModeF", modeF.toString());
  }

  /**
   * Standard getter for ModeF.
   *
   * @return the ModeF value
   */
  public String getModeF()
  {
    return properties.getProperty("ModeF");
  }

  /**
   * Standard setter for ModeN.
   *
   * @param operatorOR the new ModeN
   */
  public void setModeN(Integer modeN)
  {
    properties.setProperty("ModeN", modeN.toString());
  }

  /**
   * Standard getter for ModeN.
   *
   * @return the ModeN value
   */
  public String getModeN()
  {
    return properties.getProperty("ModeN");
  }

  /**
   * Standard setter for ModeL.
   *
   * @param new ModeL
   */
  public void setModeL(Integer modeL)
  {
    properties.setProperty("ModeL", modeL.toString());
  }

  /**
   * Standard getter for ModeL.
   *
   * @return the ModeL value
   */
  public String getModeL()
  {
    return properties.getProperty("ModeL");
  }

  /**
   * Standard setter for ModeX.
   *
   * @param operatorOR the new ModeX
   */
  public void setModeX(Integer modeX)
  {
    properties.setProperty("ModeX", modeX.toString());
  }

  /**
   * Standard getter for ModeX.
   *
   * @return the ModeX value
   */
  public String getModeX()
  {
    return properties.getProperty("ModeX");
  }

  /**
   * Standard setter for MaxParallel.
   *
   * @param MaxParallel the new MaxParallel
   */
  public void setMaxParallel(Integer maxParallel)
  {
    properties.setProperty("MaxParallel", maxParallel.toString());
  }

  /**
   * Standard getter for MaxParallel.
   *
   * @return the MaxParallel value
   */
  public String getMaxParallel()
  {
    return properties.getProperty("MaxParallel");
  }

  /**
   * Standard setter for Enforced.
   *
   * @param MaxParallel the new Enforced
   */
  public void setEnforced(Integer enforced)
  {
    properties.setProperty("Enforced", enforced.toString());
  }

  /**
   * Standard getter for Enforced.
   *
   * @return the Enforced value
   */
  public String getEnforced()
  {
    return properties.getProperty("Enforced");
  }

  
  public void setMembers(Members parseMembersFromSource)
  {
    properties.getProperty("Members");
  }

}