package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface BindParamsFactory
{
  public BindParams getDefaultBindParams();
  public BindParams parseBindParamsFromSource();
}
