/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.core;

import com.capgemini.dac.automate.codeanalyzer.XMLParser.DACXMLParser;
import com.capgemini.dac.automate.codeanalyzer.XMLParser.automic.AutomicXMLFactoryInitialize;

/**
 * This class represents a Automic Export xml file..
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.0
 */
public class AutomicFile
{
  private String filename;

  /**
   * Default constructor.
   */
  public AutomicFile()
  {
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the AutomicExportFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param filename the full path and name of the file to be processed.
   */
  public AutomicFile(String filename)
  {
    this.setFilename(filename);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the AutomicExportFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @return an AutomicExport object populated with the content of the file.
   */
  public AutomicExport getExportContent()
  {
    AutomicExportFactory exportFactory = AutomicXMLFactoryInitialize.getFactory(new DACXMLParser(filename));
    return exportFactory.parseAutomicExportFromSource();
  }

  /**
   * Standard getter for filename.
   *
   * @return the filename
   */
  public String getFilename()
  {
    return filename;
  }

  /**
   * Standard setter for filename
   *
   * @param filename the filename to set
   */
  public void setFilename(String filename)
  {
    this.filename = filename;
  }
}