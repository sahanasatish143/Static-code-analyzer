/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * Represents a run time declaration in an Automic executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class RunTime
{
  private Properties properties;
  
  /**
   * Constructor to build a default Runtime object.
   */
  public RunTime()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setMaxRetCode(0);
    this.setMrcExecute("");
    this.setMrcElseE(1);
    this.setFcstStatus("1900|ENDED_OK - ended normally");
    this.setErt(0);
    this.setErtMethodDef(1);
    this.setErtMethodFix(0);
    this.setErtFix(0);
    this.setErtDynMethod("2|Average");
    this.setErtMethodDyn(0);
    this.setErtCnt(0);
    this.setErtCorr(0);
    this.setErtIgn(0);
    this.setErtIgnFlg(0);
    this.setErtMinCnt(0);
    this.setMrtMethodNone(0);
    this.setMrtMethodFix(0);
    this.setMrtFix(0);
    this.setMrtMethodErt(0);
    this.setMrtErt(0);
    this.setMrtMethodDate(1);
    this.setMrtDays(1);
    this.setMrtTime("00:00");
    this.setMrtTZ("CST");
    this.setSrtMethodNone(0);
    this.setSrtMethodFix(0);
    this.setSrtFix(0);
    this.setSrtMethodErt(1);
    this.setSrtErt(10);
    this.setMrtCancel(1);
    this.setMrtExecute(1);
    this.setMrtExecuteObj("");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public RunTime(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for MaxRetCode
   *
   * @param maxRetCode the MaxRetCode value to set
   */
  public void setMaxRetCode(Integer maxRetCode)
  {
    properties.setProperty("MaxRetCode", maxRetCode.toString());
  }

  /**
   * Standard getter for MaxRetCode
   *
   * @return the MaxRetCode value
   */
  public Integer MaxRetCode()
  {
    return Integer.parseInt(properties.getProperty("MaxRetCode"));
  }

  /**
   * Standard setter for MrcExecute
   *
   * @param MrcExecute the MrcExecute value to set
   */
  public void setMrcExecute(String MrcExecute)
  {
    properties.setProperty("MrcExecute", MrcExecute.toString());
  }

  /**
   * Standard getter for MrcExecute
   *
   * @return the MrcExecute value
   */
  public String getMrcExecute()
  {
    return properties.getProperty("MrcExecute");
  }

  /**
   * Standard setter for MrcElseE
   *
   * @param mrcElseE the MrcElseE value to set
   */
  public void setMrcElseE(Integer mrcElseE)
  {
    properties.setProperty("MrcElseE", mrcElseE.toString());
  }

  /**
   * Standard getter for MrcElseE
   *
   * @return the MrcElseE value
   */
  public Integer MrcElseE()
  {
    return Integer.parseInt(properties.getProperty("MrcElseE"));
  }

  /**
   * Standard setter for FcstStatus
   *
   * @param fcstStatus the FcstStatus value to set
   */
  public void setFcstStatus(String fcstStatus)
  {
    properties.setProperty("FcstStatus", fcstStatus);
  }

  /**
   * Standard getter for FcstStatus
   *
   * @return the FcstStatus value
   */
  public String FcstStatus()
  {
    return properties.getProperty("FcstStatus");
  }

  /**
   * Standard setter for Ert
   *
   * @param ert the Ert value to set
   */
  public void setErt(Integer ert)
  {
    properties.setProperty("Ert", ert.toString());
  }

  /**
   * Standard getter for Ert
   *
   * @return the Ert value
   */
  public Integer Ert()
  {
    return Integer.parseInt(properties.getProperty("Ert"));
  }

  /**
   * Standard setter for ErtMethodDef
   *
   * @param ertMethodDef the ErtMethodDef value to set
   */
  public void setErtMethodDef(Integer ertMethodDef)
  {
    properties.setProperty("ErtMethodDef", ertMethodDef.toString());
  }

  /**
   * Standard getter for ErtMethodDef
   *
   * @return the ErtMethodDef value
   */
  public Integer ErtMethodDef()
  {
    return Integer.parseInt(properties.getProperty("ErtMethodDef"));
  }

  /**
   * Standard setter for ErtMethodFix
   *
   * @param ertMethodFix the ErtMethodFix value to set
   */
  public void setErtMethodFix(Integer ertMethodFix)
  {
    properties.setProperty("ErtMethodFix", ertMethodFix.toString());
  }

  /**
   * Standard getter for ErtMethodFix
   *
   * @return the ErtMethodFix value
   */
  public Integer ErtMethodFix()
  {
    return Integer.parseInt(properties.getProperty("ErtMethodFix"));
  }

  /**
   * Standard setter for ErtMethodDyn
   *
   * @param ertMethodDyn the ErtMethodDyn value to set
   */
  public void setErtMethodDyn(Integer ertMethodDyn)
  {
    properties.setProperty("ErtMethodDyn", ertMethodDyn.toString());
  }

  /**
   * Standard getter for ErtMethodDyn
   *
   * @return the ErtMethodDyn value
   */
  public Integer ErtMethodDyn()
  {
    return Integer.parseInt(properties.getProperty("ErtMethodDyn"));
  }

  /**
   * Standard setter for ErtFix
   *
   * @param ertFix the ErtFix value to set
   */
  public void setErtFix(Integer ertFix)
  {
    properties.setProperty("ErtFix", ertFix.toString());
  }

  /**
   * Standard getter for ErtFix
   *
   * @return the ErtFix value
   */
  public Integer ErtFix()
  {
    return Integer.parseInt(properties.getProperty("ErtFix"));
  }

  /**
   * Standard setter for ErtDynMethod
   *
   * @param ertDynMethod the ErtDynMethod value to set
   */
  public void setErtDynMethod(String ertDynMethod)
  {
    properties.setProperty("ErtDynMethod", ertDynMethod);
  }

  /**
   * Standard getter for ErtDynMethod
   *
   * @return the ErtDynMethod value
   */
  public String ErtDynMethod()
  {
    return properties.getProperty("ErtDynMethod");
  }

  /**
   * Standard setter for ErtCnt
   *
   * @param ertCnt the ErtCnt value to set
   */
  public void setErtCnt(Integer ertCnt)
  {
    properties.setProperty("ErtCnt", ertCnt.toString());
  }

  /**
   * Standard getter for ErtCnt
   *
   * @return the ErtCnt value
   */
  public Integer ErtCnt()
  {
    return Integer.parseInt(properties.getProperty("ErtCnt"));
  }

  /**
   * Standard setter for ErtCorr
   *
   * @param ertCorr the ErtCorr value to set
   */
  public void setErtCorr(Integer ertCorr)
  {
    properties.setProperty("ErtCorr", ertCorr.toString());
  }

  /**
   * Standard getter for ErtCorr
   *
   * @return the ErtCorr value
   */
  public Integer ErtCorr()
  {
    return Integer.parseInt(properties.getProperty("ErtCorr"));
  }

  /**
   * Standard setter for ErtIgn
   *
   * @param ertIgn the ErtIgn value to set
   */
  public void setErtIgn(Integer ertIgn)
  {
    properties.setProperty("ErtIgn", ertIgn.toString());
  }

  /**
   * Standard getter for ErtIgn
   *
   * @return the ErtIgn value
   */
  public Integer ErtIgn()
  {
    return Integer.parseInt(properties.getProperty("ErtIgn"));
  }

  /**
   * Standard setter for ErtIgnFlg
   *
   * @param ertIgnFlg the ErtIgnFlg value to set
   */
  public void setErtIgnFlg(Integer ertIgnFlg)
  {
    properties.setProperty("ErtIgnFlg", ertIgnFlg.toString());
  }

  /**
   * Standard getter for ErtIgnFlg
   *
   * @return the ErtIgnFlg value
   */
  public Integer ErtIgnFlg()
  {
    return Integer.parseInt(properties.getProperty("ErtIgnFlg"));
  }

  /**
   * Standard setter for ErtMinCnt
   *
   * @param ertMinCnt the ErtMinCnt value to set
   */
  public void setErtMinCnt(Integer ertMinCnt)
  {
    properties.setProperty("ErtMinCnt", ertMinCnt.toString());
  }

  /**
   * Standard getter for ErtMinCnt
   *
   * @return the ErtMinCnt value
   */
  public Integer ErtMinCnt()
  {
    return Integer.parseInt(properties.getProperty("ErtMinCnt"));
  }

  /**
   * Standard setter for MrtMethodNone
   *
   * @param mrtMethodNone the MrtMethodNone value to set
   */
  public void setMrtMethodNone(Integer mrtMethodNone)
  {
    properties.setProperty("MrtMethodNone", mrtMethodNone.toString());
  }

  /**
   * Standard getter for MrtMethodNone
   *
   * @return the MrtMethodNone value
   */
  public Integer MrtMethodNone()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodNone"));
  }

  /**
   * Standard setter for MrtMethodFix
   *
   * @param mrtMethodFix the MrtMethodFix value to set
   */
  public void setMrtMethodFix(Integer mrtMethodFix)
  {
    properties.setProperty("MrtMethodFix", mrtMethodFix.toString());
  }

  /**
   * Standard getter for MrtMethodFix
   *
   * @return the MrtMethodFix value
   */
  public Integer MrtMethodFix()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodFix"));
  }

  /**
   * Standard setter for MrtFix
   *
   * @param mrtFix the MrtFix value to set
   */
  public void setMrtFix(Integer mrtFix)
  {
    properties.setProperty("MrtFix", mrtFix.toString());
  }

  /**
   * Standard getter for MrtFix
   *
   * @return the MrtFix value
   */
  public Integer MrtFix()
  {
    return Integer.parseInt(properties.getProperty("MrtFix"));
  }

  /**
   * Standard setter for MrtMethodDate
   *
   * @param mrtMethodDate the MrtMethodDate value to set
   */
  public void setMrtMethodDate(Integer mrtMethodDate)
  {
    properties.setProperty("MrtMethodDate", mrtMethodDate.toString());
  }

  /**
   * Standard getter for MrtMethodDate
   *
   * @return the MrtMethodDate value
   */
  public Integer MrtMethodDate()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodDate"));
  }

  /**
   * Standard setter for MrtMethodErt
   *
   * @param mrtMethodErt the MrtMethodErt value to set
   */
  public void setMrtMethodErt(Integer mrtMethodErt)
  {
    properties.setProperty("MrtMethodErt", mrtMethodErt.toString());
  }

  /**
   * Standard getter for MrtMethodErt
   *
   * @return the MrtMethodErt value
   */
  public Integer MrtMethodErt()
  {
    return Integer.parseInt(properties.getProperty("MrtMethodErt"));
  }

  /**
   * Standard setter for MrtErt
   *
   * @param mrtErt the MrtErt value to set
   */
  public void setMrtErt(Integer mrtErt)
  {
    properties.setProperty("MrtErt", mrtErt.toString());
  }

  /**
   * Standard getter for MrtErt
   *
   * @return the MrtErt value
   */
  public Integer MrtErt()
  {
    return Integer.parseInt(properties.getProperty("MrtErt"));
  }

  /**
   * Standard setter for MrtDays
   *
   * @param mrtDays the MrtDays value to set
   */
  public void setMrtDays(Integer mrtDays)
  {
    properties.setProperty("MrtDays", mrtDays.toString());
  }

  /**
   * Standard getter for MrtDays
   *
   * @return the MrtDays value
   */
  public Integer MrtDays()
  {
    return Integer.parseInt(properties.getProperty("MrtDays"));
  }

  /**
   * Standard setter for MrtTime
   *
   * @param mrtTime the MrtTime value to set
   */
  public void setMrtTime(String mrtTime)
  {
    properties.setProperty("MrtTime", mrtTime);
  }

  /**
   * Standard getter for MrtTime
   *
   * @return the MrtTime value
   */
  public String MrtTime()
  {
    return properties.getProperty("MrtTime");
  }

  /**
   * Standard setter for MrtTZ
   *
   * @param mrtTZ the MrtTZ value to set
   */
  public void setMrtTZ(String mrtTZ)
  {
    properties.setProperty("MrtTZ", mrtTZ);
  }

  /**
   * Standard getter for MrtTZ
   *
   * @return the MrtTZ value
   */
  public String MrtTZ()
  {
    return properties.getProperty("MrtTZ");
  }

  /**
   * Standard setter for SrtMethodNone
   *
   * @param srtMethodNone the SrtMethodNone value to set
   */
  public void setSrtMethodNone(Integer srtMethodNone)
  {
    properties.setProperty("SrtMethodNone", srtMethodNone.toString());
  }

  /**
   * Standard getter for SrtMethodNone
   *
   * @return the SrtMethodNone value
   */
  public Integer SrtMethodNone()
  {
    return Integer.parseInt(properties.getProperty("SrtMethodNone"));
  }

  /**
   * Standard setter for SrtMethodFix
   *
   * @param srtMethodFix the SrtMethodFix value to set
   */
  public void setSrtMethodFix(Integer srtMethodFix)
  {
    properties.setProperty("SrtMethodFix", srtMethodFix.toString());
  }

  /**
   * Standard getter for SrtMethodFix
   *
   * @return the SrtMethodFix value
   */
  public Integer SrtMethodFix()
  {
    return Integer.parseInt(properties.getProperty("SrtMethodFix"));
  }

  /**
   * Standard setter for SrtFix
   *
   * @param srtFix the SrtFix value to set
   */
  public void setSrtFix(Integer srtFix)
  {
    properties.setProperty("SrtFix", srtFix.toString());
  }

  /**
   * Standard getter for SrtFix
   *
   * @return the SrtFix value
   */
  public Integer SrtFix()
  {
    return Integer.parseInt(properties.getProperty("SrtFix"));
  }

  /**
   * Standard setter for SrtMethodErt
   *
   * @param srtMethodErt the SrtMethodErt value to set
   */
  public void setSrtMethodErt(Integer srtMethodErt)
  {
    properties.setProperty("SrtMethodErt", srtMethodErt.toString());
  }

  /**
   * Standard getter for SrtMethodErt
   *
   * @return the SrtMethodErt value
   */
  public Integer SrtMethodErt()
  {
    return Integer.parseInt(properties.getProperty("SrtMethodErt"));
  }

  /**
   * Standard setter for SrtErt
   *
   * @param srtErt the SrtErt value to set
   */
  public void setSrtErt(Integer srtErt)
  {
    properties.setProperty("SrtErt", srtErt.toString());
  }

  /**
   * Standard getter for SrtErt
   *
   * @return the SrtErt value
   */
  public Integer SrtErt()
  {
    return Integer.parseInt(properties.getProperty("SrtErt"));
  }

  /**
   * Standard setter for MrtCancel
   *
   * @param mrtCancel the MrtCancel value to set
   */
  public void setMrtCancel(Integer mrtCancel)
  {
    properties.setProperty("MrtCancel", mrtCancel.toString());
  }

  /**
   * Standard getter for MrtCancel
   *
   * @return the MrtCancel value
   */
  public Integer MrtCancel()
  {
    return Integer.parseInt(properties.getProperty("MrtCancel"));
  }

  /**
   * Standard setter for MrtExecute
   *
   * @param mrtExecute the MrtExecute value to set
   */
  public void setMrtExecute(Integer mrtExecute)
  {
    properties.setProperty("MrtExecute", mrtExecute.toString());
  }

  /**
   * Standard getter for MrtExecute
   *
   * @return the MrtExecute value
   */
  public Integer MrtExecute()
  {
    return Integer.parseInt(properties.getProperty("MrtExecute"));
  }

  /**
   * Standard setter for MrtExecuteObj
   *
   * @param mrtExecuteObj the MrtExecuteObj value to set
   */
  public void setMrtExecuteObj(String mrtExecuteObj)
  {
    properties.setProperty("MrtExecuteObj", mrtExecuteObj);
  }

  /**
   * Standard getter for MrtExecuteObj
   *
   * @return the MrtExecuteObj value
   */
  public String MrtExecuteObj()
  {
    return properties.getProperty("MrtExecuteObj");
  }
}