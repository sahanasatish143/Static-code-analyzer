package com.capgemini.dac.automate.codeanalyzer.automic.login;

public interface LoginsRowsFactory
{
  public LoginRows getDefaultLoginsRows();

  /**
   * Parses the LOGIN definition from source.
   *
   * @return the LOGIN definition
   */
  public LoginRows parseLoginsRowsFromSource();
}
