package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

import java.util.Properties;

public class JobQDefinition 

{
  Properties properties;
  public JobQDefinition()
  {
    this.properties = new Properties();
    
    this.setState(1);
//    
  }
  public JobQDefinition(Properties properties)
  {
    this.properties = properties;
   
  }
  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  
  public void setQmFilters(JobQFilter parseMembersFromSource)
  {
    properties.getProperty("QmFilters");
  }

}
