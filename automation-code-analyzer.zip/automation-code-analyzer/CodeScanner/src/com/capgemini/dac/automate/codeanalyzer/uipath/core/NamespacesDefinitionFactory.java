package com.capgemini.dac.automate.codeanalyzer.uipath.core;

public interface NamespacesDefinitionFactory
{
  public NamespacesDefinition getDefaultNamespacesDefinition();

  public NamespacesDefinition parseNamespacesDefinitionFromSource();
}
