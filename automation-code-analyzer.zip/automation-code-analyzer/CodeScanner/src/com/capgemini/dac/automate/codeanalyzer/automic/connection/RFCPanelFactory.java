package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface RFCPanelFactory
{
  public RFCPanel getDefaultRFCPanel();
  public RFCPanel parseRFCPanelFromSource();
}
