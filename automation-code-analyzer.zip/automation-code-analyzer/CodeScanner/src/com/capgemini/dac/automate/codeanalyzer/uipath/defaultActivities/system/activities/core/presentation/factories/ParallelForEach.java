/*
* Copyright (c) 2019-20, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.core.presentation.factories;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.uipath.core.ActivityAction;
import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathObject;
import com.capgemini.dac.automate.codeanalyzer.uipath.core.WorkflowViewStateService;

/**
 * This class represents an UiPath ParallelForEach Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class ParallelForEach extends UiPathObject
{
  private ActivityAction activityAction;;
  private WorkflowViewStateService workFlowViewState;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * ParallelForEach Activity in the context of an editor or in a code translator.
   */
  public ParallelForEach()
  {
    this.properties = new Properties();
    workFlowViewState = new WorkflowViewStateService();
    activityAction = new ActivityAction();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the ParallelForEachFactory interface. All children objects ,inherited from
   * UiPathObject, will be null and are expected to be injected through setters by
   * the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   *                   properties for ParallelForEach.
   * @see ParallelForEachFactory
   */

  public ParallelForEach(Properties properties)
  {
    this.setProperties(properties);
    workFlowViewState = new WorkflowViewStateService();
    activityAction = new ActivityAction();
  }

  /**
   * Standard setter for WorkflowViewStateService
   *
   * @param sequence the WorkflowViewStateService value to set
   */
  public void setWorkflowViewStateService(WorkflowViewStateService sequence)
  {
    this.workFlowViewState = sequence;
  }

  /**
   * Standard getter for WorkflowViewStateService
   *
   * @return the WorkflowViewStateService value
   */
  public WorkflowViewStateService getWorkflowViewStateService()
  {
    return this.workFlowViewState;
  }

  /**
   * Standard setter for ActivityAction
   *
   * @param action the ActivityAction value to set
   */
  public void setActivityAction(ActivityAction action)
  {
    this.activityAction = action;
  }

  /**
   * Standard getter for ActivityAction
   *
   * @return the ActivityAction value
   */
  public ActivityAction getActivityAction()
  {
    return this.activityAction;
  }
}