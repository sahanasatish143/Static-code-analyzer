package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VaraTab
{
  Properties properties;
  public VaraTab()
  {
    this.properties = new Properties();
    this.setHostAttrType("");
    this.setLnr(1);
    this.setIdnr(2227);
    this.setName("");
    this.setType("");
  }
  public VaraTab(Properties properties)
  {
    this.properties = properties;
  }
  public void setHostAttrType(String archiveKey1)
  {
    properties.setProperty("HostAttrType", archiveKey1);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getHostAttrType()
  {
    return properties.getProperty("HostAttrType");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setName(String archiveKey2)
  {
    properties.setProperty("Name", archiveKey2);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getName()
  {
    return properties.getProperty("Name");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setLnr(Integer hw)
  {
    properties.setProperty("Lnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getLnr()
  {
    return properties.getProperty("Lnr");
  }
  public void setIdnr(Integer hw)
  {
    properties.setProperty("Idnr", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getIdnr()
  {
    return properties.getProperty("Idnr");
  }
  
  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public void setType(String icon)
  {
    properties.setProperty("SubType", icon);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getType()
  {
    return properties.getProperty("SubType");
  }

}
