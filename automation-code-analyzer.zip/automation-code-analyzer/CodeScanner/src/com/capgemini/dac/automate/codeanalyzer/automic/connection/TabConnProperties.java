package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

public class TabConnProperties
{
  Properties properties;

  /**
   * Instantiates a new connection attribute.
   */
  public TabConnProperties()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new connection attribute.
   *
   * @param properties the properties
   */
  public TabConnProperties(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Sets the conn check image.
   *
   * @param hostAttrType the new conn check image
   */
  public void setTabConnPropertiesDefinition(Connproperties tabConnProperties)
  {
    properties.getProperty("conn.properties");
  }
}
