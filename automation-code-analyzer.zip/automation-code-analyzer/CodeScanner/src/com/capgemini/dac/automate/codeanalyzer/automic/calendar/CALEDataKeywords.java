/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.calendar;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * This class represents an Automic CALEDataKeywords under CALE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CALEDataKeywords implements Iterable<CALEDataKeyword>
{

  Properties properties;

  private ArrayList<CALEDataKeyword> caleDatakeyword;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CALEDataKeywordsFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CALEDataKeywords.
   * @see CALEDataKeywordsFactory
   */
  public CALEDataKeywords(Properties properties)
  {
    this.properties = properties;
    this.caleDatakeyword = new ArrayList<CALEDataKeyword>();
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CALEDataKeywords under CALE object in the context of an editor or in a code
   * translator.
   */
  public CALEDataKeywords()
  {
    this.properties = new Properties();
    this.setOkb("");
    this.caleDatakeyword = new ArrayList<CALEDataKeyword>();
  }

  /**
   * Adds a CALEDataKeyword to the list.
   *
   * @param the the CALEDataKeyword to add to the collection
   */
  public void add(CALEDataKeyword rows)
  {
    caleDatakeyword.add(rows);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the CALEDataKeyword in the collection
   */
  @Override
  public Iterator<CALEDataKeyword> iterator()
  {
    return caleDatakeyword.iterator();
  }

  /**
   * Standard setter for Okb
   *
   * @param Okb the Okb value to set
   */
  public void setOkb(String okb)
  {
    properties.setProperty("okb", okb);
  }

  /**
   * Standard getter for Okb
   *
   * @return the Okb value
   */
  public String getOkb()
  {
    return properties.getProperty("okb");
  }

}
