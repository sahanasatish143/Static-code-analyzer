/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSCITCont implements Iterable<CITROW>
{
  Properties properties;
  private ArrayList<CITROW> citRows;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSCITCont under JOBS object in the context of an editor or in a code
   * translator.
   */
  public JOBSCITCont()
  {
    this.properties = new Properties();
    this.citRows = new ArrayList<CITROW>();
    this.setAgentname("");
    this.setJobtype("");
    this.setText("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CITROWFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CITROW.
   * @see CITROWFactory
   */
  public JOBSCITCont(Properties properties)
  {
    this.properties = properties;
    this.citRows = new ArrayList<CITROW>();
  }

  /**
   * Adds a CITROW to the list.
   *
   * @param the the CITROW to add to the collection
   */
  public void add(CITROW rows)
  {
    citRows.add(rows);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the CITROW in the collection
   */
  @Override
  public Iterator<CITROW> iterator()
  {
    return citRows.iterator();
  }

  /**
   * Standard setter for Agentname.
   *
   * @param Agentname the Agentname value to set
   */
  public void setAgentname(String agentname)
  {
    properties.setProperty("Agentname", agentname);
  }

  /**
   * Standard getter for Agentname.
   *
   * @return the Agentname
   * @returns the Agentname value
   */
  public String getAgentname()
  {
    return properties.getProperty("Agentname");
  }

  /**
   * Standard setter for Jobtype.
   *
   * @param Jobtype the Jobtype value to set
   */
  public void setJobtype(String jobtype)
  {
    properties.setProperty("Jobtype", jobtype);
  }

  /**
   * Standard getter for Jobtype.
   *
   * @return the Jobtype
   * @returns the Jobtype value
   */
  public String getJobtype()
  {
    return properties.getProperty("Jobtype");
  }

  /**
   * Standard setter for Text.
   *
   * @param Text the Text value to set
   */
  public void setText(String text)
  {
    properties.setProperty("Text", text);
  }

  /**
   * Standard getter for Text.
   *
   * @return the Text
   * @returns the Text value
   */
  public String getText()
  {
    return properties.getProperty("HostDst");
  }
}
