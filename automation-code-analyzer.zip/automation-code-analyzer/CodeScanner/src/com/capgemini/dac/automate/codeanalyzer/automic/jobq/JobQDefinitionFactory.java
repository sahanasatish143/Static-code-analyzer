package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

public interface JobQDefinitionFactory
{
public JobQDefinition getDefaultJobQDefinition();
  
  
  public JobQDefinition parseJobQDefinitionFromSource();
}
