/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * The Class CitDefinition.
 */
public class CitDefinition implements Iterable<Component>
{
  /** The properties. */
  Properties properties;
  
  /** The comp. */
  private ArrayList<Component> comp;

  /**
   * Instantiates a new citcont.
   */
  public CitDefinition()
  {
    this.properties = new Properties();
    this.comp = new ArrayList<Component>();
  }

  /**
   * Instantiates a new citcont.
   *
   * @param properties the properties
   */
  public CitDefinition(Properties properties)
  {
    this.properties = properties;
    this.comp = new ArrayList<Component>();
  }

  /**
   * Sets the cittype.
   *
   * @param cittype the new cittype
   */
  public void setCittype(String cittype)
  {
    properties.setProperty("cittype", cittype);
  }

  /**
   * Gets the agent name.
   *
   * @return the agent name
   */
  public String getCittype()
  {
    return properties.getProperty("cittype");
  }

  /**
   * Sets the icon.
   *
   * @param icon the new icon
   */
  public void setIcon(String icon)
  {
    properties.setProperty("icon", icon);
  }

  /**
   * Gets the icon.
   *
   * @return the icon
   */
  public String getIcon()
  {
    return properties.getProperty("icon");
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id)
  {
    properties.setProperty("id", id);
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId()
  {
    return properties.getProperty("id");
  }

  /**
   * Sets the subtype.
   *
   * @param subtype the new subtype
   */
  public void setSubtype(String subtype)
  {
    properties.setProperty("subtype", subtype);
  }

  /**
   * Gets the subtype.
   *
   * @return the subtype
   */
  public String getSubtype()
  {
    return properties.getProperty("subtype");
  }

  /**
   * Sets the text.
   *
   * @param text the new text
   */
  public void setText(String text)
  {
    properties.setProperty("Text", text);
  }

  /**
   * Gets the text.
   *
   * @return the text
   */
  public String getText()
  {
    return properties.getProperty("Text");
  }

  /**
   * Adds the.
   *
   * @param comps the comps
   */
  public void add(Component comps)
  {
    comp.add(comps);
  }

 
  @Override
  public Iterator<Component> iterator()
  {
    return comp.iterator();
  }

}
