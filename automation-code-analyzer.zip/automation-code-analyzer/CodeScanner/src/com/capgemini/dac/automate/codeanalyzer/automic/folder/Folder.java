/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.folder;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class Folder implements FolderItem, Iterable<FolderItem>
{
  Properties properties;
  private List<FolderItem> items;

  public Folder()
  {
    this.properties = new Properties();
    items = new ArrayList<FolderItem>(); 
  }
  
  public Folder(Properties properties)
  {
    this.properties = properties;
    items = new ArrayList<FolderItem>();    
  }
  
  public void add(FolderItem item)
  {
    items.add(item);
  }

  @Override
  public Iterator<FolderItem> iterator()
  {
    return items.iterator();
  }
  
  public void setName(String name)
  {
    properties.setProperty("name", name);
  }
  
  public String getName()
  {
    return properties.getProperty("name");
  }

  public void setTitle(String title)
  {
    properties.setProperty("title", title);
  }
  
  public String getTitle()
  {
    return properties.getProperty("title");
  }
}