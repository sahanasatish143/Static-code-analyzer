/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.analyzer;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicObject;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.0
 */
public class EvaluationRule
{
  String id;
  String title;
  
  public EvaluationRule(String id, String title)
  {
    this.id = id;
    this.title = title;
  }

  public String getID()
  {
    return id;
  }
  
  public RuleEvaluationRecord evaluate(Object object)
  {
    String id = "AA_32";
    AutomicObject ao = (AutomicObject) object;
    String prefix = ao.getName().split("\\.")[0];
    if (ao.getName().matches("^" + id + "(\\.([A-Z0-9_])+)?"))
      return new RuleEvaluationRecord(this, new EvaluationResult("Test Pass Result","AA_32", true), object);
    return new RuleEvaluationRecord(this, new EvaluationResult("Test Fail Result", prefix, false), object);
  }
  
  public String getTitle()
  {
    return title;
  }
}