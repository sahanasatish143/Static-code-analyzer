/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * Represents a dynamic values prompt box element declaration in an Automic
 * executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class DynPromptBoxElement
{
  private Properties properties = null;

  /**
   * Constructor to build a default dynamic prompt box element object.
   */
  public DynPromptBoxElement()
  {
    this.properties = new Properties();
    this.setName("");
    this.setReadFromTable("");
    this.setAltview(0);
    this.setHaslist(0);
    this.setMsginsert("");
    this.setMsgnr("");
    this.setPromptname("");
    this.setPromptsetname("");
    this.setValue("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the
   * DynPromptBoxElementFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public DynPromptBoxElement(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for name
   *
   * @param name the state value to set
   */
  public void setName(String name)
  {
    properties.setProperty("Name", name);
  }

  /**
   * Standard getter for name
   *
   * @returns the name value
   */
  public String getName()
  {
    return properties.getProperty("Name");
  }

  /**
   * Standard setter for ReadFromTable
   *
   * @param ReadFromTable the ReadFromTable value to set
   */
  public void setReadFromTable(String ReadFromTable)
  {
    properties.setProperty("ReadFromTable", ReadFromTable);
  }

  /**
   * Standard getter for ReadFromTable
   *
   * @returns the ReadFromTable value
   */
  public String getReadFromTable()
  {
    return properties.getProperty("ReadFromTable");
  }

  /**
   * Standard setter for altview
   *
   * @param altview the altview value to set
   */
  public void setAltview(Integer altview)
  {
    properties.setProperty("altview", altview.toString());
  }

  /**
   * Standard getter for altview
   *
   * @returns the altview value
   */
  public Integer getAltview()
  {
    return Integer.parseInt(properties.getProperty("altview"));
  }

  /**
   * Standard setter for haslist
   *
   * @param haslist the haslist value to set
   */
  public void setHaslist(Integer haslist)
  {
    properties.setProperty("haslist", haslist.toString());
  }

  /**
   * Standard getter for haslist
   *
   * @returns the haslist value
   */
  public Integer getHaslist()
  {
    return Integer.parseInt(properties.getProperty("haslist"));
  }

  /**
   * Standard setter for msginsert
   *
   * @param msginsert the msginsert value to set
   */
  public void setMsginsert(String msginsert)
  {
    properties.setProperty("msginsert", msginsert);
  }

  /**
   * Standard getter for msginsert
   *
   * @returns the msginsert value
   */
  public String getMsginsert()
  {
    return properties.getProperty("msginsert");
  }

  /**
   * Standard setter for msgnr
   *
   * @param msgnr the msgnr value to set
   */
  public void setMsgnr(String msgnr)
  {
    properties.setProperty("msgnr", msgnr);
  }

  /**
   * Standard getter for msgnr
   *
   * @returns the msgnr value
   */
  public String getMsgnr()
  {
    return properties.getProperty("msgnr");
  }

  /**
   * Standard setter for promptname
   *
   * @param promptname the promptname value to set
   */
  public void setPromptname(String promptname)
  {
    properties.setProperty("promptname", promptname);
  }

  /**
   * Standard getter for promptname
   *
   * @returns the promptname value
   */
  public String getPromptname()
  {
    return properties.getProperty("promptname");
  }

  /**
   * Standard setter for promptsetname
   *
   * @param promptsetname the promptsetname value to set
   */
  public void setPromptsetname(String promptsetname)
  {
    properties.setProperty("promptsetname", promptsetname);
  }

  /**
   * Standard getter for promptsetname
   *
   * @returns the promptsetname value
   */
  public String getPromptsetname()
  {
    return properties.getProperty("promptsetname");
  }

  /**
   * Standard setter for value
   *
   * @param value the value value to set
   */
  public void setValue(String value)
  {
    properties.setProperty("value", value);
  }

  /**
   * Standard getter for value
   *
   * @returns the value value
   */
  public String getValue()
  {
    return properties.getProperty("value");
  }
}