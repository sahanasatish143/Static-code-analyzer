/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * This class represents common base features of an Automic executable object.
 * It encompasses the core executable properties and functionality. This class
 * is not meant to be instantiated directly. It is always meant to be the super
 * class of another instantiated class.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.0
 */
public class AutomicExecutableObject extends AutomicObject
{
  private SyncRef syncref;
  private RunTime runtime;
  private DynValues dynvalues;
  private Rollback rollback;

  /**
   * Default constructor. Meant to be called by a sub-class, not directly.
   */
  protected AutomicExecutableObject()
  {
    super();
  }

  /**
   * This constructor is meant to be called by a sub-class, not directly from a
   * factory class. All children objects ,inherited from AutomicObject, will be
   * null and are expected to be injected through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for object.
   */
  protected AutomicExecutableObject(Properties properties)
  {
    super(properties);
  }

  /**
   * Standard setter for DynValues
   *
   * @param dynvalues the DynValues value to set
   */
  public void setDynValues(DynValues dynvalues)
  {
    this.dynvalues = dynvalues;
  }

  /**
   * Standard getter for DynValues
   *
   * @return a reference to the DynValues section of the object
   */
  public DynValues getDynValues()
  {
    return this.dynvalues;
  }

  /**
   * Standard setter for Rollback
   *
   * @param rollback the Rollback value to set
   */
  public void setRollback(Rollback rollback)
  {
    this.rollback = rollback;
  }

  /**
   * Standard getter for Rollback
   *
   * @return a reference to the Rollback section of the object
   */
  public Rollback getRollback()
  {
    return this.rollback;
  }

  /**
   * Standard setter for RunTime
   *
   * @param runtime the RunTime value to set
   */
  public void setRunTime(RunTime runtime)
  {
    this.runtime = runtime;
  }

  /**
   * Standard getter for RunTime
   *
   * @return a reference to the RunTime section of the object
   */
  public RunTime getRunTime()
  {
    return this.runtime;
  }

  /**
   * Standard setter for SyncRef
   *
   * @param syncref the SyncRef value to set
   */
  public void setSyncRef(SyncRef syncref)
  {
    this.syncref = syncref;
  }

  /**
   * Standard getter for SyncRef
   *
   * @return a reference to the SyncRef section of the object
   */
  public SyncRef getSyncRef()
  {
    return this.syncref;
  }
}