/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

/**
 * The Class Component.
 */
public class Component
{
  
  /** The properties. */
  Properties properties;
  
  /**
   * Instantiates a new component.
   */
  public Component()
  {
    this.properties = new Properties();
    this.setCon(null);
    this.setType(null);
    this.setEnc(null);
    this.setValue("");
    this.setXmlName("");
   }
  
  /**
   * Instantiates a new component.
   *
   * @param properties the properties
   */
  public Component(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Sets the con.
   *
   * @param icon the new con
   */
  public void setCon(String icon)
  {
    properties.setProperty("con", icon);
  }

  /**
   * Gets the con.
   *
   * @return the con
   */
  public String getCon()
  {
    return properties.getProperty("con");
  }
 
 /**
  * Sets the value.
  *
  * @param value the new value
  */
 public void setValue(String value)
  {
    properties.setProperty("value", value);
  }

  /**
   * Gets the value.
   *
   * @return the value
   */
  public String getValue()
  {
    return properties.getProperty("value");
  }

/**
 * Sets the xml name.
 *
 * @param xmlName the new xml name
 */
public void setXmlName(String xmlName)
  {
    properties.setProperty("xmlName", xmlName);
  }

  /**
   * Gets the xml name.
   *
   * @return the xml name
   */
  public String getXmlName()
  {
    return properties.getProperty("xmlName");
  }

  /**
   * Sets the enc.
   *
   * @param enc the new enc
   */
  public void setEnc(String enc)
  {
    properties.setProperty("enc", enc);
  }

  /**
   * Gets the enc.
   *
   * @return the enc
   */
  public String getEnc()
  {
    return properties.getProperty("enc");
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType()
  {
    return properties.getProperty("type");
  }
}
