/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.filter;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class filteroutput is used .
 * to parse only the filter_output related tags
 *  @author sahana s
 * @version 1.0
 * @since 1.0
 */
public class FilterOutput
{
 
 /** The properties. */
 Properties properties;
  
  /**
   * Instantiates a new filter attribute.
   *
   * @param properties the properties
   */
  public FilterOutput(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Instantiates a new filter attribute.
   */
  public FilterOutput()
  {
    this.properties = new Properties();
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }
  
  /**
   * Standard setter for Filters.
   *
   * @param filters the new filters
   */
  public void setFilters(String filters)
  {
    properties.setProperty("Filters", filters);
  }

  /**
   * Standard getter for Filters.
   *
   * @return the Filters value
   */
  public String getFilters()
  {
    return properties.getProperty("Filters");
  }
 
  /**
   * Standard setter for OperatorAND.
   *
   * @param operatorAND the new operator AND
   */
  public void setOperatorAND(String operatorAND)
  {
    properties.setProperty("OperatorAND", operatorAND);
  }

  /**
   * Standard getter for OperatorAND.
   *
   * @return the OperatorAND value
   */
  public String getOperatorAND()
  {
    return properties.getProperty("OperatorAND");
  }

  /**
   * Standard setter for OperatorOR.
   *
   * @param operatorOR the new operator OR
   */
  public void setOperatorOR(String operatorOR)
  {
    properties.setProperty("OperatorOR", operatorOR);
  }

  /**
   * Standard getter for OperatorOR.
   *
   * @return the OperatorOR value
   */
  public String getOperatorOR()
  {
    return properties.getProperty("OperatorOR");
  }

  
}