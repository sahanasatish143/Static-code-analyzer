/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.prompt;

import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class PromptDesigner.
 * this class has only the tags that are
 * used to parse tags only under the Prompt tags of PromptDesigner
 * @author sahana s
 * @version 1.0
 * @since 1.0
 */
public class PromptDesigner
{
  
  /** The properties. */
  private Properties properties;

  /**
   * Instantiates a new prompt designer.
   */
  public PromptDesigner()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setDesigner("");
  }

  /**
   * Instantiates a new prompt designer.
   *
   * @param properties the properties
   */
  public PromptDesigner(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for DESIGNER.
   *
   * @param designer the new designer
   */
  public void setDesigner(String designer)
  {
    properties.setProperty("DESIGNER", designer);
  }

  /**
   * Standard getter for DESIGNER.
   *
   * @return the designer
   * @returns the DESIGNER value
   */
  public String getDesigner()
  {
    return properties.getProperty("DESIGNER");
  }
}
