/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.calendar;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * This class represents an Automic GroupA under CALE object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class GroupA implements Iterable<GroupROW>
{
  Properties properties;
  private ArrayList<GroupROW> groupRows;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the GroupAFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for GroupA.
   * @see GroupAFactory
   */
  public GroupA(Properties properties)
  {
    this.properties = properties;
    this.groupRows = new ArrayList<GroupROW>();
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * GroupA under CALE object in the context of an editor or in a code translator.
   */
  public GroupA()
  {
    this.properties = new Properties();
    this.groupRows = new ArrayList<GroupROW>();

  }

  /**
   * Adds a GroupROW to the list.
   *
   * @param the the GroupROW to add to the collection
   */
  public void add(GroupROW rows)
  {
    groupRows.add(rows);
  }

  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the GroupROW in the collection
   */
  @Override
  public Iterator<GroupROW> iterator()
  {
    return groupRows.iterator();
  }

  /**
   * Standard setter for Flag
   *
   * @param Flag the Flag value to set
   */
  public void setFlag(Integer flag)
  {
    properties.setProperty("flag", flag.toString());
  }

  /**
   * Standard getter for Flag
   *
   * @return the Flag value
   */
  public Integer getFlag()
  {
    return Integer.parseInt(properties.getProperty("flag"));
  }
}
