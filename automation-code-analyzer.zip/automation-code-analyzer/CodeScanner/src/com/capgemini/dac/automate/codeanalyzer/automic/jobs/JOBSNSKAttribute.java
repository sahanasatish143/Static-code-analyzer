/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSNSKAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSNSKAttribute object in the context of an editor or in a code translator.
   */
  public JOBSNSKAttribute()
  {
    this.properties = new Properties();
    this.setPriority(120);
    this.setVhTerm("");
    this.setCpu(0);
    this.setType(0);
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSNSKAttributeFactory interface. All children objects ,inherited
   * from AutomicObject, will be null and are expected to be injected through
   * setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSNSKAttribute.
   * @see JOBSNSKAttributeFactory
   */
  public JOBSNSKAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Cpu.
   *
   * @param Cpu the Cpu value to set
   */
  public void setCpu(Integer cpu)
  {
    properties.setProperty("Cpu", cpu.toString());
  }

  /**
   * Standard getter for Cpu.
   *
   * @return the Cpu
   * @returns the Cpu value
   */
  public Integer getCpu()
  {
    return Integer.parseInt(properties.getProperty("Cpu"));
  }

  /**
   * Standard setter for Priority.
   *
   * @param Priority the Priority value to set
   */
  public void setPriority(Integer priority)
  {
    properties.setProperty("Priority", priority.toString());
  }

  /**
   * Standard getter for Priority.
   *
   * @return the Priority
   * @returns the Priority value
   */
  public Integer getPriority()
  {
    return Integer.parseInt(properties.getProperty("Priority"));
  }

  /**
   * Standard setter for Type.
   *
   * @param Type the Type value to set
   */
  public void setType(Integer type)
  {
    properties.setProperty("Type", type.toString());
  }

  /**
   * Standard getter for Type.
   *
   * @return the Type
   * @returns the Type value
   */
  public Integer getType()
  {
    return Integer.parseInt(properties.getProperty("Type"));
  }

  /**
   * Standard setter for VhTerm.
   *
   * @param VhTerm the VhTerm value to set
   */
  public void setVhTerm(String vhTerm)
  {
    properties.setProperty("VhTerm", vhTerm);
  }

  /**
   * Standard getter for VhTerm.
   *
   * @return the VhTerm
   * @returns the VhTerm value
   */
  public String getVhTerm()
  {
    return properties.getProperty("VhTerm");
  }
}
