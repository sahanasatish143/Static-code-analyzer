package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

public interface JobQAttrFactory
{
public JobQAttr getDefaultJobQAttr();
  
  
  public JobQAttr parseJobQAttrFromSource();
}
