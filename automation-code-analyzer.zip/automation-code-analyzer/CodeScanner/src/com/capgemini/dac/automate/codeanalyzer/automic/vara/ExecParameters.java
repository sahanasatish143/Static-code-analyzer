package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class ExecParameters implements Iterable<VaraParametersRows>
{
  Properties properties;

  /** The rows. */
  private ArrayList<VaraParametersRows> rows;

  public ExecParameters(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<VaraParametersRows>();
  }

  public ExecParameters()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<VaraParametersRows>();
  }

  public void add(VaraParametersRows members)
  {
    rows.add(members);
  }

  @Override
  public Iterator<VaraParametersRows> iterator()
  {
    
    return rows.iterator();
  }

}
