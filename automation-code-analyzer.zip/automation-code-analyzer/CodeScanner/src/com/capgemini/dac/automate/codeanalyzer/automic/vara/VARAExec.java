package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VARAExec
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA backend.
   */
  public VARAExec()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new VARA backend.
   *
   * @param properties the properties
   */
  public VARAExec(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the host dst.
   *
   * @param hostAttrType the new host dst
   */
  public void setExecObject(String hostAttrType)
  {
    properties.setProperty("ExecObject", hostAttrType);
  }

  /**
   * Gets the host dst.
   *
   * @return the host dst
   */
  public String getExecObject()
  {
    return properties.getProperty("ExecObject");
  }

  /**
   * Sets the apply task H.
   *
   * @param applyTaskH the new apply task H
   */
  public void setVaraResult(String applyTaskH)
  {
    properties.setProperty("VaraResult", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getVaraResult()
  {
    return properties.getProperty("VaraResult");
  }

  
  public void setParameters(ExecParameters parseMembersFromSource)
  {
    properties.getProperty("Parameters");
  }
  
}
