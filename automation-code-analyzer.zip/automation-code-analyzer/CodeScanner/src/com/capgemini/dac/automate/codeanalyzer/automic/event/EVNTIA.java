/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

/**
 * This class represents an Automic EVNTIA object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNTIA
{
  Properties properties;
  EVNTIAValues eventIAValues;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVNTIA object in the context of an editor or in a code translator.
   */
  public EVNTIA()
  {
    this.properties = new Properties();

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVNTIAFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVNTIA.
   * @see EVNTIAFactory
   */
  public EVNTIA(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Standard getter for EVNTIAValues
   *
   * @return the EVNTIAValues value
   */
  public EVNTIAValues getEVNTIAValues()
  {
    return eventIAValues;
  }

  /**
   * Standard setter for EVNTIAValues
   *
   * @param EVNTIAValues the EVNTIAValues value to set
   */
  public void setEVNTIAValues(EVNTIAValues eventIAValues)
  {
    this.eventIAValues = eventIAValues;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for HostDst
   *
   * @param HostDst the HostDst value to set
   */
  public void setHostDst(String hostDst)
  {
    properties.setProperty("HostDst", hostDst);
  }

  /**
   * Standard getter for HostDst
   *
   * @return the HostDst value
   */
  public String getHostDst()
  {
    return (properties.getProperty("HostDst"));
  }

  /**
   * Standard setter for STORE
   *
   * @param STORE the STORE value to set
   */
  public void setSTORE(String store)
  {
    properties.setProperty("STORE", store);
  }

  /**
   * Standard getter for STORE
   *
   * @return the STORE value
   */
  public String getSTORE()
  {
    return (properties.getProperty("STORE"));
  }

}
