/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class TaskCalendars
{
  private Properties properties;
  private ArrayList<TaskCalendar> calendars;
 
  /**
   * Constructor to build a default Runtime object.
   */
  public TaskCalendars()
  {
    this.properties = new Properties();
    this.calendars = new ArrayList<TaskCalendar>();
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskCalendars(Properties properties)
  {
    this.properties = properties;
    this.calendars = new ArrayList<TaskCalendar>();
    this.setCCTypeAll(0);
    this.setCCTypeExt(0);
    this.setCCTypeNone(0);
    this.setCCTypeOne(1);
    this.setCaleOn(0);
  }
  
  /**
   * Standard setter for CCTypeAll
   *
   * @param cCTypeAll the CCTypeAll value to set
   */
  public void setCCTypeAll(Integer cCTypeAll)
  {
    properties.setProperty("CCTypeAll", cCTypeAll.toString());
  }

  /**
   * Standard getter for CCTypeAll
   *
   * @returns the CCTypeAll value
   */
  public Integer getCCTypeAll()
  {
    return Integer.parseInt(properties.getProperty("CCTypeAll"));
  }
  
  /**
   * Standard setter for CCTypeExt
   *
   * @param cCTypeExt the CCTypeExt value to set
   */
  public void setCCTypeExt(Integer cCTypeExt)
  {
    properties.setProperty("CCTypeExt", cCTypeExt.toString());
  }

  /**
   * Standard getter for CCTypeExt
   *
   * @returns the CCTypeExt value
   */
  public Integer getCCTypeExt()
  {
    return Integer.parseInt(properties.getProperty("CCTypeExt"));
  }
  
  /**
   * Standard setter for CCTypeNone
   *
   * @param cCTypeNone the CCTypeNone value to set
   */
  public void setCCTypeNone(Integer cCTypeNone)
  {
    properties.setProperty("CCTypeNone", cCTypeNone.toString());
  }

  /**
   * Standard getter for CCTypeNone
   *
   * @returns the CCTypeNone value
   */
  public Integer getCCTypeNone()
  {
    return Integer.parseInt(properties.getProperty("CCTypeNone"));
  }
  
  /**
   * Standard setter for CCTypeOne
   *
   * @param cCTypeOne the CCTypeOne value to set
   */
  public void setCCTypeOne(Integer cCTypeOne)
  {
    properties.setProperty("CCTypeOne", cCTypeOne.toString());
  }

  /**
   * Standard getter for CCTypeOne
   *
   * @returns the CCTypeOne value
   */
  public Integer getCCTypeOne()
  {
    return Integer.parseInt(properties.getProperty("CCTypeOne"));
  }
  
  /**
   * Standard setter for CaleOn
   *
   * @param caleOn the CaleOn value to set
   */
  public void setCaleOn(Integer caleOn)
  {
    properties.setProperty("CaleOn", caleOn.toString());
  }

  /**
   * Standard getter for CaleOn
   *
   * @returns the CaleOn value
   */
  public Integer getCaleOn()
  {
    return Integer.parseInt(properties.getProperty("CaleOn"));
  }

  /**
   * Adds a Calendar to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void addCalendar(TaskCalendar calendar)
  {
    calendars.add(calendar);
  }
  
  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the SyncRefRecords in the collection
   */
  public Iterator<TaskCalendar> getCalendarsIterator()
  {
    return this.calendars.iterator();
  }
}