/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.dashboard;

import java.util.Properties;

/**
 * This class represents an Automic DASHDefinition under DASH object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class DASHDefinition
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the DASHDefinitionFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for DASHDefinition.
   * @see DASHDefinitionFactory
   */
  public DASHDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * DASHDefinition under DASH object in the context of an editor or in a code
   * translator.
   */
  public DASHDefinition()
  {
    this.properties = new Properties();
    this.setDOC("");
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for DOC tag under DASH
   *
   * @param DOC the DOC value to set
   */
  public void setDOC(String dOC)
  {
    properties.setProperty("DOC", dOC);
  }

  /**
   * Standard getter for DOC tag under DASH
   *
   * @return the DOC value
   */
  public String getDOC()
  {
    return properties.getProperty("DOC");
  }

}
