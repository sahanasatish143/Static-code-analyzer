package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARAEventXMLDefinitionFactory
{
  public VARAEventXMLDefinition getDefaultVARAEventXMLDefinition();
  public VARAEventXMLDefinition parseVARAEventXMLDefinitionFromSource();
}
