package com.capgemini.dac.automate.codeanalyzer.uipath.core;

public interface ReferencesDefinitionFactory
{

  public ReferencesDefinition getDefaultReferencesDefinition();

  public ReferencesDefinition parseReferencesDefinitionFromSource();
}
