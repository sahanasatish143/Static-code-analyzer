package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class JobQFilter implements Iterable<JobQFilterDefinition>
{
  Properties properties;
 
  private ArrayList<JobQFilterDefinition> filters;

  public JobQFilter()
  {
    this.properties = new Properties();
//    
    this.setHOSTAttrType("");
  this.setQTypeMsgNr("");
  this.setText("");

    this.filters = new ArrayList<JobQFilterDefinition>();
  }

  public JobQFilter(Properties properties)
  {
    this.properties = properties;
    this.setHOSTAttrType("");
    this.setQTypeMsgNr("");
    this.setText("");

    this.filters = new ArrayList<JobQFilterDefinition>();

  }

  public void setHOSTAttrType(String mode)
{
  properties.setProperty("HOSTAttrType", mode);
}

public String getHOSTAttrType()
{
  return properties.getProperty("HOSTAttrType");
}
public void setQTypeMsgNr(String mode)
{
  properties.setProperty("QTypeMsgNr", mode);
}

public String getQTypeMsgNr()
{
  return properties.getProperty("QTypeMsgNr");
  }

public void setText(String mode)
{
  properties.setProperty("Text", mode);
}

public String getText()
{
  return properties.getProperty("Text");
}

  public void add(JobQFilterDefinition filter)
  {
    filters.add(filter);
  }

  @Override
  public Iterator<JobQFilterDefinition> iterator()
  {

    return filters.iterator();
  }

}
