/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class TaskPredecessor
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public TaskPredecessor()
  {
    this.properties = new Properties();
    this.setBranchType(0);
    this.setLnr(0);
    this.setPreLnr(1);
    this.setWhen("");
    this.setType("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskPredecessor(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Standard setter for BranchType
   *
   * @param branchType the BranchType value to set
   */
  public void setBranchType(Integer branchType)
  {
    properties.setProperty("BranchType", branchType.toString());
  }

  /**
   * Standard getter for BranchType
   *
   * @returns the BranchType value
   */
  public Integer getBranchType()
  {
    return Integer.parseInt(properties.getProperty("BranchType"));
  }
  
  /**
   * Standard setter for Lnr
   *
   * @param lnr the Lnr value to set
   */
  public void setLnr(Integer lnr)
  {
    properties.setProperty("Lnr", lnr.toString());
  }

  /**
   * Standard getter for Lnr
   *
   * @returns the Lnr value
   */
  public Integer getLnr()
  {
    return Integer.parseInt(properties.getProperty("Lnr"));
  }
  
  /**
   * Standard setter for PreLnr
   *
   * @param preLnr the PreLnr value to set
   */
  public void setPreLnr(Integer preLnr)
  {
    properties.setProperty("PreLnr", preLnr.toString());
  }

  /**
   * Standard getter for PreLnr
   *
   * @returns the PreLnr value
   */
  public Integer getPreLnr()
  {
    return Integer.parseInt(properties.getProperty("PreLnr"));
  }
  
  /**
   * Standard setter for When
   *
   * @param when the Whene value to set
   */
  public void setWhen(String when)
  {
    properties.setProperty("When", when);
  }

  /**
   * Standard getter for When
   *
   * @returns the When value
   */
  public String getWhen()
  {
    return properties.getProperty("When");
  }
  
  /**
   * Standard setter for type
   *
   * @param type the type value to set
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Standard getter for type
   *
   * @returns the type value
   */
  public String getType()
  {
    return properties.getProperty("type");
  }
}