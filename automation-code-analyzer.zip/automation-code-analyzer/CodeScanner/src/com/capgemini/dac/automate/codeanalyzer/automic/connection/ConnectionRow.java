package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

public class ConnectionRow
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object. Archive1="sdasd"
   * Archive2="231232" HW="1111" Icon="FILT" Icontype="" Name="DEMO" Role="*"
   * SW="dasdasd" SWVers="sdas" Type="F" Version="dsdfsd111"
   * 
   * @param properties2Properties
   */
  public ConnectionRow()
  {
    this.properties = new Properties();
    this.setName("");
    this.setId(null);
    this.setOCVType(1);
    this.setValue("");
  }

  public ConnectionRow(Properties properties)
  {
    this.properties = properties;
  }

  public void setOCVType(Integer hw)
  {
    properties.setProperty("OCV_Type", hw.toString());
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getOCVType()
  {
    return properties.getProperty("OCV_Type");
  }
  public void setId(Integer Id)
  {
    properties.setProperty("id", Id.toString());
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getId()
  {
    return properties.getProperty("id");
  }

  public void setName(String name)
  {
    properties.setProperty("Name", name);
  }

  /**
   * Standard getter for ArchiveKey1
   *
   * @returns the When ArchiveKey1
   */
  public String getName()
  {
    return properties.getProperty("Name");
  }

  public void setValue(String type)
  {
    properties.setProperty("Value", type);
  }

  /**
   * Standard getter for ArchiveKey1.
   *
   * @return the type
   * @returns the When ArchiveKey1
   */
  public String getType()
  {
    return properties.getProperty("Value");
  }
}
