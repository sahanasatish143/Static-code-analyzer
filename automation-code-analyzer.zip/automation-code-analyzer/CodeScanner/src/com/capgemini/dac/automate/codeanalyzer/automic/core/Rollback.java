/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.core;

import java.util.Properties;

/**
 * Represents a roll back declaration in an Automic executable object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class Rollback
{
  private Properties properties;

  public Rollback(Properties properties)
  {
    this.properties = properties;
  }

  public Rollback()
  {
    properties = new Properties();
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for RollbackFlag
   *
   * @param state the RollbackFlag value to set
   */
  public void setRollbackFlag(Integer RollbackFlag)
  {
    properties.setProperty("RollbackFlag", RollbackFlag.toString());
  }

  /**
   * Standard getter for RollbackFlag
   *
   * @returns the RollbackFlag value
   */
  public Integer RollbackFlag()
  {
    return Integer.parseInt(properties.getProperty("RollbackFlag"));
  }

  /**
   * Standard setter for CBackupObj
   *
   * @param state the CBackupObj value to set
   */
  public void setCBackupObj(String CBackupObj)
  {
    properties.setProperty("CBackupObj", CBackupObj.toString());
  }

  /**
   * Standard getter for CBackupObj
   *
   * @returns the CBackupObj value
   */
  public String getCBackupObj()
  {
    return properties.getProperty("CBackupObj");
  }

  /**
   * Standard setter for CRollbackObj
   *
   * @param state the CRollbackObj value to set
   */
  public void setCRollbackObj(String CRollbackObj)
  {
    properties.setProperty("CRollbackObj", CRollbackObj);
  }

  /**
   * Standard getter for CRollbackObj
   *
   * @returns the CRollbackObj value
   */
  public String getCRollbackObj()
  {
    return properties.getProperty("CRollbackObj");
  }

  /**
   * Standard setter for FBackupPath
   *
   * @param state the FBackupPath value to set
   */
  public void setFBackupPath(String FBackupPath)
  {
    properties.setProperty("FBackupPath", FBackupPath);
  }

  /**
   * Standard getter for FBackupPath
   *
   * @returns the FBackupPath value
   */
  public String getFBackupPath()
  {
    return properties.getProperty("FBackupPath");
  }

  /**
   * Standard setter for FDeleteBefore
   *
   * @param state the FDeleteBefore value to set
   */
  public void setFDeleteBefore(Integer FDeleteBefore)
  {
    properties.setProperty("FDeleteBefore", FDeleteBefore.toString());
  }

  /**
   * Standard getter for FDeleteBefore
   *
   * @returns the FDeleteBefore value
   */
  public Integer getFDeleteBefore()
  {
    return Integer.parseInt(properties.getProperty("FDeleteBefore"));
  }

  /**
   * Standard setter for FInclSubDirs
   *
   * @param state the FInclSubDirs value to set
   */
  public void setFInclSubDirs(Integer FInclSubDirs)
  {
    properties.setProperty("FInclSubDirs", FInclSubDirs.toString());
  }

  /**
   * Standard getter for FInclSubDirs
   *
   * @returns the FInclSubDirs value
   */
  public Integer getFInclSubDirs()
  {
    return Integer.parseInt(properties.getProperty("FInclSubDirs"));
  }
}