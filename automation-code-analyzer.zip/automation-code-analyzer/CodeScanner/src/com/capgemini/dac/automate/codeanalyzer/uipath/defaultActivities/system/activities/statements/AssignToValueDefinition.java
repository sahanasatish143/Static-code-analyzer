/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate.codeanalyzer.uipath.defaultActivities.system.activities.statements;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.uipath.core.UiPathObject;

/**
 * This class represents an UiPath Assign Activity.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */

public class AssignToValueDefinition extends UiPathObject
{

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * AssignToValueDefinition Activity in the context of an editor or in a code
   * translator.
   */
  public AssignToValueDefinition()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the AssignToValueDefinitionFactory interface. All children objects
   * ,inherited from UiPathObject, will be null and are expected to be injected
   * through setters by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for AssignToValueDefinition.
   * @see AssignToValueDefinitionFactory
   */

  public AssignToValueDefinition(Properties properties)
  {
    this.setProperties(properties);
  }

  /**
   * Standard setter for InArgument tag.
   *
   * @param InArgumentthe new InArgument
   */

  public void setInArgument(String attributes)
  {
    // this.inArgument = attributes;
    properties.setProperty("inargument", attributes);
  }

  /**
   * Standard getter for InArgument tag.
   *
   * @return the InArgument value
   */

  public String getInArgument()
  {
    // return inArgument;
    return properties.getProperty("inargument");
  }

  /**
   * Standard setter for OutArgument tag.
   *
   * @param OutArgument the new OutArgument
   */

  public void setOutArgument(String outargument)
  {

    this.properties.setProperty("outargument", outargument);
  }

  /**
   * Standard getter for OutArgument tag.
   *
   * @return the OutArgumentvalue
   */
  public String getOutArgument()
  {
    return properties.getProperty("outargument");
  }

  /**
   * Standard setter for Attributes tag.
   *
   * @param Aributes the new Attributes
   */
  public void setAttributes(Properties properties)
  {

    this.properties.put("attributes", properties);
  }

  /**
   * Standard getter for Attributes tag.
   *
   * @return the Attributes value
   */
  public String getAttributes()
  {
    return properties.getProperty("attributes");
  }

}
