package com.capgemini.dac.automate.codeanalyzer.uipath.core;

public interface ReferencesForImplementationFactory
{
  public ReferencesForImplementation getDefaultReferencesForImplementation();

  public ReferencesForImplementation parseReferencesForImplementationFromSource();
}
