package com.capgemini.dac.automate.codeanalyzer.automic.jobq;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;
import com.capgemini.dac.automate.codeanalyzer.automic.core.OutputScan;


public class JOBQ  extends AutomicExecutableObject{
  /** The jobf definition. */
  private JobQDefinition jobQDefinition;

  /** The jobf attr. */
  private JobQAttr jobQAttr;
  /** The out scan. */
  private OutputScan outScan;

  /** The main script. */
  private AutomicScript mainScript;

 

  /**
   * Instantiates a new jobf.
   */
  public JOBQ()
  {
    this.properties=new Properties();
  }

  /**
   * Instantiates a new jobf.
   *
   * @param properties the properties
   */
  public JOBQ(Properties properties)
  {
    this.properties=properties;
  }

  /**
   * Sets the jobf definition.
   *
   * @param jobfDefinition the new jobf definition
   */
  public void setJobQDefinition(JobQDefinition jobQDefinition)
  {
    this.jobQDefinition = jobQDefinition;
  }

  /**
   * Gets the jobf definition.
   *
   * @return the jobf definition
   */
  public JobQDefinition getJobQDefinition()
  {
    return this.jobQDefinition;
  }

  /**
   * Sets the jobf attr.
   *
   * @param jobfAttr the new jobf attr
   */
  public void setJobQAttr(JobQAttr jobQAttr)
  {
    this.jobQAttr = jobQAttr;
  }

  /**
   * Gets the jobf attr.
   *
   * @return the jobf attr
   */
  public JobQAttr getJobQAttr()
  {
    return this.jobQAttr;
  }
  /**
   * Sets the out scan.
   *
   * @param outScan the new out scan
   */
  public void setOutScan(OutputScan outScan)
  {
    this.outScan = outScan;
  }

  /**
   * Gets the out scan.
   *
   * @return the out scan
   */
  public OutputScan getOutScan()
  {
    return this.outScan;
  }

  /**
   * Sets the script.
   *
   * @param script the new script
   */
  public void setScript(AutomicScript script)
  {
    this.mainScript = script;
  }

  /**
   * Gets the script.
   *
   * @return the script
   */
  public AutomicScript getScript()
  {
    return this.mainScript;
  }

 

}