package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VARASQLFactory
{
  public VARASQL getDefaultVARASQL();
  public VARASQL parseVARASQLFromSource();
}
