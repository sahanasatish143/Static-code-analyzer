package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface TabConnPropertiesFactory
{
  public TabConnProperties getDefaultTabConnProperties();
  public TabConnProperties parseTabConnPropertiesFromSource();
}
