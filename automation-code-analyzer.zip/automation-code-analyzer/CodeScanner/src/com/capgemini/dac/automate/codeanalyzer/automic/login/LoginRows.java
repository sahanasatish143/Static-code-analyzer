package com.capgemini.dac.automate.codeanalyzer.automic.login;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class LoginRows implements Iterable<Row>
{

  /** The properties. */
  Properties properties;

  /** The rows. */
  private ArrayList<Row> rows;

  /**
   * Instantiates a new members.
   */
  public LoginRows(Properties properties)
  {
    this.properties = properties;
    this.rows = new ArrayList<Row>();
  }

  public LoginRows()
  {
    this.properties = new Properties();
    this.rows = new ArrayList<Row>();
  }

  /**
   * Constructor meant to be used by a factory adhering to the memberFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */

  public void add(Row row)
  {
    rows.add(row);
  }

  @Override
  public Iterator<Row> iterator()
  {
    return rows.iterator();
  }

}