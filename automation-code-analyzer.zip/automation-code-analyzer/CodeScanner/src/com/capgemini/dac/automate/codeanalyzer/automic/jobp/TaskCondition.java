/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class TaskCondition implements Iterable<ConditionParam> 
{
  Properties properties;
  private ArrayList<ConditionParam> params;
  private TaskCondition condition1;
  private TaskCondition condition2;

  /**
   * Constructor to build a default Runtime object.
   */
  private TaskCondition()
  {
    this.properties = new Properties();
    this.params = null;
    this.condition1 = null;
    this.condition2 = null;
    this.setActive(1);
    this.setId("");
    this.setOnce(0);
    this.setType("");
    this.setUiinfo("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskCondition(Properties properties)
  {
    this.properties = properties;
    this.params = null;
    this.condition1 = null;
    this.condition2 = null;
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public static TaskCondition getDefualtCondition()
  {
    TaskCondition result = new TaskCondition();
    result.setType("C");
    return result;
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public static TaskCondition getDefualtAction()
  {
    TaskCondition result = new TaskCondition();
    result.setType("A");
    return result;
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public static TaskCondition getDefualtWhen()
  {
    TaskCondition result = new TaskCondition();
    result.setType("W");
    return result;
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public static TaskCondition getDefualtElse()
  {
    TaskCondition result = new TaskCondition();
    result.setType("E");
    return result;
  }
  
  /**
   * Standard setter for Active
   *
   * @param active the Active value to set
   */
  public void setActive(Integer active)
  {
    properties.setProperty("active", active.toString());
  }

  /**
   * Standard getter for Active
   *
   * @returns the Active value
   */
  public Integer getActive()
  {
    return Integer.parseInt(properties.getProperty("active"));
  }
  
  /**
   * Standard setter for id
   *
   * @param id the id value to set
   */
  public void setId(String id)
  {
    properties.setProperty("id", id);
  }

  /**
   * Standard getter for id
   *
   * @returns the id value
   */
  public String getId()
  {
    return properties.getProperty("id");
  }
  
  /**
   * Standard setter for once
   *
   * @param once the once value to set
   */
  public void setOnce(Integer once)
  {
    properties.setProperty("once", once.toString());
  }

  /**
   * Standard getter for once
   *
   * @returns the once value
   */
  public Integer getOnce()
  {
    return Integer.parseInt(properties.getProperty("once"));
  }
  
  /**
   * Standard setter for type
   *
   * @param type the type value to set
   */
  public void setType(String type)
  {
    properties.setProperty("type", type);
  }

  /**
   * Standard getter for type
   *
   * @returns the type value
   */
  public String getType()
  {
    return properties.getProperty("type");
  }
  
  /**
   * Standard setter for uiinfo
   *
   * @param uiinfo the uiinfo value to set
   */
  public void setUiinfo(String uiinfo)
  {
    properties.setProperty("uiinfo", uiinfo);
  }

  /**
   * Standard getter for uiinfo
   *
   * @returns the uiinfo value
   */
  public String getUiinfo()
  {
    return properties.getProperty("uiinfo");
  }
  
  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setCondition(TaskCondition condition)
  {
    condition1 = condition;
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public TaskCondition getCondition()
  {
    return condition1;
  }
  
  /**
   * Standard setter for action
   *
   * @param action the action value to set
   */
  public void setAction(TaskCondition action)
  {
    condition2 = action;
  }

  /**
   * Standard getter for action
   *
   * @returns the action value
   */
  public TaskCondition getAction()
  {
    return condition2;
  }
  
  /**
   * Standard setter for when
   *
   * @param when the when value to set
   */
  public void setWhen(TaskCondition when)
  {
    condition1 = when;
  }

  /**
   * Standard getter for when
   *
   * @returns the when value
   */
  public TaskCondition getWhen()
  {
    return condition1;
  }
  
  /**
   * Standard setter for else
   *
   * @param Else the else value to set
   */
  public void setElse(TaskCondition Else)
  {
    condition2 = Else;
  }

  /**
   * Standard getter for else
   *
   * @returns the else value
   */
  public TaskCondition getElse()
  {
    return condition2;
  }

  /**
   * Adds a SyncRefRecord to the list.
   *
   * @param the the SyncRefRecord to add to the collection
   */
  public void add(ConditionParam record)
  {
    if (params == null)
      params = new ArrayList<ConditionParam>();
    params.add(record);
  }
  
  /**
   * returns the iterator for the collection
   *
   * @returns an iterator for the SyncRefRecords in the collection 
   */
  @Override
  public Iterator<ConditionParam> iterator()
  {
    return params.iterator();
  }
}