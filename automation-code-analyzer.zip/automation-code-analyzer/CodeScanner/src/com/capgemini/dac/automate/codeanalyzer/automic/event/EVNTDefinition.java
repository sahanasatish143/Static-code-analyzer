/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

/**
 * This class represents an Automic EVNTDefinition object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNTDefinition
{

  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVNTDefinition object in the context of an editor or in a code translator.
   */
  public EVNTDefinition()
  {
    this.properties = new Properties();

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVNTDefinitionFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVNTDefinition.
   * @see EVNTDefinitionFactory
   */
  public EVNTDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for RepeatTypeS
   *
   * @param RepeatTypeS the RepeatTypeS value to set
   */
  public void setRepeatTypeS(Integer repeatTypeS)
  {
    properties.setProperty("RepeatTypeS", repeatTypeS.toString());
  }

  /**
   * Standard getter for RepeatTypeS
   *
   * @return the RepeatTypeS value
   */
  public Integer getRepeatTypeS()
  {
    return Integer.parseInt(properties.getProperty("RepeatTypeS"));
  }

  /**
   * Standard setter for EventTypeTS
   *
   * @param EventTypeTS the EventTypeTS value to set
   */
  public void setEventTypeTS(Integer eventTypeTS)
  {
    properties.setProperty("EventTypeTS", eventTypeTS.toString());
  }

  /**
   * Standard getter for EventTypeTS
   *
   * @return the EventTypeTS value
   */
  public Integer getEventTypeTS()
  {
    return Integer.parseInt(properties.getProperty("EventTypeTS"));
  }

  /**
   * Standard setter for EventTypeTT
   *
   * @param EventTypeTT the EventTypeTT value to set
   */
  public void setEventTypeTT(Integer eventTypeTT)
  {
    properties.setProperty("EventTypeTT", eventTypeTT.toString());
  }

  /**
   * Standard getter for EventTypeTT
   *
   * @return the EventTypeTT value
   */
  public Integer getEventTypeTT()
  {
    return Integer.parseInt(properties.getProperty("EventTypeTT"));
  }

  /**
   * Standard setter for RepeatTypeF
   *
   * @param RepeatTypeF the RepeatTypeF value to set
   */
  public void setRepeatTypeF(Integer repeatTypeF)
  {
    properties.setProperty("RepeatTypeF", repeatTypeF.toString());
  }

  /**
   * Standard getter for RepeatTypeF
   *
   * @return the RepeatTypeF value
   */
  public Integer getRepeatTypeF()
  {
    return Integer.parseInt(properties.getProperty("RepeatTypeF"));
  }

  /**
   * Standard setter for RepeatTypeR
   *
   * @param RepeatTypeR the RepeatTypeR value to set
   */
  public void setRepeatTypeR(Integer repeatTypeR)
  {
    properties.setProperty("RepeatTypeR", repeatTypeR.toString());
  }

  /**
   * Standard getter for RepeatTypeR
   *
   * @return the RepeatTypeR value
   */
  public Integer getRepeatTypeR()
  {
    return Integer.parseInt(properties.getProperty("RepeatTypeR"));
  }

  /**
   * Standard setter for EventTypeAuto
   *
   * @param EventTypeAuto the EventTypeAuto value to set
   */
  public void setEventTypeAuto(Integer eventTypeAuto)
  {
    properties.setProperty("EventTypeAuto", eventTypeAuto.toString());
  }

  /**
   * Standard getter for EventTypeAuto
   *
   * @return the EventTypeAuto value
   */
  public Integer getEventTypeAuto()
  {
    return Integer.parseInt(properties.getProperty("EventTypeAuto"));
  }

  /**
   * Standard setter for TExecTypeT
   *
   * @param TExecTypeT the TExecTypeT value to set
   */
  public void setTExecTypeT(Integer tExecTypeT)
  {
    properties.setProperty("TExecTypeT", tExecTypeT.toString());
  }

  /**
   * Standard getter for TExecTypeT
   *
   * @return the TExecTypeT value
   */
  public Integer getTExecTypeT()
  {
    return Integer.parseInt(properties.getProperty("TExecTypeT"));
  }

  /**
   * Standard setter for TExecTypeS
   *
   * @param TExecTypeS the TExecTypeS value to set
   */
  public void setTExecTypeS(Integer tExecTypeS)
  {
    properties.setProperty("TExecTypeS", tExecTypeS.toString());
  }

  /**
   * Standard getter for TExecTypeS
   *
   * @return the TExecTypeS value
   */
  public Integer getTExecTypeS()
  {
    return Integer.parseInt(properties.getProperty("TExecTypeS"));
  }

  /**
   * Standard setter for TExecTypeN
   *
   * @param TExecTypeN the TExecTypeN value to set
   */
  public void setTExecTypeN(Integer tExecTypeN)
  {
    properties.setProperty("TExecTypeN", tExecTypeN.toString());
  }

  /**
   * Standard getter for TExecTypeN
   *
   * @return the TExecTypeN value
   */
  public Integer getTExecTypeN()
  {
    return Integer.parseInt(properties.getProperty("TExecTypeN"));
  }

  /**
   * Standard setter for TExecTypeE
   *
   * @param TExecTypeE the TExecTypeE value to set
   */
  public void setTExecTypeE(Integer tExecTypeE)
  {
    properties.setProperty("TExecTypeE", tExecTypeE.toString());
  }

  /**
   * Standard getter for TExecTypeE
   *
   * @return the TExecTypeE value
   */
  public Integer getTExecTypeE()
  {
    return Integer.parseInt(properties.getProperty("TExecTypeE"));
  }

  /**
   * Standard setter for TimePeriodTT
   *
   * @param TimePeriodTT the TimePeriodTT value to set
   */
  public void setTimePeriodTT(Integer timePeriodTT)
  {
    properties.setProperty("TimePeriodTT", timePeriodTT.toString());
  }

  /**
   * Standard getter for TimePeriodTT
   *
   * @return the TimePeriodTT value
   */
  public Integer getTimePeriodTT()
  {
    return Integer.parseInt(properties.getProperty("TimePeriodTT"));
  }

  /**
   * Standard setter for TimePeriodTS
   *
   * @param TimePeriodTS the TimePeriodTS value to set
   */
  public void setTimePeriodTS(String timePeriodTS)
  {
    properties.setProperty("TimePeriodTS", timePeriodTS);
  }

  /**
   * Standard getter for TimePeriodTS
   *
   * @return the TimePeriodTS value
   */
  public String getTimePeriodTS()
  {
    return properties.getProperty("TimePeriodTS");
  }
}
