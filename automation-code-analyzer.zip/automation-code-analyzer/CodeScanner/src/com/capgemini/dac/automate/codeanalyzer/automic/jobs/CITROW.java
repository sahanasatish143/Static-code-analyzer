/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic CITROW under JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CITROW
{
  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CITROW under JOBS object in the context of an editor or in a code translator.
   */
  public CITROW()
  {
    this.properties = new Properties();
    this.setIcon("");
    this.setCittype(null);
    this.setSubtype("");
    this.setText("");

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CITROWFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CITROW.
   * @see CITROWFactory
   */
  public CITROW(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for Icon
   *
   * @param Icon the Icon value to set
   */
  public void setIcon(String icon)
  {
    properties.setProperty("Icon", icon);
  }

  /**
   * Standard getter for Icon
   *
   * @returns the Icon value
   */
  public String getIcon()
  {
    return properties.getProperty("Icon");
  }

  /**
   * Standard setter for Subtype
   *
   * @param Subtype the Subtype value to set
   */
  public void setSubtype(String subtype)
  {
    properties.setProperty("Subtype", subtype);
  }

  /**
   * Standard getter for Subtype
   *
   * @returns the Subtype value
   */
  public String getSubtype()
  {
    return properties.getProperty("Subtype");
  }

  /**
   * Standard setter for Text
   *
   * @param Text the Text value to set
   */
  public void setText(String text)
  {
    properties.setProperty("Text", text);
  }

  /**
   * Standard getter for Text
   *
   * @returns the Text value
   */
  public String getText()
  {
    return properties.getProperty("Text");
  }

  /**
   * Standard setter for Cittype
   *
   * @param Cittype the Cittype value to set
   */
  public void setCittype(Integer cittype)
  {
    properties.setProperty("Cittype", cittype.toString());
  }

  /**
   * Standard getter for Cittype
   *
   * @returns the Cittype value
   */
  public Integer getCittype()
  {
    return Integer.parseInt(properties.getProperty("Cittype"));
  }
}
