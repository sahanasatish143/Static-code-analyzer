/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.usergrp;

import java.util.Properties;

/**
 * This class represents an Automic PrivList under USRG object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class PrivList
{
  Properties properties;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the PrivListFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for PrivList.
   * @see PrivListFactory
   */
  public PrivList(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * PrivList under USRG object in the context of an editor or in a code
   * translator.
   */
  public PrivList()
  {
    this.properties = new Properties();
    this.setB1(0);
    this.setB2(0);
    this.setB4(0);
    this.setB8(0);
    this.setB16(0);
    this.setB32(0);
    this.setB64(0);
    this.setB128(0);
    this.setB256(0);
    this.setB512(0);
    this.setB1024(0);
    this.setB2048(0);
    this.setB4096(0);
    this.setB8192(0);
    this.setB16384(0);
    this.setB32768(0);
    this.setB65536(0);
    this.setB131072(0);
    this.setB262144(0);
    this.setB524288(0);
    this.setB1048576(0);
    this.setB2097152(0);
    this.setB4194304(0);
    this.setB8388608(0);
    this.setB16777216(0);
    this.setB33554432(0);
    this.setB67108864(0);
    this.setB134217728(0);
    this.setB268435456(0);
    this.setB536870912(0);
    this.setB1073741824(0);
    this.setB2147483648(0);
    this.setB4294967296(0);
    this.setB8589934592(0);
    this.setB17179869184(0);
    this.setB34359738368(0);
    this.setB68719476736(0);
    this.setB137438953472(0);
    this.setB274877906944(0);
    this.setB549755813888(0);
    this.setB1099511627776(0);
    this.setB2199023255552(0);
    this.setB8796093022208(0);
    this.setB4398046511104(0);

  }

  /**
   * Standard setter for B1
   *
   * @param B1 the B1 value to set
   */
  public void setB1(Integer b1)
  {
    properties.setProperty("b1", b1.toString());
  }

  /**
   * Standard getter for B1
   *
   * @return the B1 value
   */
  public Integer getB1()
  {
    return Integer.parseInt(properties.getProperty("b1"));
  }

  /**
   * Standard setter for B2
   *
   * @param B2 the B2 value to set
   */
  public void setB2(Integer b2)
  {
    properties.setProperty("b2", b2.toString());
  }

  /**
   * Standard getter for B2
   *
   * @return the B2 value
   */
  public Integer getB2()
  {
    return Integer.parseInt(properties.getProperty("b2"));
  }

  /**
   * Standard setter for B4
   *
   * @param B4 the B4 value to set
   */
  public void setB4(Integer b4)
  {
    properties.setProperty("b4", b4.toString());
  }

  /**
   * Standard getter for B4
   *
   * @return the B4 value
   */
  public Integer getB4()
  {
    return Integer.parseInt(properties.getProperty("b4"));
  }

  /**
   * Standard setter for B8
   *
   * @param B8 the B8 value to set
   */
  public void setB8(Integer b8)
  {
    properties.setProperty("b8", b8.toString());
  }

  /**
   * Standard getter for B8
   *
   * @return the B8 value
   */
  public Integer getB8()
  {
    return Integer.parseInt(properties.getProperty("b8"));
  }

  /**
   * Standard setter for B16
   *
   * @param B16 the B16 value to set
   */
  public void setB16(Integer b16)
  {
    properties.setProperty("b16", b16.toString());
  }

  /**
   * Standard getter for B16
   *
   * @return the B16 value
   */
  public Integer getB16()
  {
    return Integer.parseInt(properties.getProperty("b16"));
  }

  /**
   * Standard setter for B32
   *
   * @param B32 the B32 value to set
   */
  public void setB32(Integer b32)
  {
    properties.setProperty("b32", b32.toString());
  }

  /**
   * Standard getter for B32
   *
   * @return the B32 value
   */
  public Integer getB32()
  {
    return Integer.parseInt(properties.getProperty("b32"));
  }

  /**
   * Standard setter for B64
   *
   * @param B64 the B64 value to set
   */
  public void setB64(Integer b64)
  {
    properties.setProperty("b64", b64.toString());
  }

  /**
   * Standard getter for B64
   *
   * @return the B64 value
   */
  public Integer getB64()
  {
    return Integer.parseInt(properties.getProperty("b64"));
  }

  /**
   * Standard setter for B128
   *
   * @param B128 the B128 value to set
   */
  public void setB128(Integer b128)
  {
    properties.setProperty("b128", b128.toString());
  }

  /**
   * Standard getter for B128
   *
   * @return the B128 value
   */
  public Integer getB128()
  {
    return Integer.parseInt(properties.getProperty("b128"));
  }

  /**
   * Standard setter for B256
   *
   * @param B256 the B256 value to set
   */
  public void setB256(Integer b256)
  {
    properties.setProperty("b256", b256.toString());
  }

  /**
   * Standard getter for B256
   *
   * @return the B256 value
   */
  public Integer getB256()
  {
    return Integer.parseInt(properties.getProperty("b256"));
  }

  /**
   * Standard setter for B512
   *
   * @param B512 the B512 value to set
   */
  public void setB512(Integer b512)
  {
    properties.setProperty("b512", b512.toString());
  }

  /**
   * Standard getter for B512
   *
   * @return the B512 value
   */
  public Integer getB512()
  {
    return Integer.parseInt(properties.getProperty("b512"));
  }

  /**
   * Standard setter for B1024
   *
   * @param B1024 the B1024 value to set
   */
  public void setB1024(Integer b1024)
  {
    properties.setProperty("b1024", b1024.toString());
  }

  /**
   * Standard getter for B1024
   *
   * @return the B1024 value
   */
  public Integer getB1024()
  {
    return Integer.parseInt(properties.getProperty("b1024"));
  }

  /**
   * Standard setter for B2048
   *
   * @param B2048 the B2048 value to set
   */
  public void setB2048(Integer b2048)
  {
    properties.setProperty("b2048", b2048.toString());
  }

  /**
   * Standard getter for B2048
   *
   * @return the B2048 value
   */
  public Integer getB2048()
  {
    return Integer.parseInt(properties.getProperty("b2048"));
  }

  /**
   * Standard setter for B4096
   *
   * @param B4096 the B4096 value to set
   */
  public void setB4096(Integer b4096)
  {
    properties.setProperty("b4096", b4096.toString());
  }

  /**
   * Standard getter for B4096
   *
   * @return the B4096 value
   */
  public Integer getB4096()
  {
    return Integer.parseInt(properties.getProperty("b4096"));
  }

  /**
   * Standard setter for B8192
   *
   * @param B8192 the B8192 value to set
   */
  public void setB8192(Integer b8192)
  {
    properties.setProperty("b8192", b8192.toString());
  }

  /**
   * Standard getter for B8192
   *
   * @return the B8192 value
   */
  public Integer getB8192()
  {
    return Integer.parseInt(properties.getProperty("b8192"));
  }

  /**
   * Standard setter for B16384
   *
   * @param B16384 the B16384 value to set
   */
  public void setB16384(Integer b16384)
  {
    properties.setProperty("b16384", b16384.toString());
  }

  /**
   * Standard getter for B16384
   *
   * @return the B16384 value
   */
  public Integer getB16384()
  {
    return Integer.parseInt(properties.getProperty("b16384"));
  }

  /**
   * Standard setter for B32768
   *
   * @param B32768 the B32768 value to set
   */
  public void setB32768(Integer b32768)
  {
    properties.setProperty("b32768", b32768.toString());
  }

  /**
   * Standard getter for B32768
   *
   * @return the B32768 value
   */
  public Integer getB32768()
  {
    return Integer.parseInt(properties.getProperty("b32768"));
  }

  /**
   * Standard setter for B65536
   *
   * @param B65536 the B65536 value to set
   */
  public void setB65536(Integer b65536)
  {
    properties.setProperty("b65536", b65536.toString());
  }

  /**
   * Standard getter for B65536
   *
   * @return the B65536 value
   */
  public Integer getB65536()
  {
    return Integer.parseInt(properties.getProperty("b65536"));
  }

  /**
   * Standard setter for B131072
   *
   * @param B131072 the B131072 value to set
   */
  public void setB131072(Integer b131072)
  {
    properties.setProperty("b131072", b131072.toString());
  }

  /**
   * Standard getter for B131072
   *
   * @return the B131072 value
   */
  public Integer getB131072()
  {
    return Integer.parseInt(properties.getProperty("b131072"));
  }

  /**
   * Standard setter for B262144
   *
   * @param B262144 the B262144 value to set
   */
  public void setB262144(Integer b262144)
  {
    properties.setProperty("b262144", b262144.toString());
  }

  /**
   * Standard getter for B262144
   *
   * @return the B262144 value
   */
  public Integer getB262144()
  {
    return Integer.parseInt(properties.getProperty("b262144"));
  }

  /**
   * Standard setter for B524288
   *
   * @param B524288 the B524288 value to set
   */
  public void setB524288(Integer b524288)
  {
    properties.setProperty("b524288", b524288.toString());
  }

  /**
   * Standard getter for B524288
   *
   * @return the B524288 value
   */
  public Integer getB524288()
  {
    return Integer.parseInt(properties.getProperty("b524288"));
  }

  /**
   * Standard setter for B1048576
   *
   * @param B1048576 the B1048576 value to set
   */
  public void setB1048576(Integer b1048576)
  {
    properties.setProperty("b1048576", b1048576.toString());
  }

  /**
   * Standard getter for B1048576
   *
   * @return the B1048576 value
   */
  public Integer getB1048576()
  {
    return Integer.parseInt(properties.getProperty("b1048576"));
  }

  /**
   * Standard setter for B2097152
   *
   * @param B2097152 the B2097152 value to set
   */
  public void setB2097152(Integer b2097152)
  {
    properties.setProperty("b2097152", b2097152.toString());
  }

  /**
   * Standard getter for B2097152
   *
   * @return the B2097152 value
   */
  public Integer getB2097152()
  {
    return Integer.parseInt(properties.getProperty("b2097152"));
  }

  /**
   * Standard setter for B4194304
   *
   * @param B4194304 the B4194304 value to set
   */
  public void setB4194304(Integer b4194304)
  {
    properties.setProperty("b4194304", b4194304.toString());
  }

  /**
   * Standard getter for B4194304
   *
   * @return the B4194304 value
   */
  public Integer getB4194304()
  {
    return Integer.parseInt(properties.getProperty("b4194304"));
  }

  /**
   * Standard setter for B8388608
   *
   * @param B8388608 the B8388608 value to set
   */
  public void setB8388608(Integer b8388608)
  {
    properties.setProperty("b8388608", b8388608.toString());
  }

  /**
   * Standard getter for B8388608
   *
   * @return the B8388608 value
   */
  public Integer getB8388608()
  {
    return Integer.parseInt(properties.getProperty("b8388608"));
  }

  /**
   * Standard setter for B16777216
   *
   * @param B16777216 the B16777216 value to set
   */
  public void setB16777216(Integer b16777216)
  {
    properties.setProperty("b16777216", b16777216.toString());
  }

  /**
   * Standard getter for B16777216
   *
   * @return the B16777216 value
   */
  public Integer getB16777216()
  {
    return Integer.parseInt(properties.getProperty("b16777216"));
  }

  /**
   * Standard setter for B33554432
   *
   * @param B33554432 the B33554432 value to set
   */
  public void setB33554432(Integer b33554432)
  {
    properties.setProperty("b33554432", b33554432.toString());
  }

  /**
   * Standard getter for B33554432
   *
   * @return the B33554432 value
   */
  public Integer getB33554432()
  {
    return Integer.parseInt(properties.getProperty("b33554432"));
  }

  /**
   * Standard setter for B67108864
   *
   * @param B67108864 the B67108864 value to set
   */
  public void setB67108864(Integer b67108864)
  {
    properties.setProperty("b67108864", b67108864.toString());
  }

  /**
   * Standard getter for B67108864
   *
   * @return the B67108864 value
   */
  public Integer getB67108864()
  {
    return Integer.parseInt(properties.getProperty("b67108864"));
  }

  /**
   * Standard setter for B134217728
   *
   * @param B134217728 the B134217728 value to set
   */
  public void setB134217728(Integer b134217728)
  {
    properties.setProperty("b134217728", b134217728.toString());
  }

  /**
   * Standard getter for B134217728
   *
   * @return the B134217728 value
   */
  public Integer getB134217728()
  {
    return Integer.parseInt(properties.getProperty("b134217728"));
  }

  /**
   * Standard setter for B268435456
   *
   * @param B268435456 the B268435456 value to set
   */
  public void setB268435456(Integer b268435456)
  {
    properties.setProperty("b268435456", b268435456.toString());
  }

  /**
   * Standard getter for B268435456
   *
   * @return the B268435456 value
   */
  public Integer getB268435456()
  {
    return Integer.parseInt(properties.getProperty("b268435456"));
  }

  /**
   * Standard setter for B536870912
   *
   * @param B536870912 the B536870912 value to set
   */
  public void setB536870912(Integer b536870912)
  {
    properties.setProperty("b536870912", b536870912.toString());
  }

  /**
   * Standard getter for B536870912
   *
   * @return the B536870912 value
   */
  public Integer getB536870912()
  {
    return Integer.parseInt(properties.getProperty("b536870912"));
  }

  /**
   * Standard setter for B1073741824
   *
   * @param B1073741824 the B1073741824 value to set
   */
  public void setB1073741824(Integer b1073741824)
  {
    properties.setProperty("b1073741824", b1073741824.toString());
  }

  /**
   * Standard getter for B1073741824
   *
   * @return the B1073741824 value
   */
  public Integer getB1073741824()
  {
    return Integer.parseInt(properties.getProperty("b1073741824"));
  }

  /**
   * Standard setter for B2147483648
   *
   * @param B2147483648 the B2147483648 value to set
   */
  public void setB2147483648(Integer b2147483648)
  {
    properties.setProperty("b2147483648", b2147483648.toString());
  }

  /**
   * Standard getter for B2147483648
   *
   * @return the B2147483648 value
   */
  public Integer getB2147483648()
  {
    return Integer.parseInt(properties.getProperty("b2147483648"));
  }

  /**
   * Standard setter for B4294967296
   *
   * @param B4294967296 the B4294967296 value to set
   */
  public void setB4294967296(Integer b4294967296)
  {
    properties.setProperty("b4294967296", b4294967296.toString());
  }

  /**
   * Standard getter for B4294967296
   *
   * @return the B4294967296 value
   */
  public Integer getB4294967296()
  {
    return Integer.parseInt(properties.getProperty("b4294967296"));
  }

  /**
   * Standard setter for B8589934592
   *
   * @param B8589934592 the B8589934592 value to set
   */
  public void setB8589934592(Integer b8589934592)
  {
    properties.setProperty("b8589934592", b8589934592.toString());
  }

  /**
   * Standard getter for B8589934592
   *
   * @return the B8589934592 value
   */
  public Integer getB8589934592()
  {
    return Integer.parseInt(properties.getProperty("b8589934592"));
  }

  /**
   * Standard setter for B17179869184
   *
   * @param B17179869184 the B17179869184 value to set
   */
  public void setB17179869184(Integer b17179869184)
  {
    properties.setProperty("b17179869184", b17179869184.toString());
  }

  /**
   * Standard getter for B17179869184
   *
   * @return the B17179869184 value
   */
  public Integer getB17179869184()
  {
    return Integer.parseInt(properties.getProperty("b17179869184"));
  }

  /**
   * Standard setter for B34359738368
   *
   * @param B34359738368 the B34359738368 value to set
   */
  public void setB34359738368(Integer b34359738368)
  {
    properties.setProperty("b34359738368", b34359738368.toString());
  }

  /**
   * Standard getter for B34359738368
   *
   * @return the B34359738368 value
   */
  public Integer getB34359738368()
  {
    return Integer.parseInt(properties.getProperty("b34359738368"));
  }

  /**
   * Standard setter for B68719476736
   *
   * @param B68719476736 the B68719476736 value to set
   */
  public void setB68719476736(Integer b68719476736)
  {
    properties.setProperty("b68719476736", b68719476736.toString());
  }

  /**
   * Standard getter for B68719476736
   *
   * @return the B68719476736 value
   */
  public Integer getB68719476736()
  {
    return Integer.parseInt(properties.getProperty("b68719476736"));
  }

  /**
   * Standard setter for B137438953472
   *
   * @param B137438953472 the B137438953472 value to set
   */
  public void setB137438953472(Integer b137438953472)
  {
    properties.setProperty("b137438953472", b137438953472.toString());
  }

  /**
   * Standard getter for B137438953472
   *
   * @return the B137438953472 value
   */
  public Integer getB137438953472()
  {
    return Integer.parseInt(properties.getProperty("b137438953472"));
  }

  /**
   * Standard setter for B274877906944
   *
   * @param B274877906944 the B274877906944 value to set
   */
  public void setB274877906944(Integer b274877906944)
  {
    properties.setProperty("b274877906944", b274877906944.toString());
  }

  /**
   * Standard getter for B274877906944
   *
   * @return the B274877906944 value
   */
  public Integer getB274877906944()
  {
    return Integer.parseInt(properties.getProperty("b274877906944"));
  }

  /**
   * Standard setter for B549755813888
   *
   * @param B549755813888 the B549755813888 value to set
   */
  public void setB549755813888(Integer b549755813888)
  {
    properties.setProperty("b549755813888", b549755813888.toString());
  }

  /**
   * Standard getter for B549755813888
   *
   * @return the B549755813888 value
   */
  public Integer getB549755813888()
  {
    return Integer.parseInt(properties.getProperty("b549755813888"));
  }

  /**
   * Standard setter for B1099511627776
   *
   * @param B1099511627776 the B1099511627776 value to set
   */
  public void setB1099511627776(Integer b1099511627776)
  {
    properties.setProperty("b1099511627776", b1099511627776.toString());
  }

  /**
   * Standard getter for B1099511627776
   *
   * @return the B1099511627776 value
   */
  public Integer getB1099511627776()
  {
    return Integer.parseInt(properties.getProperty("b1099511627776"));
  }

  /**
   * Standard setter for B2199023255552
   *
   * @param B2199023255552 the B2199023255552 value to set
   */
  public void setB2199023255552(Integer b2199023255552)
  {
    properties.setProperty("B2199023255552", b2199023255552.toString());
  }

  /**
   * Standard getter for B2199023255552
   *
   * @return the B2199023255552 value
   */
  public Integer getB2199023255552()
  {
    return Integer.parseInt(properties.getProperty("b2199023255552"));
  }

  /**
   * Standard setter for B4398046511104
   *
   * @param B4398046511104 the B4398046511104 value to set
   */
  public void setB4398046511104(Integer b4398046511104)
  {
    properties.setProperty("b4398046511104", b4398046511104.toString());
  }

  /**
   * Standard getter for B4398046511104
   *
   * @return the B4398046511104 value
   */
  public Integer getB4398046511104()
  {
    return Integer.parseInt(properties.getProperty("b4398046511104"));
  }

  /**
   * Standard setter for B8796093022208
   *
   * @param B8796093022208 the B8796093022208 value to set
   */
  public void setB8796093022208(Integer b8796093022208)
  {
    properties.setProperty("b8796093022208", b8796093022208.toString());
  }

  /**
   * Standard getter for B8796093022208
   *
   * @return the B8796093022208 value
   */
  public Integer getB8796093022208()
  {
    return Integer.parseInt(properties.getProperty("B8796093022208"));
  }
}
