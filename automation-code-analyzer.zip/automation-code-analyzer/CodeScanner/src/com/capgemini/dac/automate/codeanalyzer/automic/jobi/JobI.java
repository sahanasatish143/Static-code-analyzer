/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.jobi;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;
import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicScript;

// TODO: Auto-generated Javadoc
/**
 * The Class JobI.

 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.0
 */
public class JobI extends AutomicExecutableObject
{

  /** The main script. */
  private AutomicScript mainScript;

  /**
   * Instantiates a new job I.
   */
  public JobI()
  {
    this.properties = new Properties();
  }

  /**
   * Instantiates a new job I.
   *
   * @param properties the properties
   */
  public JobI(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Sets the script.
   *
   * @param script the new script
   */
  public void setScript(AutomicScript script)
  {
    this.mainScript = script;
  }

  /**
   * Gets the script.
   *
   * @return the script
   */
  public AutomicScript getScript()
  {
    return this.mainScript;
  }

}