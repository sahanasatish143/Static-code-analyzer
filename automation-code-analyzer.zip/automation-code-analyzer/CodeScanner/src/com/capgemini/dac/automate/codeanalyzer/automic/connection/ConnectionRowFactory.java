package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface ConnectionRowFactory
{
  public ConnectionRow getDefaultConnectionRow();
  public ConnectionRow parseConnectionRowFromSource();
}
