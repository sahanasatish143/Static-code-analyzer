package com.capgemini.dac.automate.codeanalyzer.automic.connection;

import java.util.Properties;

public class TabConnString
{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new connection attribute.
   */
  public TabConnString()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new connection attribute.
   *
   * @param properties the properties
   */
  public TabConnString(Properties properties)
  {
    this.properties = properties;

  }

  public void setConnString(Connproperties tabConnString)
  {
    properties.getProperty("conn.string");
  }
}
