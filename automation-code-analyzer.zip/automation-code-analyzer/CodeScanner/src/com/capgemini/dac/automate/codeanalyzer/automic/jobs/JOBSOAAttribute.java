/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobs;

import java.util.Properties;

/**
 * This class represents an Automic JOBS object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class JOBSOAAttribute extends JOBSCITAttribute
{
  /**
   * Default constructor. This is intended to be called for creation of a blank
   * JOBSOAAttribute object in the context of an editor or in a code translator.
   */
  public JOBSOAAttribute()
  {
    this.properties = new Properties();
    this.setRKey("");
    this.setRAppSName("");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the JOBSOAAttributeFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for JOBSOAAttribute.
   * @see JOBSOAAttributeFactory
   */
  public JOBSOAAttribute(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for RKey.
   *
   * @param RKey the RKey value to set
   */
  public void setRKey(String rKey)
  {
    properties.setProperty("RKey", rKey);
  }

  /**
   * Standard getter for RKey.
   *
   * @return the RKey
   * @returns the RKey value
   */
  public String getRKey()
  {
    return properties.getProperty("RKey");
  }

  /**
   * Standard setter for RAppSName.
   *
   * @param RAppSName the RAppSName value to set
   */
  public void setRAppSName(String rAppSName)
  {
    properties.setProperty("RAppSName", rAppSName);
  }

  /**
   * Standard getter for RAppSName.
   *
   * @return the RAppSName
   * @returns the RAppSName value
   */
  public String getRAppSName()
  {
    return properties.getProperty("RAppSName");
  }
}
