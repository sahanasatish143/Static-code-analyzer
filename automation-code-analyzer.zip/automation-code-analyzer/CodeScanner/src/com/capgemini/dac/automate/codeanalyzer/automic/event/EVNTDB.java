/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.event;

import java.util.Properties;

/**
 * This class represents an Automic EVNTDB object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class EVNTDB
{

  Properties properties;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * EVNTDB object in the context of an editor or in a code translator.
   */
  public EVNTDB()
  {
    this.properties = new Properties();

  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the EVNTDBFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for EVNTDB.
   * @see EVNTDBFactory
   */
  public EVNTDB(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for Op1_type
   *
   * @param Op1_type the Op1_type value to set
   */
  public void setOp1_type(String op1_type)
  {
    properties.setProperty("Op1_type", op1_type);
  }

  /**
   * Standard getter for Op1_type
   *
   * @return the Op1_type value
   */
  public String getOp1_type()
  {
    return properties.getProperty("Op1_type");
  }

  /**
   * Standard setter for Op1_sql
   *
   * @param Op1_sql the Op1_sql value to set
   */
  public void setOp1_sql(String op1_sql)
  {
    properties.setProperty("Op1_sql", op1_sql);
  }

  /**
   * Standard getter for Op1_sql
   *
   * @return the Op1_sql value
   */
  public String getOp1_sql()
  {
    return properties.getProperty("Op1_sql");
  }

  /**
   * Standard setter for Op1_host
   *
   * @param Op1_host the Op1_host value to set
   */
  public void setOp1_host(String op1_host)
  {
    properties.setProperty("Op1_host", op1_host);
  }

  /**
   * Standard getter for Op1_host
   *
   * @return the Op1_host value
   */
  public String getOp1_host()
  {
    return properties.getProperty("Op1_host");
  }

  /**
   * Standard setter for Op1_login
   *
   * @param Op1_login the Op1_login value to set
   */
  public void setOp1_login(String op1_login)
  {
    properties.setProperty("Op1_login", op1_login);
  }

  /**
   * Standard getter for Op1_login
   *
   * @return the Op1_login value
   */
  public String getOp1_login()
  {
    return properties.getProperty("Op1_login");
  }

  /**
   * Standard setter for Op1_server
   *
   * @param Op1_server the Op1_server value to set
   */
  public void setOp1_server(String op1_server)
  {
    properties.setProperty("Op1_server", op1_server);
  }

  /**
   * Standard getter for Op1_server
   *
   * @return the Op1_server value
   */
  public String getOp1_server()
  {
    return properties.getProperty("Op1_server");
  }

  /**
   * Standard setter for Op1_db
   *
   * @param Op1_db the Op1_db value to set
   */
  public void setOp1_db(String op1_db)
  {
    properties.setProperty("Op1_db", op1_db);
  }

  /**
   * Standard getter for Op1_db
   *
   * @return the Op1_db value
   */
  public String getOp1_db()
  {
    return properties.getProperty("Op1_db");
  }

  /**
   * Standard setter for Op1_file
   *
   * @param Op1_file the Op1_file value to set
   */
  public void setOp1_file(String op1_file)
  {
    properties.setProperty("Op1_file", op1_file);
  }

  /**
   * Standard getter for Op1_file
   *
   * @return the Op1_file value
   */
  public String getOp1_file()
  {
    return properties.getProperty("Op1_file");
  }

  /**
   * Standard setter for Op1_vara
   *
   * @param Op1_vara the Op1_vara value to set
   */
  public void setOp1_vara(String op1_vara)
  {
    properties.setProperty("Op1_vara", op1_vara);
  }

  /**
   * Standard getter for Op1_vara
   *
   * @return the Op1_vara value
   */
  public String getOp1_vara()
  {
    return properties.getProperty("Op1_vara");
  }

  /**
   * Standard setter for Op1_keyword
   *
   * @param Op1_keyword the Op1_keyword value to set
   */
  public void setOp1_keyword(String op1_keyword)
  {
    properties.setProperty("Op1_keyword", op1_keyword);
  }

  /**
   * Standard getter for Op1_keyword
   *
   * @return the Op1_keyword value
   */
  public String getOp1_keyword()
  {
    return properties.getProperty("Op1_keyword");
  }

  /**
   * Standard setter for Op1_static
   *
   * @param Op1_static the Op1_static value to set
   */
  public void setOp1_static(String op1_static)
  {
    properties.setProperty("Op1_static", op1_static);
  }

  /**
   * Standard getter for Op1_static
   *
   * @return the Op1_static value
   */
  public String getOp1_static()
  {
    return properties.getProperty("Op1_static");
  }

  /**
   * Standard setter for Operator
   *
   * @param Operator the Operator value to set
   */
  public void setOperator(String operator)
  {
    properties.setProperty("Operator", operator);
  }

  /**
   * Standard getter for Operator
   *
   * @return the Operator value
   */
  public String getOperator()
  {
    return properties.getProperty("Operator");
  }

  /**
   * Standard setter for Op2_type
   *
   * @param Op2_type the Op2_type value to set
   */
  public void setOp2_type(String op2_type)
  {
    properties.setProperty("Op2_type", op2_type);
  }

  /**
   * Standard getter for Op2_type
   *
   * @return the Op2_type value
   */
  public String getOp2_type()
  {
    return properties.getProperty("Op2_type");
  }

  /**
   * Standard setter for Op2_sql
   *
   * @param Op2_sql the Op2_sql value to set
   */
  public void setOp2_sql(String op2_sql)
  {
    properties.setProperty("Op2_sql", op2_sql);
  }

  /**
   * Standard getter for Op2_sql
   *
   * @return the Op2_sql value
   */
  public String getOp2_sql()
  {
    return properties.getProperty("Op2_sql");
  }

  /**
   * Standard setter for Op2_host
   *
   * @param Op2_host the Op2_host value to set
   */
  public void setOp2_host(String op2_host)
  {
    properties.setProperty("Op2_host", op2_host);
  }

  /**
   * Standard getter for Op2_host
   *
   * @return the Op2_host value
   */
  public String getOp2_host()
  {
    return properties.getProperty("Op2_host");
  }

  /**
   * Standard setter for Op2_login
   *
   * @param Op2_login the Op2_login value to set
   */
  public void setOp2_login(String op2_login)
  {
    properties.setProperty("Op2_login", op2_login);
  }

  /**
   * Standard getter for Op2_login
   *
   * @return the Op2_login value
   */
  public String getOp2_login()
  {
    return properties.getProperty("Op2_login");
  }

  /**
   * Standard setter for Op2_server
   *
   * @param Op2_server the Op2_server value to set
   */
  public void setOp2_server(String op2_server)
  {
    properties.setProperty("Op2_server", op2_server);
  }

  /**
   * Standard getter for Op2_server
   *
   * @return the Op2_server value
   */
  public String getOp2_server()
  {
    return properties.getProperty("Op2_server");
  }

  /**
   * Standard setter for Op2_file
   *
   * @param Op2_file the Op2_file value to set
   */
  public void setOp2_file(String op2_file)
  {
    properties.setProperty("Op2_file", op2_file);
  }

  /**
   * Standard getter for Op2_file
   *
   * @return the Op2_file value
   */
  public String getOp2_file()
  {
    return properties.getProperty("Op2_file");
  }

  /**
   * Standard setter for Op2_vara
   *
   * @param Op2_vara the Op2_vara value to set
   */
  public void setOp2_vara(String op2_vara)
  {
    properties.setProperty("Op2_vara", op2_vara);
  }

  /**
   * Standard getter for Op2_vara
   *
   * @return the Op2_vara value
   */
  public String getOp2_vara()
  {
    return properties.getProperty("Op2_vara");
  }

  /**
   * Standard setter for Op2_db
   *
   * @param Op2_db the Op2_db value to set
   */
  public void setOp2_db(String op2_db)
  {
    properties.setProperty("Op2_db", op2_db);
  }

  /**
   * Standard getter for Op2_db
   *
   * @return the Op2_db value
   */
  public String getOp2_db()
  {
    return properties.getProperty("Op2_db");
  }

  /**
   * Standard setter for Op2_keyword
   *
   * @param Op2_keyword the Op2_keyword value to set
   */
  public void setOp2_keyword(String op2_keyword)
  {
    properties.setProperty("Op2_keyword", op2_keyword);
  }

  /**
   * Standard getter for Op2_keyword
   *
   * @return the Op2_keyword value
   */
  public String getOp2_keyword()
  {
    return properties.getProperty("Op2_keyword");
  }

  /**
   * Standard setter for Op2_static
   *
   * @param Op2_static the Op2_static value to set
   */
  public void setOp2_static(String op2_static)
  {
    properties.setProperty("Op2_static", op2_static);
  }

  /**
   * Standard getter for Op2_static
   *
   * @return the Op2_static value
   */
  public String getOp2_static()
  {
    return properties.getProperty("Op2_static");
  }
}
