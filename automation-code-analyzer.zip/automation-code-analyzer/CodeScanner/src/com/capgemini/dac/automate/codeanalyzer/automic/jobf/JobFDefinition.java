/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.codeanalyzer.automic.jobf;

import java.util.Properties;


// TODO: Auto-generated Javadoc
/**
 * The Class JobFDefinition.
 */
public class JobFDefinition
{
  
  /** The properties. */
  private Properties properties;

  /**
   * Constructor to build a default JobfAttr object.
   */
  public JobFDefinition()
  {
    this.properties = new Properties();
    this.setState(1);
    this.setHostSrc("|&lt;WIN&gt;|HOST");
    
    this.setCodeNameSrc("");
    this.setLoginSrc("");
    this.setCompress("");
    this.setFileNameSrc("");
    this.setFileAttrSrc("");
    this.setKeepSrcAttr("");
    this.setHostDst("");
    this.setCodeNameDst("");
    this.setLoginDst("");
    this.setFileNameDst("");
    this.setFileAttrDst("");
    this.setWildCard(0);
    this.setMaxParallel2(1);
    this.setRepeatType(0);
    this.setSubDirStruct(0);
    this.setCancelOn1stErr(0);
    
    
    this.setErase(0);
    this.setTextTypeText(1);
    this.setTextTypeBin(0);//</TextTypeBin>
    this.setOvCancel(1);//</OvCancel>
    this.setOvOverwrite(0);//</OvOverwrite>
    this.setOvAppend(0);//</OvAppend>
   
  }

  /**
   * Constructor meant to be used by a factory adhering to the JobPAttrFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public JobFDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for state.
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state.
   *
   * @return the state
   * @returns the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  /**
   * Standard setter for HostSrc.
   *
   * @param HostSrc the HostSrc value to set
   */
  public void setHostSrc(String HostSrc)
  {
    properties.setProperty("HostSrc", HostSrc);
  }

  /**
   * Standard getter for HostSrc.
   *
   * @return the host src
   * @returns the HostSrc value
   */
  public String getHostSrc()
  {
    return properties.getProperty("HostSrc");
  }

  
  /**
   * Standard setter for CodeNameSrc.
   *
   * @param CodeNameSrc the CodeNameSrc value to set
   */
  public void setCodeNameSrc(String CodeNameSrc)
  {
    properties.setProperty("CodeNameSrc", CodeNameSrc);
  }

  /**
   * Standard getter for CodeNameSrc.
   *
   * @return the code name src
   * @returns the CodeNameSrc value
   */
  public String getCodeNameSrc()
  {
    return properties.getProperty("CodeNameSrc");
  }

  /**
   * Standard setter for LoginSrc.
   *
   * @param LoginSrc the LoginSrc value to set
   */
  public void setLoginSrc(String LoginSrc)
  {
    properties.setProperty("LoginSrc", LoginSrc);
  }

  /**
   * Standard getter for LoginSrc.
   *
   * @return the login src
   * @returns the LoginSrc value
   */
  public String getLoginSrc()
  {
    return properties.getProperty("LoginSrc");
  }

  /**
   * Standard setter for Compress.
   *
   * @param Compress the Compress value to set
   */
  public void setCompress(String Compress)
  {
    properties.setProperty("Compress", Compress);
  }

  /**
   * Standard getter for Compress.
   *
   * @return the compress
   * @returns the Compress value
   */
  public String getCompress()
  {
    return properties.getProperty("Compress");
  }

  /**
   * Standard setter for FileNameSrc.
   *
   * @param FileNameSrc the FileNameSrc value to set
   */
  public void setFileNameSrc(String FileNameSrc)
  {
    properties.setProperty("FileNameSrc", FileNameSrc);
  }

  /**
   * Standard getter for FileNameSrc.
   *
   * @return the file name src
   * @returns the FileNameSrc value
   */
  public String getFileNameSrc()
  {
    return properties.getProperty("FileNameSrc");
  }

  /**
   * Standard setter for FileAttrSrc.
   *
   * @param FileAttrSrc the FileAttrSrc value to set
   */
  public void setFileAttrSrc(String FileAttrSrc)
  {
    properties.setProperty("FileAttrSrc", FileAttrSrc);
  }

  /**
   * Standard getter for FileAttrSrc.
   *
   * @return the file attr src
   * @returns the FileAttrSrc value
   */
  public String getFileAttrSrc()
  {
    return properties.getProperty("FileAttrSrc");
  }

  /**
   * Standard setter for KeepSrcAttr.
   *
   * @param KeepSrcAttr the KeepSrcAttr value to set
   */
  public void setKeepSrcAttr(String KeepSrcAttr)
  {
    properties.setProperty("KeepSrcAttr", KeepSrcAttr);
  }

  /**
   * Standard getter for KeepSrcAttr.
   *
   * @return the keep src attr
   * @returns the KeepSrcAttr value
   */
  public String getKeepSrcAttr()
  {
    return properties.getProperty("KeepSrcAttr");
  }

  /**
   * Standard setter for HostDst.
   *
   * @param HostDst the HostDst value to set
   */
  public void setHostDst(String HostDst)
  {
    properties.setProperty("HostDst", HostDst);
  }

  /**
   * Standard getter for HostDst.
   *
   * @return the host dst
   * @returns the HostDst value
   */
  public String getHostDst()
  {
    return properties.getProperty("HostDst");
  }

  /**
   * Standard setter for CodeNameDst.
   *
   * @param CodeNameDst the CodeNameDst value to set
   */
  public void setCodeNameDst(String CodeNameDst)
  {
    properties.setProperty("CodeNameDst", CodeNameDst);
  }

  /**
   * Standard getter for CodeNameDst.
   *
   * @return the code name dst
   * @returns the CodeNameDst value
   */
  public String getCodeNameDst()
  {
    return properties.getProperty("CodeNameDst");
  }

  /**
   * Standard setter for LoginDst.
   *
   * @param LoginDst the LoginDst value to set
   */
  public void setLoginDst(String LoginDst)
  {
    properties.setProperty("LoginDst", LoginDst);
  }

  /**
   * Standard getter for LoginDst.
   *
   * @return the login dst
   * @returns the LoginDst value
   */
  public String getLoginDst()
  {
    return properties.getProperty("LoginDst");
  }

  /**
   * Standard setter for FileNameDst.
   *
   * @param FileNameDst the FileNameDst value to set
   */
  public void setFileNameDst(String FileNameDst)
  {
    properties.setProperty("FileNameDst", FileNameDst);
  }

  /**
   * Standard getter for FileNameDst.
   *
   * @return the file name dst
   * @returns the FileNameDst value
   */
  public String getFileNameDst()
  {
    return properties.getProperty("FileNameDst");
  }

  /**
   * Standard setter for FileAttrDst.
   *
   * @param FileAttrDst the FileAttrDst value to set
   */
  public void setFileAttrDst(String FileAttrDst)
  {
    properties.setProperty("FileAttrDst", FileAttrDst);
  }

  /**
   * Standard getter for FileAttrDst.
   *
   * @return the file attr dst
   * @returns the FileAttrDst value
   */
  public String getFileAttrDst()
  {
    return properties.getProperty("FileAttrDst");
  }
  
  /**
   * Standard setter for WildCard.
   *
   * @param WildCard the WildCard value to set
   */
  public void setWildCard(Integer WildCard)
  {
    properties.setProperty("WildCard", WildCard.toString());
  }

  /**
   * Standard getter for WildCard.
   *
   * @return the wild card
   * @returns the WildCard value
   */
  public Integer getWildCard()
  {
    return Integer.parseInt(properties.getProperty("WildCard"));
  }

  /**
   * Standard setter for RepeatType.
   *
   * @param RepeatType the RepeatType value to set
   */
  public void setRepeatType(Integer RepeatType)
  {
    properties.setProperty("RepeatType", RepeatType.toString());
  }

  /**
   * Standard getter for RepeatType.
   *
   * @return the integer
   * @returns the RepeatType value
   */
  public Integer RepeatType()
  {
    return Integer.parseInt(properties.getProperty("RepeatType"));
  }

  /**
   * Standard setter for SubDirStruct.
   *
   * @param SubDirStruct the SubDirStruct value to set
   */
  public void setSubDirStruct(Integer SubDirStruct)
  {
    properties.setProperty("SubDirStruct", SubDirStruct.toString());
  }

  /**
   * Standard getter for SubDirStruct.
   *
   * @return the sub dir struct
   * @returns the SubDirStruct value
   */
  public Integer getSubDirStruct()
  {
    return Integer.parseInt(properties.getProperty("SubDirStruct"));
  }

  /**
   * Standard setter for CancelOn1stErr.
   *
   * @param CancelOn1stErr the CancelOn1stErr value to set
   */
  public void setCancelOn1stErr(Integer CancelOn1stErr)
  {
    properties.setProperty("CancelOn1stErr", CancelOn1stErr.toString());
  }

  /**
   * Standard getter for CancelOn1stErr.
   *
   * @return the cancel on 1 st err
   * @returns the CancelOn1stErr value
   */
  public Integer getCancelOn1stErr()
  {
    return Integer.parseInt(properties.getProperty("CancelOn1stErr"));
  }

  /**
   * Standard setter for MaxParallel2.
   *
   * @param maxParallel2 the MaxParallel2 value to set
   */
  public void setMaxParallel2(Integer maxParallel2)
  {
    properties.setProperty("MaxParallel", maxParallel2.toString());
  }

  /**
   * Standard getter for MaxParallel2.
   *
   * @return the max parallel 2
   * @returns the MaxParallel2 value
   */
  public Integer getMaxParallel2()
  {
    return Integer.parseInt(properties.getProperty("MaxParallel"));
  }

  

  /**
   * Standard setter for Erase.
   *
   * @param Erase the Erase value to set
   */
  public void setErase(Integer Erase)
  {
    properties.setProperty("Erase", Erase.toString());
  }

  /**
   * Standard getter for Erase.
   *
   * @return the erase
   * @returns the Erase value
   */
  public Integer getErase()
  {
    return Integer.parseInt(properties.getProperty("Erase"));
  }

  /**
   * Standard setter for TextTypeText.
   *
   * @param TextTypeText the TextTypeText value to set
   */
  public void setTextTypeText(Integer TextTypeText)
  {
    properties.setProperty("TextTypeText", TextTypeText.toString());
  }

  /**
   * Standard getter for TextTypeText.
   *
   * @return the text type text
   * @returns the TextTypeText value
   */
  public Integer getTextTypeText()
  {
    return Integer.parseInt(properties.getProperty("TextTypeText"));
  }
  
  /**
   * Sets the text type bin.
   *
   * @param TextTypeText the new text type bin
   */
  public void setTextTypeBin(Integer TextTypeText)
  {
    properties.setProperty("TextTypeBin", TextTypeText.toString());
  }

  /**
   * Standard getter for TextTypeText.
   *
   * @return the text type bin
   * @returns the TextTypeText value
   */
  public Integer getTextTypeBin()
  {
    return Integer.parseInt(properties.getProperty("TextTypeBin"));
  }
  
  /**
   * Standard setter for TextTypeText.
   *
   * @param TextTypeText the TextTypeText value to set
   */
  public void setOvCancel(Integer TextTypeText)
  {
    properties.setProperty("OvCancel", TextTypeText.toString());
  }

  /**
   * Standard getter for TextTypeText.
   *
   * @return the ov cancel
   * @returns the TextTypeText value
   */
  public Integer getOvCancel()
  {
    return Integer.parseInt(properties.getProperty("OvCancel"));
  }
  
  /**
   * Standard setter for TextTypeText.
   *
   * @param TextTypeText the TextTypeText value to set
   */
  public void setOvOverwrite(Integer TextTypeText)
  {
    properties.setProperty("OvOverwrite", TextTypeText.toString());
  }

  /**
   * Standard getter for TextTypeText.
   *
   * @return the ov overwrite
   * @returns the TextTypeText value
   */
  public Integer getOvOverwrite()
  {
    return Integer.parseInt(properties.getProperty("OvOverwrite"));
  }
  
  /**
   * Standard setter for TextTypeText.
   *
   * @param TextTypeText the TextTypeText value to set
   */
  public void setOvAppend(Integer TextTypeText)
  {
    properties.setProperty("OvAppend", TextTypeText.toString());
  }

  /**
   * Standard getter for TextTypeText.
   *
   * @return the ov append
   * @returns the TextTypeText value
   */
  public Integer getOvAppend()
  {
    return Integer.parseInt(properties.getProperty("OvAppend"));
  }
  
 
  

  

  

}
