package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VaraWindowsRowsFactory
{
  public VaraWindowsRows getDefaultVaraWindowsRows();
  public VaraWindowsRows parseVaraWindowsRowsFromSource();
}
