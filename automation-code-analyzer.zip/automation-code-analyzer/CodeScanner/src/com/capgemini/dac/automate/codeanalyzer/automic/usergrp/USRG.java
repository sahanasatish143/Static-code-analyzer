/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.usergrp;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicExecutableObject;

/**
 * This class represents an Automic USRG object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class USRG extends AutomicExecutableObject
{

  private UACLDefinition uaclDefinition;
  private PRIVILEGES privileges;

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * USRG object in the context of an editor or in a code translator.
   */
  public USRG()
  {
    this.properties = new Properties();
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the USRGFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for USRG.
   * @see USRGFactory
   */
  public USRG(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard getter for UACLDefinition
   *
   * @return the UACLDefinition value
   */
  public UACLDefinition getUACLDefinition()
  {
    return uaclDefinition;
  }

  /**
   * Standard setter for UACLDefinition
   *
   * @param UACLDefinition the UACLDefinition value to set
   */
  public void setUACLDefinition(UACLDefinition uaclDefinition)
  {
    this.uaclDefinition = uaclDefinition;
  }

  /**
   * Standard getter for PRIVILEGES
   *
   * @return the PRIVILEGES value
   */
  public PRIVILEGES getPRIVILEGES()
  {
    return privileges;
  }

  /**
   * Standard setter for PRIVILEGES
   *
   * @param PRIVILEGES the PRIVILEGES value to set
   */
  public void setPRIVILEGES(PRIVILEGES privileges)
  {
    this.privileges = privileges;
  }
}
