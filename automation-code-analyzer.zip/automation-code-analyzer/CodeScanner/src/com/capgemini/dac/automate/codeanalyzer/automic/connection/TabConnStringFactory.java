package com.capgemini.dac.automate.codeanalyzer.automic.connection;

public interface TabConnStringFactory
{
  public TabConnString getDefaultTabConnString();
  public TabConnString parseTabConnStringFromSource();
}
