package com.capgemini.dac.automate.codeanalyzer.automic.vara;

import java.util.Properties;

public class VARAFilelist{
  /** The properties. */
  Properties properties;

  /**
   * Instantiates a new VARA backend.
   */
  public VARAFilelist()
  {
    this.properties = new Properties();

  }

  /**
   * Instantiates a new VARA backend.
   *
   * @param properties the properties
   */
  public VARAFilelist(Properties properties)
  {
    this.properties = properties;

  }

  /**
   * Sets the host dst.
   *
   * @param hostAttrType the new host dst
   */
  public void setDirectory(String hostAttrType)
  {
    properties.setProperty("directory", hostAttrType);
  }

  /**
   * Gets the host dst.
   *
   * @return the host dst
   */
  public String getDirectory()
  {
    return properties.getProperty("directory");
  }

  /**
   * Sets the apply task H.
   *
   * @param applyTaskH the new apply task H
   */
  public void setHostDst(String applyTaskH)
  {
    properties.setProperty("HostDst", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getHostDst()
  {
    return properties.getProperty("HostDst");
  }
  public void setpreferTaskHost(Integer preferTaskHost)
  {
    properties.setProperty("preferTaskHost", preferTaskHost.toString());
  }

  /**
   * Standard getter for state
   *
   * @returns the state value
   */
  public Integer getpreferTaskHost()
  {
    return Integer.parseInt(properties.getProperty("preferTaskHost"));
  }
  public void setpreferTaskLogin(Integer preferTaskHost)
  {
    properties.setProperty("preferTaskLogin", preferTaskHost.toString());
    
  }
  public Integer getpreferTaskLogin()
  {
    return Integer.parseInt(properties.getProperty("preferTaskLogin"));
  }
  public void setLogin(String applyTaskH)
  {
    properties.setProperty("Login", applyTaskH);
  }

  /**
   * Gets the apply task H.
   *
   * @return the apply task H
   */
  public String getLogin()
  {
    return properties.getProperty("Login");
  }

  
}
