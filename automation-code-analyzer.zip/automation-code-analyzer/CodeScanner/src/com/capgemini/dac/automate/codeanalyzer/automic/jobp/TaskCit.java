/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * 
 * 
 * @author 
 * @version 1.0
 * @since 1.8
 */
public class TaskCit
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public TaskCit()
  {
    this.properties = new Properties();
    this.setBody("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskCit(Properties properties)
  {
    this.properties = properties;
  }
  
  /**
   * Standard setter for body
   *
   * @param body the body value to set
   */
  public void setBody(String body)
  {
    properties.setProperty("body", body);
  }

  /**
   * Standard getter for body
   *
   * @returns the body value
   */
  public String getBody()
  {
    return properties.getProperty("body");
  }
}