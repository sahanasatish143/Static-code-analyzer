/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.cockpit;

import java.util.Properties;

/**
 * This class represents an Automic CPITDefinition under CPIT object.
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.0
 */
public class CPITDefinition
{
  Properties properties;
  private CockpitDefinition cockpitDefinition;

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the CPITDefinition interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for CPITDefinition.
   * @see CPITDefinitionFactory
   */
  public CPITDefinition(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * CPITDefinition under CPIT object in the context of an editor or in a code
   * translator.
   */
  public CPITDefinition()
  {
    this.properties = new Properties();

  }

  /**
   * Standard getter for CockpitDefinition
   *
   * @return the CockpitDefinition value
   */
  public void setCockpitDefinition(CockpitDefinition cockpitDefinition)
  {
    this.cockpitDefinition = cockpitDefinition;
  }

  /**
   * Standard setter for CockpitDefinition
   *
   * @param CockpitDefinition the CockpitDefinition value to set
   */
  public CockpitDefinition getCockpitDefinition()
  {
    return this.cockpitDefinition;
  }

}
