package com.capgemini.dac.automate.codeanalyzer.automic.login;

import java.util.Properties;



public class LOGINDefinition
{
  Properties properties;
  
  public LOGINDefinition(Properties properties)
  {
    this.properties = properties;
  }

  public LOGINDefinition()
  {
    this.properties = new Properties();
    
  }

  /**
   * Standard setter for state
   *
   * @param state the state value to set
   */
  public void setState(Integer state)
  {
    properties.setProperty("state", state.toString());
  }

  /**
   * Standard getter for state
   *
   * @return the state value
   */
  public Integer getState()
  {
    return Integer.parseInt(properties.getProperty("state"));
  }

  public void setLogins(LoginRows parseLoginRowsFromSource)
  {
    properties.getProperty("LOGINS");
    
  }

}
