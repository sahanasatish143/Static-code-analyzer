/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.jobp;

import java.util.Properties;

/**
 * 
 * 
 * @author
 * @version 1.0
 * @since 1.8
 */
public class TaskResult
{
  Properties properties;

  /**
   * Constructor to build a default Runtime object.
   */
  public TaskResult()
  {
    this.properties = new Properties();
    this.setChkRExec(0);
    this.setRElseHalt(0);
    this.setRElseIgn(0);
    this.setRElseJPAbend(0);
    this.setRExecFlag(0);
    this.setRExecute("");
    this.setRRepMTimes(0);
    this.setRRepOn(0);
    this.setRRepWait(0);
    this.setRWhen("");
  }

  /**
   * Constructor meant to be used by a factory adhering to the RunTimeFactory
   * interface.
   *
   * @param properties a filled runtime properties block
   */
  public TaskResult(Properties properties)
  {
    this.properties = properties;
  }

  /**
   * Standard setter for ChkRExec
   *
   * @param chkRExec the ChkRExec value to set
   */
  public void setChkRExec(Integer chkRExec)
  {
    properties.setProperty("ChkRExec", chkRExec.toString());
  }

  /**
   * Standard getter for ChkRExec
   *
   * @returns the ChkRExec value
   */
  public Integer getChkRExec()
  {
    return Integer.parseInt(properties.getProperty("ChkRExec"));
  }

  /**
   * Standard setter for RElseHalt
   *
   * @param rElseHalt the RElseHalt value to set
   */
  public void setRElseHalt(Integer rElseHalt)
  {
    properties.setProperty("RElseHalt", rElseHalt.toString());
  }

  /**
   * Standard getter for RElseHalt
   *
   * @returns the RElseHalt value
   */
  public Integer getRElseHalt()
  {
    return Integer.parseInt(properties.getProperty("RElseHalt"));
  }

  /**
   * Standard setter for RElseIgn
   *
   * @param rElseIgn the RElseIgn value to set
   */
  public void setRElseIgn(Integer rElseIgn)
  {
    properties.setProperty("RElseIgn", rElseIgn.toString());
  }

  /**
   * Standard getter for RElseIgn
   *
   * @returns the RElseIgn value
   */
  public Integer getRElseIgn()
  {
    return Integer.parseInt(properties.getProperty("RElseIgn"));
  }

  /**
   * Standard setter for RElseJPAbend
   *
   * @param rElseJPAbend the RElseJPAbend value to set
   */
  public void setRElseJPAbend(Integer rElseJPAbend)
  {
    properties.setProperty("stRElseJPAbendate", rElseJPAbend.toString());
  }

  /**
   * Standard getter for RElseJPAbend
   *
   * @returns the RElseJPAbend value
   */
  public Integer getRElseJPAbend()
  {
    return Integer.parseInt(properties.getProperty("staRElseJPAbendte"));
  }

  /**
   * Standard setter for RExecFlag
   *
   * @param rExecFlag the RExecFlag value to set
   */
  public void setRExecFlag(Integer rExecFlag)
  {
    properties.setProperty("RExecFlag", rExecFlag.toString());
  }

  /**
   * Standard getter for RExecFlag
   *
   * @returns the RExecFlag value
   */
  public Integer getRExecFlag()
  {
    return Integer.parseInt(properties.getProperty("RExecFlag"));
  }

  /**
   * Standard setter for RExecute
   *
   * @param rExecute the RExecute value to set
   */
  public void setRExecute(String rExecute)
  {
    properties.setProperty("RExecute", rExecute);
  }

  /**
   * Standard getter for RExecute
   *
   * @returns the RExecute value
   */
  public String getRExecute()
  {
    return properties.getProperty("RExecute");
  }

  /**
   * Standard setter for stRRepMTimesate
   *
   * @param rRepMTimes the RRepMTimes value to set
   */
  public void setRRepMTimes(Integer rRepMTimes)
  {
    properties.setProperty("RRepMTimes", rRepMTimes.toString());
  }

  /**
   * Standard getter for RRepMTimes
   *
   * @returns the RRepMTimes value
   */
  public Integer getRRepMTimes()
  {
    return Integer.parseInt(properties.getProperty("RRepMTimes"));
  }

  /**
   * Standard setter for RRepOn
   *
   * @param rRepOn the RRepOn value to set
   */
  public void setRRepOn(Integer rRepOn)
  {
    properties.setProperty("RRepOn", rRepOn.toString());
  }

  /**
   * Standard getter for RRepOn
   *
   * @returns the RRepOn value
   */
  public Integer getRRepOn()
  {
    return Integer.parseInt(properties.getProperty("RRepOn"));
  }

  /**
   * Standard setter for RRepWait
   *
   * @param rRepWait the RRepWait value to set
   */
  public void setRRepWait(Integer rRepWait)
  {
    properties.setProperty("RRepWait", rRepWait.toString());
  }

  /**
   * Standard getter for RRepWait
   *
   * @returns the RRepWait value
   */
  public Integer getRRepWait()
  {
    return Integer.parseInt(properties.getProperty("RRepWait"));
  }

  /**
   * Standard setter for RWhen
   *
   * @param rWhen the RWhen value to set
   */
  public void setRWhen(String rWhen)
  {
    properties.setProperty("RWhen", rWhen);
  }

  /**
   * Standard getter for RWhen
   *
   * @returns the RWhen value
   */
  public String getRWhen()
  {
    return properties.getProperty("RWhen");
  }
}