/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/
package com.capgemini.dac.automate.codeanalyzer.automic.document;

import java.util.Properties;

import com.capgemini.dac.automate.codeanalyzer.automic.core.AutomicObject;

/**
 * This class represents an Automic DOCU object. 
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.0
 */
public class DOCU extends AutomicObject
{

  /**
   * Default constructor. This is intended to be called for creation of a blank
   * DOCU object in the context of an editor or in a code translator.
   */
  public DOCU()
  {
    super();
    this.setName("NEW_DOCUMENT");
  }

  /**
   * This constructor is designed to be called from a factory class that adheres
   * to the DOCUFactory interface. All children objects ,inherited from
   * AutomicObject, will be null and are expected to be injected through setters
   * by the factory.
   * 
   * @param properties a properties object that is populated with the appropriate
   * properties for DOCU.
   * @see DOCUFactory
   */
  public DOCU(Properties properties)
  {
    this.setProperties(properties);
  }
}