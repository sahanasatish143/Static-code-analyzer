package com.capgemini.dac.automate.codeanalyzer.automic.vara;

public interface VaraStaticRowFactory
{
  public VaraStaticRow getDefaultVaraStaticRow();
  public VaraStaticRow parseVaraStaticRowFromSource();
}
