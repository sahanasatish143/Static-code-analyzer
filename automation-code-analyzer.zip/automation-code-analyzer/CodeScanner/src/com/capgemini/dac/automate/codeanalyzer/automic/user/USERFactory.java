/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.codeanalyzer.automic.user;

/**
 * This interface represents a factory class for building a {@link USER} object.
 * <p>
 * In order to comply with this interface the implementing class needs to return
 * a complete with all children populated.
 * <p>
 * For the method getDefaultUSER it should be sufficient to call the default
 * constructor for USER.
 * <p>
 * The method parseUSERFromSource is intended for non-default uses. This can be
 * achieved by calling the default constructor and then using the setters to
 * populate the values or by using the properties constructor, USER (Properties
 * properties). In the second case the factory will need to inject a fully
 * populated properties block and then inject a populated Header object.
 * <p>
 * Properties that need to be in the properties block are:
 * <ul>
 * <li>name : the name of the object. the value needs to adhere to Automic
 * naming standards.</li>
 * </ul>
 * 
 * @author Abhishek Tenneti &lt; abhishek.tenneti@capgemini.com &gt;
 * @version 1.0
 * @since 1.8
 * @see USER
 */
public interface USERFactory
{
  /**
   * @return A USER object with default values.
   */
  public USER getDefaultUSER();

  /**
   * @return A USER object completely populated by the factory.
   */
  public USER parseUSERFromSource();
}
